try:
    from simplegeneric import *
except ImportError:
    from ._simplegeneric import *
