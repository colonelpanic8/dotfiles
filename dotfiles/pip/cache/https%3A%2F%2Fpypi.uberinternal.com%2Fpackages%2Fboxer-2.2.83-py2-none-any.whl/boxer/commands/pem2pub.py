import logging
import os
import shutil
import subprocess

import click

from boxer.cli import cli
from boxer.click_lib import BoxerClickReturn, click_command, fail

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('pem_filename', type=click.Path(exists=True))
@click.pass_context
def pem2pub(ctx, pem_filename):
    """Turn a .pem into a key and pubfile.

    :param str pem_filename: Path to the .pem to convert

    This is helpful when building custom boxes with keys from Amazon as Vagrant does not support .pems.

    For example::

        \b
        boxer pem2pub ~/.ssh/uber-dev-YOU.pem
    """
    if not pem_filename.endswith('.pem'):
        fail(ctx, msg="pem_filename '%s' does not end in .pem" % pem_filename)

    pem_filename = os.path.expanduser(os.path.expandvars(pem_filename))

    key_dir, private_key_name = os.path.split(pem_filename)
    private_key_name, _ = os.path.splitext(private_key_name)
    pub_key_name = private_key_name + '.pub'

    private_key_path = os.path.join(key_dir, private_key_name)
    pub_key_path = os.path.join(key_dir, pub_key_name)

    # copy pem_filename to private_key_name
    shutil.copyfile(pem_filename, private_key_path)
    os.chmod(private_key_path, 0600)

    # get the public key from the private key
    pub_contents = subprocess.check_output(['ssh-keygen', '-y', '-f', private_key_path], env=os.environ)
    with open(pub_key_path, 'w') as f:
        f.write(pub_contents)
    os.chmod(pub_key_path, 0644)  # os.fchmod failed with weird errors

    log.info("Created %s and %s from %s", private_key_name, pub_key_name, pem_filename)
    return BoxerClickReturn(output=True)
