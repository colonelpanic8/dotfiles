import logging
import os
import os.path

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, is_local_vagrant_or_fail

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.pass_context
def edit(ctx, name):
    """Edit a vagrant's configuration.

    By default, the config is stored in ~/.boxer/vagrants/<name>/boxes.yaml

    For example::

        \b
        boxer edit $VAGRANTNAME
    """
    name = is_local_vagrant_or_fail(ctx, name)

    with boxer_lock(ctx, name):
        boxer_config = ctx.find_object(config.BoxerConfig)
        vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)
        yaml_filename = os.path.join(vagrant_dir, 'boxes.yaml')

        click.edit(filename=yaml_filename)

    return BoxerClickReturn(output=True)
