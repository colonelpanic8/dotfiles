import logging
import os
import os.path
import pprint
import subprocess

import click
import yaml

from boxer import config
from boxer.commands.bootstrap import bootstrap
from boxer.cli import cli
from boxer.click_lib import (
    BoxerClickReturn, check_current_cloud_vagrants, click_command, click_vagrant_options, fail, get_box_urls,
    get_current_cloud_vagrants, get_current_vagrants, get_s3_bucket, quick_s3_get
)
from boxer.commands.download_box import download_box
from boxer.commands.export_vagrant import export_vagrant
from boxer.commands.ssl import fetch_dev_ssl
from boxer.commands.terminate import terminate
from boxer.commands.v import v
from boxer.lib import (
    edit_diff, edit_config_csv, is_box_installed, is_valid_hostname, sanitize_vagrant_name,
)

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option('--name', required=True)  # todo: do the lowering and underscore replacing with a click type
@click.option('--with-export/--no-export', default=False)
@click_vagrant_options
def create_vagrant(
    ctx,
    add_all_boxes,
    aws_ami,
    aws_disk_size,
    aws_keypair,
    aws_mnt_size,
    aws_region,
    aws_type,
    aws_zone,
    box_name,
    build_num,
    check_existing,
    create_log,
    destroy_scripts_local,
    distro,
    email,
    env,
    fallback_role,
    force,
    launch_provider,
    name,
    override_role,
    prefix,
    private_keys,
    providers,
    provision_scripts_vagrant,
    puppet_custom_include_files,
    puppet_custom_includes,
    puppet_diffs,
    puppet_includes,
    role,
    services,
    ssh_username,
    uber_service,
    update,
    vbox_ip,
    vmware_ip,
    with_aws_dns,
    with_aws_vpc,
    with_bootstrap_puppet,
    with_custom_config,
    with_export,
    with_launch,
    with_ssh,
    with_ssl,
    with_update_terminates,
    **extra_kwargs
):
    """Create or update a Vagrantfile.

    .. TODO:: link to click_vagrant_command for the rest of the vagrant commands

    The simplest usage is to run this one command then follow the instructions it prints::

        \b
        boxer create_vagrant --name VAGRANTNAME
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    # sanitize variables
    if email is None:
        email = ''
    else:
        email = email.strip()
    if not email:
        if update:
            log.debug("Updating without an UBER_OWNER")
        else:
            # todo: I thought required=True on there would do this for us :(
            fail(ctx, msg="UBER_OWNER env var not set to your @uber.com email! Please export it in your ~/.bash_profile or similar or use --email")

    # sanitize more variables
    name = sanitize_vagrant_name(name)

    # todo: split this into a 'get_next_name' function?
    if not update:
        # this could probably more dynamic
        if role == 'devserver' or override_role == 'devserver':  # if devserver is part of either role, its going to take awhile
            time_message = "Prepare to wait up to an hour for your devserver vagrant to launch and provision"
        elif not override_role and role == 'base':  # if we are launching a simple base role, its pretty fast
            time_message = "Prepare to wait 12-20 minutes for your base vagrant to launch and provision"
        else:
            time_message = "Prepare to wait up to an hour for vagrant to launch and provision"
        log.info(click.style(time_message, fg='blue'))

        name_count = 0
        default_name = name

        if check_existing:
            # join local vagrant list with remote vagrant list for finding a name
            all_current_vagrants = list(get_current_vagrants(ctx)) + [ccv['name'] for ccv in get_current_cloud_vagrants(ctx)]

            while default_name in all_current_vagrants:
                name_count += 1
                default_name = sanitize_vagrant_name("%s%s" % (name, name_count))
        else:
            log.warning("Skipping check of currently running instances")

        if name != default_name:
            log.info("An instance named '%s' already exists", name)
            if force:
                log.info("Using %s instead of %s", default_name, name)
                name = default_name
            else:
                while name in all_current_vagrants:
                    name = click.prompt("New instance name", default=default_name)

    # todo: prompt the user to make sure they don't want to query lifeguard
    # todo: if they do want lifeguard. set name to None
    # todo: make sure we don't ask lifeguard if it is lifeguard

    domain = config.DEFAULT_DOMAIN  # todo: check the domain being used instead of the default

    if not update:
        log.debug("Creating %s.%s for %s", name, domain, email)

    # we can't use a * here because that isn't a valid name
    wildcard_hostname = 'X.{name}.{domain}'.format(name=name, domain=domain)
    try:
        if not is_valid_hostname(wildcard_hostname):
            fail(ctx, msg="Invalid name! '%s' contains invalid characters" % name)
    except ValueError as e:
        fail(ctx, msg="Invalid name! %s" % e)

    if name.endswith("vagrantname") or name.endswith("username") or name.startswith("vagrantname") or name.startswith("username"):
        fail(ctx, msg="Invalid name! You shouldn't blindly copy/paste commands!")
    if email:
        if email.endswith("email@uber.com") or email.endswith("name@uber.com"):
            fail(ctx, msg="Invalid email! You shouldn't blindly copy/paste commands!")
        if not email.endswith("@uber.com"):
            fail(ctx, msg="You must launch a vagrant with your @uber.com email address!")

    if providers:
        providers = providers.split(',')
    else:  # pragma: no cover
        providers = config.DEFAULT_PROVIDERS

    # todo: make sure launch_provider is in the list of available providers

    if box_name and build_num:
        fail(ctx, msg="You can specify box_name OR build_num OR neither, but not both")

    if aws_region and aws_zone:
        if len(aws_zone) == 1:
            # if this is just a single letter, prepend the region
            aws_zone = aws_region + aws_zone
        elif aws_zone.startswith(aws_region):
            # the zone is inside the region
            pass
        else:
            fail(ctx, msg="aws_zone '%s' is not inside aws_region '%s'" % (aws_zone, aws_region))

    # todo: do we really need this? shouldn't ssh agent forwarding be enough?
    private_keys = private_keys.split(',')
    private_key = None
    for pk in private_keys:
        pk = os.path.expanduser(os.path.expandvars(pk))
        if os.path.exists(pk):
            private_key = pk
            break
    if not private_key:
        fail(ctx, msg="Unable to load an ssh private key")

    # hvm instances are special
    # todo: use a prebuilt uber ami
    if aws_type[:2] in config.HVM_ONLY_INSTANCE_TYPES and not (aws_ami or build_num):
        fail(ctx, msg=("Instance type {} requires HVM. Use --ami-id or --build-num to specify an hvm:ebs ami. "
                       "See https://engdocs.uberinternal.com/boxer/advanced.html#hvm-instance-types "
                       "for more details").format(aws_type))

    # todo: alert if vbox_ip is already in use with the help of `get_current_vagrants`

    # setup some more variables
    box_role = role  # this may change to fallback_role if an image isn't available for the given role
    vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)

    # path on s3. not local!
    # todo: move this to a function in lib?
    latest_template = os.path.join('vagrant_boxes', '{prefix}-{provider}-{distro}-{env}-{role}.latest')

    # setup variables that use the above variables
    vagrant_filename = os.path.join(vagrant_dir, 'Vagrantfile')
    yaml_filename = os.path.join(vagrant_dir, 'boxes.yaml')

    # if a Vagrantfile is already setup, require --update
    if os.path.exists(vagrant_filename) or os.path.exists(yaml_filename):
        if update:
            if with_update_terminates:
                message = click.style(
                    ("Prompting termination of existing instance. You can say no if you want to keep the instance "
                     "running, but if you want the latest image, say yes!"),
                    fg='yellow',
                )
                log.info(message)
                if not ctx.invoke(terminate, names=[name], force=force, with_raise=False):
                    log.info('Existing instance left alone. Continuing to update Vagrantfile and boxes.yaml')
                    # todo: maybe call `vagrant reload` at the end instead?
        else:
            # todo: prompt here instead of aborting
            fail(ctx, msg=("Files already exists in %s! Set --update to update an existing Vagrant or use the "
                           "current files with `boxer v %s -c up`" % (vagrant_dir, name)))

    if not update and 'aws' in providers and check_existing:
        # this will abort if there are dupes
        check_current_cloud_vagrants(ctx, name=name)

    # variables to hold things
    box_urls = {}  # provider: [list of box urls]
    more_boxes = []  # messages related to boxes that need to be added
    messages = []  # misc messages
    closing_messages = [
        click.style(
            ("A basic Vagrantfile and config has been created for you.ustomize the box to "
             "your needs. Run the following to start the vagrant instance:\n"),
            fg='green',
        ),
    ]

    # box files are stored on s3, so grab the bucket
    bucket = get_s3_bucket(ctx)

    if box_name:
        messages.append(click.style(
            ("`vagrant up` will NOT be able to add the box '{}' for this Vagrantfile. Be sure it is already added "
             "before running `vagrant up`"),
            fg='yellow',
        ).format(box_name))
        closing_messages.append("boxer v %s -c up\n" % (vagrant_dir))
    else:
        # todo: move this to a separate function
        box_names = []  # parts of the box names used to create a hash that matches these boxes
        build_num_set = set()
        build_nums = {}

        if build_num:
            # the user specified a build_num, check S3 for it
            # todo: this can't handle providers with differing build_nums
            for provider in providers:
                box_urls[provider] = get_box_urls(
                    ctx,
                    bucket=bucket,
                    distro=distro,
                    env=env,
                    num=build_num,
                    prefix=prefix,
                    provider=provider,
                    role=box_role,
                )
                box_names.append('%s-%s-%s-%s' % (provider, distro, box_role, build_num))

                build_num_set.add(build_num)
                build_nums[provider] = build_num + box_role
        else:
            # check S3 for the latest build_num for all the providers
            for provider in providers:
                if provider == 'aws' and aws_ami:
                    log.info("Using an ami-id instead of a box for the aws provider.")
                    if not is_box_installed('dummy', 'aws'):
                        log.info("Dummy box is required, but not currently setup. Bootstrapping for you now")
                        result = ctx.invoke(bootstrap)
                        if not result:
                            fail(ctx, msg="Bootstrapping failed")
                    # todo: maybe skip the real box completely. we override with dummy in the vagrantfile anyways

                latest_txt = latest_template.format(
                    distro=distro,
                    env=env,
                    prefix=prefix,
                    provider=provider,
                    role=box_role,
                )
                latest_boxes = quick_s3_get(ctx, latest_txt)
                # if latest_txt doesn't exist, emit a warning and use the fallback_role
                if not latest_boxes:
                    log.warning("{} does not exist on S3".format(os.path.basename(latest_txt)))

                    if fallback_role != role:
                        box_role = fallback_role
                        latest_txt = latest_template.format(
                            distro=distro,
                            env=env,
                            prefix=prefix,
                            provider=provider,
                            role=box_role,
                        )
                        latest_boxes = quick_s3_get(ctx, latest_txt)
                        if not latest_boxes:
                            log.warning("Fallback file {} does not exist on S3".format(os.path.basename(latest_txt)))

                # same check as above, but latest_boxes might have been set
                if not latest_boxes:
                    log.error(
                        click.style(
                            "The %s provider will be unavailable for this Vagrantfile.",
                            fg='red',
                        ),
                        provider,
                    )
                    continue

                # this is kind of a weird file format
                # todo: the original use-case isn't around anymore, so we might want to change the format
                data = latest_boxes.strip().split()
                build_num = data[:1][0]
                build_num_set.add(build_num)
                build_nums[provider] = build_num + box_role

                if role == box_role:
                    log.info(click.style(
                        "Using build {build_num} for the {provider} provider".format(
                            build_num=build_num,
                            provider=provider,
                        ),
                        fg='green',
                    ))
                else:
                    log.warning(click.style(
                        "No {provider} build for {role}. Using build {build_num} for {box_role} role instead".format(
                            box_role=box_role,
                            build_num=build_num,
                            provider=provider,
                            role=role,
                        ),
                        fg='yellow',
                    ))

                # this url is only valid for a set amount of time
                box_urls[provider] = get_box_urls(
                    ctx,
                    bucket=bucket,
                    distro=distro,
                    env=env,
                    num=build_num,
                    prefix=prefix,
                    provider=provider,
                    role=box_role,
                )
                box_names.append('%s-%s-%s-%s' % (provider, distro, box_role, build_num))

        if not box_names:
            fail(ctx, msg="No boxes found! Ask for help")

        # collapse all boxes into a single name even though they may have different build_nums
        # in a perfect world, they will all always have the same build number and we would name the box with that
        box_name = "%s_" % (distro, )
        if len(build_num_set) == 1:
            box_name += build_num_set.pop()
        else:
            box_name += '_'.join("%s%s" % t for t in build_nums.iteritems())

        # prepare some helpful messages
        first = True
        for provider in providers:
            log.debug("Processing provider '%s'", provider)
            if provider not in box_urls:
                continue
            for box_url in box_urls[provider]:
                if box_url.startswith('/') and not os.path.exists(box_url):
                    log.debug("box not found locally: %s", box_url)
                    continue

                if force or not is_box_installed(box_name, provider):
                    if add_all_boxes:
                        log.debug("Adding box for '%s' now...", provider)
                        # todo: error handling here
                        # todo: parallelize adding the boxes?
                        # todo: use `download_box` to leverage axel
                        result = ctx.invoke(
                            download_box,
                            box_name=box_name, box_urls=box_urls[provider], force=force, name=name, provider=provider,
                            with_add=True,
                        )
                        if not result:
                            fail(ctx, msg="Unable to download box for %s: %s" % (name, result))
                    else:
                        msg = click.style(provider + ": ", fg='yellow')
                        msg += "boxer download_box %s %s\n" % (name, provider)
                        more_boxes.append(msg)

                if first:
                    first = False
                else:
                    closing_messages.append(click.style("OR\n", fg='green'))

                # this makes Bryan sad
                if provider == 'vmware':
                    launch_provider = 'vmware_fusion'  # boxes get launched with vmware_FUSION
                else:
                    launch_provider = provider

                closing_messages.append(
                    "boxer download_box {name} {provider} && boxer v {name} -c \"up --provider={provider}\"\n".format(
                        name=name,
                        provider=launch_provider,
                    )
                )
                break  # only do these messages once

        if more_boxes:
            messages.append(
                click.style(
                    ("If you are not running `vagrant up` within the next 24 hours or are on a flakey network, run "
                     "these expiring commands for the relevant providers, and `vagrant up` will work at your "
                     "convenience:\n"),
                    fg='green',
                ),
            )
            messages.extend(more_boxes)

    # todo: there might be something better to check
    if len(closing_messages) == 1:
        fail(ctx, msg="No boxes found to actually download. The latest files must be broken. Ask for help")

    # todo: move this to a helper?
    if destroy_scripts_local:
        # filter any empty strings
        destroy_scripts_local = [i for i in destroy_scripts_local.split(',') if i]
    else:
        destroy_scripts_local = []

    if provision_scripts_vagrant:
        # filter any empty strings
        provision_scripts_vagrant = [i for i in provision_scripts_vagrant.split(',') if i]
    else:
        provision_scripts_vagrant = []

    # create the yaml file that is read by our magical Vagrantfile
    # todo: allow setting `aws_security_groups` and even making the groups on the fly
    # todo: allow multiple boxes? for now that will have to be done by hand
    goal_role = override_role or role
    data = [{
        ':altname': '{env}-{name}'.format(env=env, name=name),
        ':arc_diffs': {
            'uber-puppet-manifests': [],
        },
        ':aws_ami': aws_ami,
        ':aws_availability_zone': aws_zone,
        ':aws_disks': {
            '/dev/sda1': ['/dev/xvda1', 'root', aws_disk_size, '/'],
            '/dev/sdb': ['/dev/xvdb', 'mnt', aws_mnt_size, '/mnt'],
        },
        ':aws_instance_type': aws_type,
        ':aws_keypair': aws_keypair,
        ':aws_region': aws_region,
        ':aws_security_groups': ['uber-development-devserver'],
        ':aws_skip_bootstrap_puppet': not with_bootstrap_puppet,
        ':box': box_name,
        ':box_urls': box_urls,
        ':destroy_scripts_local': destroy_scripts_local,
        ':distro': distro,
        ':ec2_stack_name': name,
        ':hostname': name,
        ':name': ':' + name,
        ':primary': True,
        ':provision_scripts_vagrant': provision_scripts_vagrant,
        ':puppet_custom_includes': [],
        ':puppet_includes': [],
        ':remote_paths': [],
        ':services': [],
        ':ssh_private_key': private_key,
        ':ssh_username': ssh_username,
        ':uber_env': env,
        ':uber_role': goal_role,
        ':uber_service': uber_service,
        ':vbox_ip': vbox_ip,
        ':vmware_ip': vmware_ip,
        ':with_aws_dns': with_aws_dns,
    }]

    # add more things to the yaml
    if services:
        log.info('Adding services: %s' % services)
        data = edit_config_csv(data, ':services', services.encode('ascii', 'ignore'))
    if puppet_includes:
        log.info("Adding puppet_includes: %s" % puppet_includes)
        data = edit_config_csv(data, ':puppet_includes', puppet_includes)
    if puppet_custom_include_files:
        log.info("Adding puppet_custom_include_files: %s" % puppet_custom_include_files)
        data = edit_config_csv(data, ':puppet_includes', puppet_custom_include_files)
    if puppet_custom_includes:
        log.info("Adding puppet_custom_includes: %s" % puppet_custom_includes)
        data = edit_config_csv(data, ':custom_includes', puppet_custom_includes)
    data = edit_diff(data, 'uber-puppet-manifests', puppet_diffs)

    if email:
        data[0][':uber_owner'] = email

    if aws_ami:  # pragma: no cover
        log.warning(
            click.style(
                ("Vagrant will try to login as '%s' with '%s' and '%s' to AMI '%s'. Waiting for SSH will never"
                 "succeed if this is wrong"),
                fg='blue',
            ),
            ssh_username, aws_keypair, private_key, aws_ami,
        )

    if with_aws_vpc:
        log.info(
            click.style(
                "Creating a Vagrantfile for the AWS VPC. Be sure you are connected to the VPN!",
                fg='blue',
            )
        )
        try:
            aws_security_groups = boxer_config.get('AWS_VPC_SECURITY_GROUPS')[aws_region]  # todo: allow overrides
            aws_subnet_id = boxer_config.get('AWS_VPC_SUBNETS')[aws_region][aws_zone]
        except KeyError:
            fail(ctx, msg="VPC is not currently available in aws_region '%s'" % (aws_region, ))
        data[0][':aws_security_groups'] = aws_security_groups
        data[0][':aws_subnet_id'] = aws_subnet_id

    if not force and with_custom_config:
        # todo: instead of editting directly, first:
        # 1) prompt for diff ids for uber-puppet-manifests
        # 2) prompt for puppet_include files
        interactive_edit_yaml = True
    else:
        interactive_edit_yaml = False

    # create the directories and copy the base Vagrantfile
    if not os.path.exists(vagrant_dir):
        subprocess.check_call(['mkdir', '-p', vagrant_dir], env=os.environ)
    if os.path.lexists(vagrant_filename):
        os.unlink(vagrant_filename)
    os.symlink(config.BASE_VAGRANTFILE, vagrant_filename)

    # add the old yaml file overtop the new data
    if os.path.exists(yaml_filename):
        with open(yaml_filename, 'r') as f:
            prev_data = yaml.safe_load(f)

        # there may be multiple boxes in the yaml file
        # todo: this will probably change when `boxer vagrant` can make a yaml with multiple instances
        num_boxes_in_prev = len(prev_data)
        if num_boxes_in_prev > 1:
            for i in xrange(1, num_boxes_in_prev):
                data.append(data[0].copy())

        # override the existing keys that we already have in our YAML
        for i, prev_box_data in enumerate(prev_data):
            del prev_box_data[':box']
            del prev_box_data[':box_urls']
            data[i].update(prev_box_data)

        log.debug("Merged old yaml with new: %s", pprint.pformat(data))

    # save the yaml
    with open(yaml_filename, 'w') as f:
        f.write(yaml.safe_dump(data))

    if interactive_edit_yaml:
        click.edit(filename=yaml_filename)

    if update:
        log.info(click.style("Vagrantfile updated for %s", fg='green'), name)
    elif with_launch:
        result = ctx.invoke(download_box, name=name, provider=launch_provider, with_add=True)
        if not result:
            fail(ctx, msg="Failed downloading %s box for %s: %s" % (launch_provider, name, result), output=name)
            # todo: terminate?

        # this makes Bryan sad: vagrant and packer aren't consistent
        if launch_provider == 'vmware':
            launch_provider = 'vmware_fusion'

        # split provisioning because it can time out and then the instance terminates
        result = ctx.invoke(
            v,
            name=name,
            command=['up', '--provider', launch_provider, '--no-provision'],
            check_existing=False,
            log_file=create_log,
            with_exit=False,
        )
        if not result:
            fail(ctx, msg="Failed bringing up %s with provider %s: %s" % (name, launch_provider, result), output=name)
            # todo: terminate?

        if with_export:
            result = ctx.invoke(export_vagrant, delete_local=False, name=name)
            if not result:
                fail(ctx, msg="Failed exporting %s: %s" % (name, result), output=name)

        result = ctx.invoke(
            v,
            name=name,
            command=['provision'],
            log_file=create_log,
            with_exit=False,
        )
        if not result:
            # fail(ctx, msg="Failed provisioning %s: %s" % (name, result), output=name)
            log.error("Failed provisioning %s: %s", name, result)
        else:
            log.debug("provision result: %s", result)

        if with_ssl and goal_role in ('devserver'):
            # always force because this prompt is never helpful
            # don't use DNS because it probably has not yet propagated
            result = ctx.invoke(fetch_dev_ssl, force=True, name_or_fqdn=name, with_dns=False)
            if not result:
                log.warning("Failed fetching dev SSL certificates for %s: %s", name, result)

        if with_ssh:
            # todo: if this ever can use DNS, this will need to change to have with_dns=False
            result = ctx.invoke(v, name=name, command=['ssh'], with_exit=False)
            if result.returncode not in (0, 130):
                # todo: i think this can fail if the ssh connects but then the tunnel is killed. kinda misleading
                fail(ctx, msg="Failed SSHing to %s. Ask for help: %s" % (name, result), output=name)
    else:
        # print helpful final messages
        for m in messages + closing_messages:
            click.echo(m)

        log.info(click.style("Vagrantfile created for %s", fg='green'), name)

    return BoxerClickReturn(output=name)
