import logging
import os
import shutil
import subprocess
import sys
import time

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail, get_s3_bucket
from boxer.commands.ssl import remove_dev_ssl
from boxer.lib import sanitize_vagrant_name

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('names', nargs=-1)
@click.option('--force', default=None, help='force termination without user confirmation', is_flag=True)
@click.option('--with-raise/--no-raise', default=True, help='ADVANCED: Only useful when boxer is used as a library')
@click.pass_context
def terminate(ctx, names, force=False, with_raise=True):
    """Destroy a vagrant and all its local files.

    Generally, the default options are fine::

        \b
        boxer terminate $VAGRANTNAME
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    if not names:
        return

    # check wether we can ask for user confirmation.
    # todo: get rid of this check?
    if not sys.stdin.isatty() and not force:  # pragma: no cover
        fail(ctx, msg="This command requires user confirmation")

    expected_terminations = len(names)
    terminations = 0
    for name in names:
        name = sanitize_vagrant_name(name)

        with boxer_lock(ctx, 'terminate-%s' % name):

            # todo: check that name is a valid name to terminate
            vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)
            remote_deleted = False

            # todo: move this if to a function
            if not os.path.exists(vagrant_dir):
                # prompt to fetch the files for s3
                log.debug("%s does not exist locally!", vagrant_dir)

                if force or click.confirm("Attempt to download Vagrantfile for {}?".format(name), default=True):
                    try:
                        # circular imports. we can't do this at the top
                        from boxer.commands.import_vagrant import import_vagrant

                        result = ctx.invoke(import_vagrant, claim=False, delete_remote=True, name=name)
                        if not result:
                            log.warning("Vagrant files for '%s' not available remotely", name)
                            continue

                        remote_deleted = True
                    except Exception:
                        # todo: don't except so much
                        log.warning("Exception while fetching remote vagrant files for '%s'", name)
                        continue
                else:
                    log.warning("Vagrant files for '%s' not available locally", name)
                    continue
            else:
                # check for stray vagrant processes
                # there is no need to check if the vagrant wasn't local since theres no chance those processes are related
                # todo: figure out how to only get processes that are relavant to this vagrant
                if not force:
                    try:
                        output = subprocess.check_output(['pgrep', '-fl', 'vagrant'], env=os.environ)

                        message = click.style(
                            ("Found vagrant processes running locally (possibly stuck in the background). These may be okay, "
                             "but if they are running for %s, terminate will fail unless they are killed."),
                            fg='yellow',
                        )
                        log.info(message, name)

                        click.echo('')
                        click.echo(output)

                        message = click.style(
                            "Are you sure the above processes are okay? Continue terminating {}? If you are unsure, ask for help",  # noqa
                            fg='yellow',
                        ).format(name)
                        if not click.confirm(message, abort=with_raise):
                            return False

                    except subprocess.CalledProcessError:
                        # no running vagrant processes
                        pass

            # don't check if we force termination.
            if not force:
                message = ("Saying yes to this action will delete everything related to '{name}' (INCLUDING ALL SYNCED FILES) "  # noqa
                           "and CANNOT be undone.\nAre you sure ALL your synced code is pushed somewhere safe and that you "
                           "want to destroy '{name}'? ")
                message = click.style(message, fg='magenta').format(name=name)
                if not click.confirm(message, abort=with_raise):
                    return False

            # destroy the vagrant if its running
            original_wd = os.getcwd()
            try:
                os.chdir(vagrant_dir)

                vagrant_is_built = False
                # check if any of the vagrants are created
                try:
                    output = subprocess.check_output(['vagrant', 'status'], env=os.environ).splitlines()[2:-2]
                    for o in output:
                        if not o.strip():
                            continue

                        name, status = o.split(None, 1)
                        log.debug("%s: %s", name, status)
                        # todo: i think this can miss something if we terminate while they are launching
                        if not status.startswith('not created'):
                            vagrant_is_built = True
                except subprocess.CalledProcessError:
                    if not force:
                        message = ("Failed running 'vagrant status' for '{name}'. An error with 'vagrant_aws.config.ami_required' "  # noqa
                                   "is usually okay.\nContinue terminating?")
                        message = click.style(message, fg='magenta').format(name=name)
                        click.confirm(message, abort=True)

                if vagrant_is_built:
                    subprocess.check_call(['vagrant', 'destroy', '--force'], env=os.environ)
                    time.sleep(10)  # todo: actually wait for the vagrant to shutdown and shared directories to unmount
                else:
                    log.debug("Vagrant is not built, so skipping destroy step")
            except subprocess.CalledProcessError:
                log.error('vagrant destroy did not exit cleanly')
                raise
            finally:
                os.chdir(original_wd)

            # delete the vagrant directory
            try:
                shutil.rmtree(vagrant_dir)
            except OSError:
                # this shouldn't ever happen, but it does sometimes for vagrants made with older versions of boxer
                log.info("Unable to delete %s", vagrant_dir)

            if os.path.exists(os.path.expanduser('~/.ssh/known_hosts')):
                for domain in config.PROVIDER_DOMAIN_MAP.itervalues():
                    fqdn = "{}.{}".format(name, domain)

                    unison_profile = os.path.expanduser(os.path.join("~", ".unison", "{}.prf".format(fqdn)))
                    if os.path.exists(unison_profile):
                        log.info("Deleting %s", unison_profile)
                        os.unlink(unison_profile)

                    sync_dir = os.path.join(boxer_config.get('BOXER_SYNC_ROOT'), fqdn)
                    if os.path.exists(sync_dir):
                        log.info("Deleting %s", sync_dir)
                        shutil.rmtree(sync_dir)

                    subprocess.check_call(['ssh-keygen', '-R', fqdn], env=os.environ)

                    # remove installed dev ssl certificate.
                    result = ctx.invoke(remove_dev_ssl, name_or_fqdn=fqdn)
                    if not result:
                        log.warning("Failed removing dev SSL for %s", fqdn)

                # remove remote_paths file
                remote_paths_filename = sync_dir + '.remote_paths'
                if os.path.exists(remote_paths_filename):
                    os.unlink(remote_paths_filename)

                # delete the entry in ~/.ssh/known_hosts
                subprocess.check_call(['ssh-keygen', '-R', name], env=os.environ)
                subprocess.check_call(['ssh-keygen', '-R', "%s.dev" % name], env=os.environ)

            if not remote_deleted:
                # todo: exception handling?
                key_name = "vagrants/%s.tar.gz" % name

                bucket = get_s3_bucket(ctx)
                bucket.delete_key(key_name)
                log.info("Deleted remote Vagrant files for %s", name)

            terminations += 1

    if terminations != expected_terminations:
        msg = "Only {} of {} instances were terminated. You can try terminating with 'boxer aws terminate INSTANCEID' instead".format(
            terminations,
            expected_terminations,
        )
        fail(ctx, msg=msg)

    return BoxerClickReturn(output=True)
