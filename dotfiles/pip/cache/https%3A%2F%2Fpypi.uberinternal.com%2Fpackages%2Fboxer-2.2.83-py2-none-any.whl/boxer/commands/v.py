import logging
import os
import re
import shlex
import subprocess

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import BoxerClickReturn, check_current_cloud_vagrants, click_command, is_local_vagrant_or_fail

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.option(
    '--check-existing/--no-check-existing',
    default=True,
    help="Check for existing vagrants with the same name before 'up'",
)
@click.option('-c', '--command', default='ssh')
@click.option('--force/--interactive', is_flag=True, default=False)
@click.option('--log-file', default=None, type=click.File('a+'))
@click.option('--with-exit/--no-exit', default=True)
@click.pass_context
def v(ctx, name, check_existing, log_file, command, force, with_exit):
    """Control a vagrant.

    This is essentially just a wrapper that cd's next to the relevant Vagrantfile and runs ``vagrant <command>``.

    If you are ever told to run 'vagrant COMMAND', run 'boxer v $VAGRANTNAME -c "COMMAND"' instead.

    Some simple examples::

        \b
        boxer v $VAGRANTNAME -c up
        boxer v $VAGRANTNAME
        boxer v $VAGRANTNAME -c provision
        boxer v $VAGRANTNAME -c "reload --provision"
    """
    name = is_local_vagrant_or_fail(ctx, name)

    boxer_config = ctx.find_object(config.BoxerConfig)

    vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)

    if isinstance(command, basestring):
        command = shlex.split(command)

    if 'up' in command and check_existing:
        check = False

        # check for '--provider=aws' in the command
        match = False
        for c in command:
            match = re.match('--provider=(.*)', c)
            if match:
                break
        if match:
            if match.group(1) == 'aws':
                check = True
        else:
            # check for ['--provider', 'aws'] in the command
            try:
                provider_index = command.index('--provider')
            except ValueError:
                provider_index = False
            if provider_index:
                if command[provider_index + 1] == 'aws':
                    check = True
            else:
                # no '--provider' in the command. check the default provider
                if os.environ.get('VAGRANT_DEFAULT_PROVIDER') == 'aws':
                    check = True

        # we are launching a box with the aws provider
        if check:
            # this will abort if there are dupes
            check_current_cloud_vagrants(ctx, name)

    command = ['vagrant'] + command

    log.debug("Running on %s: %s", name, command)

    if 'reload' in command:
        msg = click.style((
            "'reload' sometimes leave the instance stopped! You may need to `boxer v %s -c up` if it does not "
            "start on its own."
        ), fg='yellow')
        log.warning(msg, name)

    orig_cwd = os.getcwd()
    try:
        os.chdir(vagrant_dir)

        """
        This got more complicated than I thought it would.
        If --log-file, save the output to a file. return a BoxerClickReturn with only the exit code
        Else if we are running as a library (like as part of lifeguard), return a BoxerClickReturn with the output
        Else, send the output to stdout. return a BoxerClickReturn with only the exit code
        """
        if log_file:
            exit_code = subprocess.call(command, env=os.environ, stderr=subprocess.STDOUT, stdout=log_file)
            return BoxerClickReturn(returncode=exit_code)
        elif boxer_config.get('library'):
            try:
                result = subprocess.check_output(command, env=os.environ, stderr=subprocess.STDOUT)
                return BoxerClickReturn(output=result, returncode=0)
            except subprocess.CalledProcessError as e:
                return BoxerClickReturn(output=e.output, returncode=e.returncode)
        else:
            exit_code = subprocess.call(command, env=os.environ)
            if with_exit:
                ctx.exit(exit_code)
            else:
                return BoxerClickReturn(returncode=exit_code)
    finally:
        os.chdir(orig_cwd)
