import json
import logging
import os
import os.path
import subprocess
import tempfile

import click
import which
import yaml

from boxer import config
from boxer.cli import cli
from boxer.click_lib import BoxerClickReturn, click_command, create_packer_variables, distro_type, fail
from boxer.commands.upload_box import upload_box
from boxer.lib import get_box_filename

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option('--packer-args', '--args')
@click.option('--build-num')  # todo: check env for this
@click.option('--distro', type=distro_type, default=config.DEFAULT_DISTRO)
@click.option('--env', default=config.DEFAULT_UBER_ENV)
@click.option('--interactive/--no-interactive', default=False)
@click.option('--with-mark-latest/--no-mark-latest', default=False)
@click.option('--owner-email', envvar='UBER_OWNER')  # todo: read UBER_OWNER env variable
@click.option('--packer-json')  # todo: use click file types
@click.option('--prefix', help='Image name prefix', default='uber')
@click.option(
    '--providers',
    default=','.join(config.DEFAULT_PROVIDERS),
    help='comma-separated list of providers to build. choices: %s' % ", ".join(config.VALID_PROVIDERS)
)
@click.option('--puppet-ref', help='NOT YET SUPPORTED')
@click.option('--role', default=config.DEFAULT_UBER_ROLE)
@click.option('--services', default='')
@click.option('--var-file', type=click.Path(exists=True))
@click.option('--with-upload/--no-upload', default=False)
@click.pass_context
# todo: option to build the instance in the VPC
# todo: use more of clicks features to prompt for values
def packer(
    ctx, args, build_num, distro, env, interactive, owner_email, packer_json, prefix, puppet_ref, role,
    services, var_file, providers, with_mark_latest, with_upload,
):
    """Build a box with packer for vagrant to use.

    :ref:`Read the detailed docs <creating_a_box>`. **tl;dr;**::

        \b
        boxer packer --providers aws --interactive
    """
    # make sure packer is installed
    which.which('packer')

    boxer_config = ctx.find_object(config.BoxerConfig)

    if packer_json is None:
        packer_json = os.path.join(config.PACKER_DATA_DIR, 'templates', "%s.json" % distro)

    log.info("Providers: %s", providers)
    for p in providers.split(','):
        output_dir = os.path.join(config.BOXER_ROOT, 'output-%s' % p)
        if os.path.exists(output_dir):
            if interactive:  # pragma: no cover
                log.warning(click.style("'%s' already exists. Packer may fail", fg='magenta'), output_dir)
                message = click.style("Are you sure you want continue with this directory in place?", fg='yellow')
                click.confirm(message, abort=True)
            else:
                fail(ctx, msg="%s already exists and would be in the way of the packer build" % output_dir)

    services_file = tempfile.NamedTemporaryFile(delete=False)
    services_file.write(yaml.safe_dump(services, encoding='utf-8', allow_unicode=True, default_flow_style=False))
    services_file.close()

    if var_file:
        var_file_temp = None
    else:
        var_file_data = create_packer_variables(
            build_num=build_num,
            click_ctx=ctx,
            env=env,
            interactive=interactive,
            owner_email=owner_email,
            prefix=prefix,
            role=role,
            services_file=services_file.name,
        )

        var_file_temp = tempfile.NamedTemporaryFile(delete=False)
        var_file_temp.write(json.dumps(var_file_data))
        var_file_temp.close()

        var_file = var_file_temp.name

    if not os.path.exists(packer_json):
        fail(ctx, msg="Could not find '%s'" % packer_json)

    if puppet_ref and puppet_ref != 'origin/master':
        # todo: inject custom puppet ref with modify_packer_json.py
        raise NotImplementedError("Installing custom puppet manifests is not currently supported.")

    cmd = [
        'packer',
        'build',
    ]
    if providers:
        cmd.append('-only=%s' % providers)
    if args:
        cmd.append(args)
    cmd.extend([
        "-var-file=%s" % var_file,
        packer_json,
    ])
    # todo: make these part of the var_file_data
    os.environ['BOXER_DATA_DIR'] = config.BOXER_DATA_DIR
    os.environ['BOXER_HOME_DIR'] = boxer_config.get('BOXER_HOME')  # todo: be consistent with _DIR
    subprocess.check_call(cmd, env=os.environ)

    if var_file_temp:
        os.unlink(var_file)

    # todo: upload the boxes to s3/show the command to upload the boxes to s3
    # todo: show the build_num/providers to specify when running `$0 vagrant`
    built_boxes = []
    for p in providers.split(','):
        box_name = get_box_filename(
            env=var_file_data['uber_environment'],
            distro=distro,
            num=var_file_data['image_build_num'],
            prefix=var_file_data['image_name_prefix'],
            provider=p,
            role=var_file_data['uber_role'],
        )
        log.info('Finished building box with packer: %s', box_name)
        built_boxes.append(box_name)

        if with_upload:
            result = ctx.invoke(upload_box, box_name=box_name, with_mark_latest=with_mark_latest)
            if not result:
                fail(ctx, msg="Failed uploading box: %s" % box_name)

    return BoxerClickReturn(output=built_boxes)
