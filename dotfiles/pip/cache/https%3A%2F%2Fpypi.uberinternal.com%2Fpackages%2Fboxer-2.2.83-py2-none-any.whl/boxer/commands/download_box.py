import logging
import os
import os.path
import subprocess

import click
import yaml
import which

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail, is_local_vagrant_or_fail, provider_type
from boxer.lib import is_box_installed

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.argument('provider', type=provider_type)
@click.option('--box-name')
@click.option('--box-urls', nargs=-1)
@click.option('--force', default=None, is_flag=True)
@click.option('-n', '--num-connections', default=4)
@click.option('--with-add/--no-add', default=True)
@click.pass_context
def download_box(ctx, name, provider, box_name, box_urls, force, num_connections, with_add):
    """Download a Vagrant box from S3.

    Using axel is much more reliable than using vagrant's downloader, especially with large boxes (e.g. virtualbox and
    vmware boxes).

    The S3 download links in your boxes.yaml will expire after 24 hours. If you don't plan on launching the instance
    soon after running `boxer vagrant` but do plan on using the box eventually, you should run the
    ``boxer download_box`` commands from ``boxer vagrant``'s output now.

    For example::

        \b
        boxer download_box $VAGRANTNAME aws
    """
    name = is_local_vagrant_or_fail(ctx, name, force=force)

    # todo: support multiple boxes
    boxer_config = ctx.find_object(config.BoxerConfig)

    # make sure axel is installed
    which.which('axel')

    # todo: make sure box_name and box_urls or both set or neither is set
    if not box_name and not box_urls:
        # load the config
        boxes_yaml_filename = os.path.join(boxer_config.get('VAGRANT_ROOT'), name, 'boxes.yaml')
        log.debug("Loading %s", boxes_yaml_filename)
        if not os.path.exists(boxes_yaml_filename):
            fail(ctx, msg="Could not find '%s'" % boxes_yaml_filename)
        with open(boxes_yaml_filename, 'r') as f:
            box_config = yaml.safe_load(f)

        # get the box_name to check if the box is already in vagrant
        box_name = box_config[0][':box']
        if not force and is_box_installed(box_name, provider):
            log.info("This box has already been added to vagrant")
            return True

        box_urls = box_config[0][':box_urls'][provider]

    with boxer_lock(ctx, 'download_box-%s-%s' % (box_name, provider)):
        # get the box url for downloading
        # todo: handle expired download links
        # todo: handle the box file already existing in a better way
        box_found = False
        local_filepath = None
        for box_url in box_urls:
            if box_url.startswith('/'):
                local_filepath = box_url
                if os.path.exists(box_url) and not os.path.exists(box_url + '.st'):
                    # i don't love this
                    log.info("File is already downloaded")
                    box_found = True
                    break
            elif box_url.startswith('http'):
                log.info("Downloading %s box for %s with %d connections", provider, name, num_connections)
                log.info(
                    click.style(
                        "If this fails, restart it with `boxer download_box %s %s`",
                        fg='blue',
                    ),
                    name,
                    provider,
                )

                box_dir = boxer_config.get('BOX_DIR')

                if os.path.isfile(box_dir):
                    log.warning("Cleaning up broken box download")
                    os.unlink(box_dir)

                if not os.path.exists(box_dir):
                    os.makedirs(box_dir)

                subprocess.check_call([
                    'axel',
                    '-a',
                    '-n', str(num_connections),
                    '-o', box_dir,
                    box_url,
                ], env=os.environ)

                box_found = True
                break

        if not box_found:
            fail(ctx, msg="Failed finding boxes for axel: %s" % ", ".join(box_urls))

        if with_add:
            if not local_filepath:
                fail(ctx, msg="Unable to find downloaded box at %s" % local_filepath)

            # this makes Bryan sad
            if provider == 'vmware':
                real_provider = 'vmware_desktop'  # boxes get added with vmware_DESKTOP
            else:
                real_provider = provider

            command = [
                'vagrant',
                'box',
                'add',
                '--name', box_name,
                '--provider', real_provider,
                local_filepath,
            ]
            if force:
                command.append('--force')

            log.debug("Running command: %s", command)
            subprocess.check_call(command, env=os.environ)

    log.info("Finished downloading %s box for %s", provider, name)
    return BoxerClickReturn(output=True)
