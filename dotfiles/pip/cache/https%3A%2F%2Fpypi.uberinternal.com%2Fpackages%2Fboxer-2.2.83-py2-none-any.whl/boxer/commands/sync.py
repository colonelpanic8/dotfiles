import collections
import glob
import logging
import os
import subprocess
import sys
import time

import click
import which
import yaml

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail
from boxer.commands.ssl import fetch_dev_ssl
from boxer.lib import fqdn_from_name

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name_or_fqdn')  # todo: make a type for this that uses --default-domain?
@click.argument('remote_paths', nargs=-1)  # todo: make this work
@click.option('--additional-ignores', help=":-delimited list of things to ignore")
@click.option('--default-domain', default=config.DEFAULT_DOMAIN)  # don't restrict
@click.option('--fast-check/--no-fast-check', default=False)
@click.option('--force/--interactive', default=False)
@click.option('--ignore-archives/--no-ignore-archives', default=False)
@click.option('--interactive/--no-interactive', default=False)
@click.option('--prefer', default=None, type=click.Choice(['local', 'remote']))
@click.option('--repeat', default=1)  # todo: allow 'watch' or ints
@click.option('--user')
@click.option('--with-fetch-ssl/--no-fetch-ssl', default=True)
@click.option('--with-last-sync/--no-last-sync', default=True)
@click.option('--with-repeat/--no-repeat', default=True)
@click.pass_context
def sync(
    ctx, additional_ignores, default_domain, fast_check, force, ignore_archives, interactive, name_or_fqdn, prefer,
    remote_paths, repeat, user, with_fetch_ssl, with_last_sync, with_repeat,
):
    """Use unison for two-way syncing of code.

    While Vagrant provides synced folders, they don't work for us very well. To make it easy to develop remote code on
    any vagrant (started by you or someone else) with a local editor, this command was written.

    It will download code from the vagrant's ``/home/`` to a namespaced directory in ``$UBER_HOME/sync/`` and keep it in
    sync with Unison.

    It is not designed to copy local directories to your vagrant. There is no backgrounding or auto-start magic.

    .. WARNING::

        Git submodules do not sync well. If your project uses submodules, you will have to do your commits on the
        vagrant side and not from your mac.

    Sync lets you sync one or more directories from the remote ``/home``::

        \b
        boxer sync $VAGRANTNAME uber/api uber/dispatch uber/kodenom

    Once you run sync with several directories, it will remember for you. Running sync again after running the above
    command would still sync ``uber/api`` ``uber/dispatch`` and ``uber/kodenom``::

        \b
        boxer sync $VAGRANTNAME
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    if name_or_fqdn.endswith('.dev'):
        log.warning("You shouldn't be syncing to NAME.dev! Just use NAME")
        # name_or_fqdn += '.uber.com'  # todo: this isn't safe! we should move the existing files and maybe clear archives

    fqdn = fqdn_from_name(name_or_fqdn, default_domain=default_domain)

    # make sure unison is installed
    which.which('unison')

    with boxer_lock(ctx, 'sync-%s' % fqdn):
        remote_dir = '/home'

        sync_root = boxer_config.get('boxer_sync_root')

        # todo: use vagrant ssh-config instead of relying on DNS
        if user:  # pragma: no cover
            remote_root_dir_str = "ssh://{user}@{fqdn}/{remote_dir}"
        else:
            remote_root_dir_str = "ssh://{fqdn}/{remote_dir}"
        remote_root_dir = remote_root_dir_str.format(
            user=user,
            fqdn=fqdn,
            remote_dir=remote_dir,
        )

        local_root_dir = ctx.invoke(
            sync_dir,
            name_or_fqdn=fqdn,
            default_domain=default_domain,
            print_dir=False,
        ).output

        if not os.path.exists(local_root_dir):
            os.makedirs(local_root_dir)

        if with_fetch_ssl:
            success = ctx.invoke(fetch_dev_ssl, name_or_fqdn=name_or_fqdn, force=force)
            if not success:
                fail(ctx, msg="Failed to fetch dev SSL certificates")

        unison_profile_dir = os.path.expanduser("~/.unison/")
        if not os.path.exists(unison_profile_dir):  # pragma: no cover
            os.makedirs(unison_profile_dir)

        last_remote_paths_filename = os.path.join(sync_root, "{}.remote_paths".format(fqdn))

        hostname = fqdn.split('.')[0]
        # In the case where you have multiple boxes defined in a boxes.yaml, the
        # hostname may not be in the path. We need to scan all the box configs for
        # a host config that matches the hostname
        boxes_yaml_filenames = glob.glob(os.path.join(boxer_config.get('VAGRANT_ROOT'), '*', 'boxes.yaml'))

        # if not remote paths are listed explicitly, check the last synced dirs
        if not remote_paths:
            try:
                if not with_last_sync:
                    log.debug("Skipping reading %s" % last_remote_paths_filename)
                else:
                    with open(last_remote_paths_filename, 'r') as f:
                        remote_paths = f.readlines()
                if not remote_paths:
                    raise Exception("no remote paths loaded from %s", last_remote_paths_filename)
            except Exception:  # todo: catch the right exception
                # still no remote_paths found. check all the yaml files for the given hostname
                for boxes_yaml_filename in boxes_yaml_filenames:
                    log.debug("Loading %s", boxes_yaml_filename)
                    if not os.path.exists(boxes_yaml_filename):
                        fail(ctx, msg="Could not find '%s'" % boxes_yaml_filename)
                    with open(boxes_yaml_filename, 'r') as f:
                        box_config = yaml.safe_load(f)

                    for host_config in box_config:
                        if host_config.get(':hostname') == hostname:
                            log.debug("Found matching remote_paths for hostname %s", hostname)
                            remote_paths = host_config.get(':remote_paths', ['uber/api'])
                            break

        # sometimes we can't find any defaults
        if not remote_paths:
            remote_paths = ['uber/api']

        log.info("Syncing path(s) %s to %s/", " ".join((r.strip() for r in remote_paths)), local_root_dir)

        for remote_path in remote_paths:
            if remote_path.startswith('/'):
                fail(ctx, msg="Invalid path '%s'. Paths must be relative to '%s'" % (remote_path, remote_dir))

        with open(last_remote_paths_filename, 'w') as f:
            for remote_path in remote_paths:
                if remote_path.endswith('\n'):
                    f.write(remote_path)
                else:
                    f.write("%s\n" % remote_path)

        ignores = [
            # 'Name *.po',  # todo: ignore once we change it to not ignore ones that are in tests and checked into git
            'Name *.po.md5',
            'Name *.pyc',
            'Name *~',
            'Name .*.swp',
            'Name .*~',
            'Name ._*',
            'Name .DS_Store',
            'Name .localized',
            'Name celerybeat-schedule',
            'Name {.idea}',
            'Name {.tox}',
            'Name {env}',
            'Name {node_modules}',
            'Name {pyenv}',
            # do not ignore the following
            # 'Name {snapshots}',  # no need to ignore this since things go in /mnt.  It also makes us skip a .gitignore
        ]

        if additional_ignores:
            ignores += additional_ignores.split(':')

        unison_config = {
            'auto': 'true',
            'confirmbigdel': 'true',
            'ignore': ignores,
            'path': remote_paths,
            # 'perms': '0',  # doing this causes more problems than it fixes
            'root': [
                local_root_dir,
                remote_root_dir,
            ],
            'sshargs': '-C',
            'terse': 'true',
            'times': 'true',
        }
        unison_config_filename = os.path.join(unison_profile_dir, "{fqdn}.prf".format(fqdn=fqdn))

        log.debug("Saving unison profile to %s", unison_config_filename)
        with open(unison_config_filename, 'w') as f:
            for key, value in unison_config.iteritems():
                if isinstance(value, basestring):
                    f.write("{} = {}\n".format(key, value))
                elif isinstance(value, collections.Iterable):
                    for v in value:
                        f.write("{} = {}\n".format(key, v))
                else:
                    fail(ctx, msg="Invalid unison config for %s" % key)

            if os.path.exists(os.path.join(unison_profile_dir, "custom.include")):
                f.write("include custom.include")

        # todo: print contents of unison_config_filename

        # do the initial sync
        unison_batch_command = ['unison', fqdn, '-ui', 'text']

        if not interactive:
            unison_batch_command.append('-batch')

        if ignore_archives:
            unison_batch_command.append('-ignorearchives')

        unison_batch_command.append('-fastcheck')
        if fast_check:
            unison_batch_command.append('true')
        else:
            unison_batch_command.append('false')

        if prefer:
            unison_batch_command.append('-prefer')
            if prefer == 'local':
                unison_batch_command.append(local_root_dir)
            elif prefer == 'remote':
                unison_batch_command.append(remote_root_dir)
            else:
                fail(ctx, msg="Must prefer either local or remote, not '%s'" % prefer)

        try:
            subprocess.check_call(unison_batch_command, env=os.environ)
        except subprocess.CalledProcessError:
            log.error(click.style("Oh no! An error was detected while syncing!", fg='red'))

            they_said_yes = False

            if click.confirm(click.style(
                "Was the error about mismatched versions of unison or 'bad bigarray kind'?",
                fg='yellow',
            )):
                they_said_yes = True
                click.launch('https://engdocs.uberinternal.com/boxer/troubleshooting.html#mismatched-unison-versions')
                fail(ctx, msg="Follow the \"MISMATCHED UNISON VERSIONS\" troubleshooting steps and then try again")

            if click.confirm(click.style(
                    "Was the error about inconsistent state or did it recommend '-ignorearchives'?",
                    fg='yellow',
            )):
                they_said_yes = True
                log.info("Re-running sync with --ignore-archives")
                ignore_archives = True

            if click.confirm(click.style(
                ("Was the error about skipped files, change conflicts, 'fast update detection' or 'No updates to "
                 "propagate'? (hint, the answer is probably yes)"),
                fg='yellow',
            )):
                they_said_yes = True

                valid_answers = {
                    1: (None, 'ask me for each file'),
                    2: ('remote', ("prefer the remote file (hint: if you have done work on remote but not local, this is "
                                   "probably what you want)")),
                    3: ('local', ("prefer the local file (hint: if you have changed work on local but not remote, this "
                                  "is probably what you want)")),
                }

                click.echo('')
                for key, (_, helptext) in sorted(valid_answers.iteritems()):
                    click.echo("{}: {}".format(key, helptext))
                click.echo('')

                try:
                    answer = click.prompt("When conflicts are detected, what should sync prefer? [1,2,3] ", type=int)
                except EOFError:
                    # add a newline, for output clarity and consistency.
                    click.echo('')
                if not answer or answer not in valid_answers:
                    log.error("Invalid answer given. Raising original exception")
                    raise

                prefer = valid_answers[answer][0]

            if not they_said_yes:
                log.error(click.style("No yes answers given. Raising original exception", fg='red'))
                raise

            log.info(click.style("Press ? for help inside unison", fg='blue'))

            return ctx.invoke(
                sync,
                name_or_fqdn=fqdn,
                remote_paths=remote_paths,
                repeat=repeat,
                fast_check=False,
                ignore_archives=ignore_archives,
                interactive=True,
                prefer=prefer,
            )

        if repeat == 'watch' and sys.platform == 'darwin':
            log.warning(click.style("unison file watching seems to be broken on OS X", fg='red'))

        unison_repeat_command = ['unison', fqdn, '-repeat', str(repeat), '-ui', 'text']

        # check for changes every 2 seconds
        # todo: "-repeat watch" does not seem to work :'(
        while with_repeat:  # pragma: no cover
            log.info(
                click.style(
                    "Running '%s'. This will be silent until files change on either side. [ctrl + c] to exit",
                    fg='blue',
                ),
                " ".join(unison_repeat_command),
            )
            try:
                subprocess.check_call(unison_repeat_command, env=os.environ)
            except subprocess.CalledProcessError as e:
                if e.returncode == 3:
                    log.warning(click.style(
                        "An error was detected. This likely means ssh was interrupted. Restarting in a second",
                        fg='yellow',
                    ))
                    time.sleep(1)
                else:
                    raise


@click_command(group=cli)
@click.argument('name_or_fqdn')  # todo: make a type for this that uses --default-domain?
@click.option('--default-domain', default=config.DEFAULT_DOMAIN)  # don't limit this to our choices
@click.option('--print-dir/--no-print-dir', default=True)
@click.pass_context
def sync_dir(ctx, name_or_fqdn, default_domain, print_dir):
    """Print the directory used by ``boxer sync``.

    :param str name_or_fqdn: The name of the vagrant or a fully qualified domain name.
    :param str default_domain: The domain name to use if a vagrant name is given rather than a fqdn.
    :param boot print_dir: If true, echo the directory to stdout instead of only returning it

    This can be useful when used by some shell functions like these::

        \b
        cdsync () {
            cd $(boxer sync_dir $@)
        }
        editsync () {
            $EDITOR $(boxer sync_dir $@)
        }
        opensync () {
            open $(boxer sync_dir $@)
        }
    """

    """
    if name_or_fqdn.endswith('.dev'):
        name_or_fqdn += '.uber.com'
    """

    fqdn = fqdn_from_name(name_or_fqdn, default_domain=default_domain)

    sync_root = ctx.find_object(config.BoxerConfig).get('boxer_sync_root')

    sd = os.path.join(sync_root, fqdn, 'home')

    if print_dir:
        click.echo(sd)
    return BoxerClickReturn(output=sd)
