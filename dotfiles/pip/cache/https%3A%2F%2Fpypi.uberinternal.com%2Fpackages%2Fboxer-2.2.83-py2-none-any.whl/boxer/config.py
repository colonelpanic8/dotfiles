# todo: better order for this file
# this file might better be named constants instead of config
# this file is loaded before loggers are configured
# todo: import time logic is evil! build a config object inside boxer.cli.cli for tests to work
import logging
import os
import os.path
import sys
import yaml


BOXER_ROOT = os.path.dirname(os.path.realpath(__file__))

BOXER_DATA_DIR = os.path.join(BOXER_ROOT, 'data')

PACKER_DATA_DIR = os.path.join(BOXER_DATA_DIR, 'packer')
PUPPET_INCLUDE_DIR = os.path.join(BOXER_DATA_DIR, 'puppet_includes')
VAGRANT_DATA_DIR = os.path.join(BOXER_DATA_DIR, 'vagrant')

BASE_VAGRANTFILE = os.path.join(VAGRANT_DATA_DIR, 'Vagrantfile')


AWS_INSTANCE_TYPES = [
    't1.micro',
    'm1.small',
    'm3.2xlarge',
    'm3.large',
    'm3.medium',
    'm3.xlarge',
    'm3.2xlarge',
    'c3.xlarge',
    'c3.4xlarge',
    'c3.8xlarge',
    'r3.xlarge',
    'r3.2xlarge',
    'r3.8xlarge',
    'g2.2xlarge',
    'i2.2xlarge',
    'i2.8xlarge',
    'hs1.8xlarge',
]  # was boto.ec2.buyreservation.InstanceTypes but that is too many
DEFAULT_AWS_DISK_SIZE = 280
DEFAULT_AWS_MNT_SIZE = 0
DEFAULT_AWS_TYPE = 'm3.xlarge'
HVM_ONLY_INSTANCE_TYPES = [
    'g2',
    'i2',
    'r3',
]

AWS_REGIONS = [
    'ap-southeast-1',
    'eu-west-1',
    'us-east-1',
    'us-west-1',
    'us-west-2',
]  # was [r.name for r in boto.ec2.regions()]
DEFAULT_AWS_REGION = 'us-west-2'

DEFAULT_DISTRO = 'precise'

VALID_DISTROS = [
    'precise',
    'squeeze',
]

DEFAULT_PROVIDER = 'aws'
DEFAULT_PROVIDERS = [
    'aws',
]
VALID_PROVIDERS = [
    'aws',
    'virtualbox',
    'vmware',
]

# todo: this isn't great
DEFAULT_DOMAIN = 'dev.uber.com'
VALID_DOMAINS = [
    'dev.uber.com',
    'local',
]
PROVIDER_DOMAIN_MAP = {
    'aws': DEFAULT_DOMAIN,
    'virtualbox': 'local',
    'vmware': 'local',
}

VAGRANT_COLS = [
    'days_up',
    'instance_id',
    'instance_type',
    'ip_address',
    'last_puppet',
    'launch_time',
    'name',
    'owner',
    'region',
]

DEFAULT_AWS_KEYPAIR = 'uber-root-20120131'
DEFAULT_SSH_KEYS = '~/.ssh/uberdev,~/.ssh/uber_rsa,~/.ssh/id_rsa'

DEFAULT_UBER_ENV = 'development'
VALID_UBER_ENV = [
    'development'
]

DEFAULT_UBER_ROLE = 'devserver'

BAD_VAGRANT_VERSIONS = [
    '1.6.0',
    '1.6.1',
]
MIN_VAGRANT_VERSION = '1.6.3'
MAX_VAGRANT_VERSION = None

VAGRANT_PLUGINS = [
    'unf',
    'vagrant-aws',
    'vagrant-triggers',
    'vagrant-vbguest',
    'vagrant-vbox-snapshot',
    'vagrant-vmware-fusion',
]


log = logging.getLogger(__name__)


class BoxerConfig(object):

    def __init__(self, boxer_home=None, filename=None, library=False):
        if boxer_home is None:
            boxer_home = os.path.realpath(os.environ.get('BOXER_HOME', os.path.expandvars('$HOME/.boxer')))

        # log.debug("BOXER_HOME: %s", boxer_home)
        # log.debug("VAGRANT_HOME: %s", os.environ.get('VAGRANT_HOME'))

        # defaults go here
        self.data = {
            'aws_access_key': 'AKIAJTBIRQRMVRHXZCDA',  # todo: keep these out of git. maybe use ~/.boto
            'aws_secret_key': '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',  # todo: keep these out of git. maybe use ~/.boto
            'aws_vpc_subnets': {
                'us-west-2': {
                    'us-west-2a': 'subnet-e4382a90',
                    'us-west-2b': 'subnet-4c53a129',
                    'us-west-2c': 'subnet-d2794494',
                }
            },
            'aws_vpc_security_groups': {
                'us-west-2': ['sg-a45889c1'],
            },
            'boxer_home': boxer_home,
            'dev_ssl_certificate': 'devstar.uber.com.crt',
            'library': library,
            's3_bucket': 'uber-packer',
        }

        # load config overrides from an optional file
        if not filename:
            # load boxer.yaml to override config
            # this works, but it is silly and fragile. we should use a real config object
            filename = os.path.join(boxer_home, 'boxer.yaml')
        if os.path.exists(filename):
            with open(filename) as f:
                self.data.update(yaml.safe_load(f))

        # variables that use the above variables. this is too complicated
        if 'boxer_sync_root' not in self.data:
            if 'BOXER_SYNC_ROOT' in os.environ:
                boxer_sync_root = os.path.realpath(os.path.expanduser(os.environ['BOXER_SYNC_ROOT']))
            elif 'UBER_HOME' in os.environ:
                boxer_sync_root = os.path.join(os.path.realpath(os.path.expanduser(os.environ['UBER_HOME'])), 'sync')
            else:
                print >> sys.stderr, "Neither BOXER_SYNC_ROOT nor UBER_HOME are set. Defaulting BOXER_SYNC_ROOT to cwd."
                boxer_sync_root = os.getcwd()
            self.data['boxer_sync_root'] = boxer_sync_root

        # variables that use the above variables
        if 'box_dir' not in self.data:
            self.data['box_dir'] = os.path.join(boxer_home, 'boxes')
        if 'vagrant_root' not in self.data:
            self.data['vagrant_root'] = os.path.join(boxer_home, 'vagrants')
        if 'packer_cache_dir' not in self.data:
            self.data['packer_cache_dir'] = os.path.join(boxer_home, 'packer_cache')

        # override environment variables
        # todo: I hate setting the environ here
        # move Packer cache out of the way
        os.environ['PACKER_CACHE_DIR'] = self.data['packer_cache_dir']

    def get(self, value):
        return self.data[value.lower()]
