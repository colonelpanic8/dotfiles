import datetime
import hashlib
import os
import socket

from moto import mock_s3, mock_ec2
import boto
import click
import click.testing
import pytest

from boxer import config
from boxer.cli import cli
from boxer.click_lib import get_box_filename
from boxer.exc import LifeguardPoolEmpty


TEST_ROOT = os.path.dirname(__file__)


def _default_return(*args, **kwargs):
    """Helper for monkeypatch/mock to return default kwarg."""
    default = kwargs.get('default', None)
    return default


@pytest.fixture
def ctx():
    """A click.Context with our BoxerConfig attached to ctx.obj."""
    # todo: get the context out of click_runner
    ctx = click.Context(click.Command)
    ctx.obj = config.BoxerConfig(filename=os.path.join(TEST_ROOT, 'config.yaml'))
    return ctx


@pytest.fixture
def click_runner():
    """A click.testing.CliRunner."""
    return click.testing.CliRunner()


@pytest.fixture(scope='function')
def random_name(click_runner):
    hostname = socket.gethostname()
    now = datetime.datetime.utcnow().isoformat()
    pid = str(os.getpid())
    hashed = hashlib.sha1(hostname + now + pid).hexdigest()[:8]
    return "boxer-test-%s" % (hashed)


def test_bootstrap_and_cleanup(click_runner, monkeypatch, tmpdir):
    print "Bootstrapping in tmpdir '%s'" % (tmpdir, )

    # use a temporary directory for BOXER_HOME so this can run in parallel with other tests
    # todo: this doesn't seem to be enough
    monkeypatch.setenv('BOXER_HOME', tmpdir.join('boxer').mkdir())

    # use a temporary directory for vagrant so this can run in parallel with other tests
    monkeypatch.setenv('VAGRANT_HOME', tmpdir.join('vagrant').mkdir())

    # todo: use a real mock here so we can make sure the right things were called
    monkeypatch.setattr('subprocess.check_call', lambda *args, **kargs: None)

    result = click_runner.invoke(
        cli,
        ['bootstrap', '--force'],
    )
    print 'bootstrap:', result.output.strip()
    assert result.exit_code == 0

    # todo: I should test this by itself, too, but I want to make sure the dummy box exists
    # todo: this function could probably be named better
    # todo: this function seems to be listing the boxes installed in ~/.boxer instead of our tmpdir :'(
    result = click_runner.invoke(
        cli,
        ['remove_unused_boxes'],
    )
    print 'remove_unused_boxes:', result.output.strip()
    assert result.exit_code == 0


# todo: mock s3
@pytest.long_running_test
@pytest.mark.timeout(1800)
def test_creation_flow(click_runner, ctx, monkeypatch, random_name):
    """Test checking existing, creating, launching, SSH, and then deleting."""
    email = 'bryan+boxertest@uber.com'
    aws_region = 'us-east-1'
    aws_zone = 'a'
    aws_type = 'm3.large'

    # todo: should we use tmpdir for BOXER_HOME and VAGRANT_HOME?

    # a parameterized test doesn't really make sense here since we just need one role tested to get good coverage
    role = os.environ.get('PYTEST_BOXER_ROLE', 'base')

    monkeypatch.setattr("boxer.commands.ssl.revoke_trust_ssl_certificate", _default_return)
    monkeypatch.setattr("boxer.commands.ssl.trust_ssl_certificate", _default_return)

    def mock_claim_vagrant(*args, **kwargs):
        raise LifeguardPoolEmpty("Pool closed for testing")
    monkeypatch.setattr("boxer.commands.vagrant.claim_vagrant", mock_claim_vagrant)

    # todo: does click passes through defaults automatically?
    monkeypatch.setattr("boxer.commands.create_vagrant.click.edit", _default_return)

    # bootstrap hits the network and is known to be flappy. try it twice like setup-uber-home and don't assert success
    # force could break other users of boxer
    result = click_runner.invoke(cli, [
        'bootstrap',
    ])
    print 'bootstrap:', result.output.strip()
    if result.exit_code != 0:
        result = click_runner.invoke(cli, [
            'bootstrap',
        ])
        print 'bootstrap:', result.output.strip()
        # assert result.exit_code == 0

    try:
        print "Creating vagrant %s" % random_name
        result = click_runner.invoke(cli, [
            'vagrant',
            '--aws-region', aws_region,
            '--aws-type', aws_type,
            '--aws-zone', aws_zone,
            '--check-existing',
            '--email', email,
            '--name', random_name,
            '--no-bootstrap-puppet',  # not running puppet saves us a lot of time
            '--no-ssh',  # todo: would be cool to have True here and then send 'exit'
            '--providers', ','.join(config.VALID_PROVIDERS + ['invalid_provider']),
            '--role', role,
            '--try-claim-vagrant',  # this is mocked to fail
            '--try-create-vagrant',
            '--with-launch',
            '--with-ssl',
        ])
        print 'vagrant:', result.output.strip()
        assert result.exit_code == 0

        # todo: we should probably have certs on more than just devserver
        if role == 'devserver':
            # todo: assert that the certificate is local
            pass

        # todo: maybe test update with termination?

        print "Exporting vagrant %s" % random_name
        result = click_runner.invoke(cli, [
            'export_vagrant', random_name, '--delete-local',
        ])
        print 'export_vagrant:', result.output.strip()
        assert result.exit_code == 0

        """
        # todo: add a flag that won't allow renaming. this test doesn't work now that we auto-rename
        print "Creating an instance with a duplicate name remote (should fail)"
        result = click_runner.invoke(cli, [
            'vagrant',
            '--check-existing',
            '--email', email,
            '--force',
            '--name', random_name,
            '--no-claim-vagrant',  # this is mocked to fail
            '--role', role,
            '--try-create-vagrant',
        ])
        print 'vagrant:', result.output.strip()
        assert result.exit_code == 2
        # todo: check the output
        """

        # todo: how do we do this now that we don't have the context?
        # assert random_name not in get_current_vagrants(ctx)

        print "Importing vagrant %s" % random_name
        result = click_runner.invoke(cli, [
            'import_vagrant', random_name, '--delete-remote',
        ])
        print 'import_vagrant:', result.output.strip()
        assert result.exit_code == 0

        # make sure calling create without --update when it already exists. bail
        print "Creating an instance with a duplicate name local (should fail)"
        result = click_runner.invoke(cli, [
            'vagrant',
            '--email', email,
            '--force',
            '--name', random_name,
            '--no-check-existing',
            '--no-claim-vagrant',
            '--role', role,
            '--try-create-vagrant',
        ])
        print 'vagrant:', result.output.strip()
        assert result.exit_code == 2

        # todo: these don't fail properly on jenkins. they just provision instead
        """
        print "Up-ing an instance while it is already up #1 (should fail)"
        result = click_runner.invoke(cli, [
            'v', random_name, '-c', 'up', '--check-existing',
        ])
        print 'v:', result.output.strip()
        assert result.exit_code == 1

        print "Up-ing an instance while it is already up #2 (should fail)"
        result = click_runner.invoke(cli, [
            'v', random_name, '-c', 'up --provider=aws', '--check-existing',
        ])
        print 'v:', result.output.strip()
        assert result.exit_code == 1

        print "Up-ing an instance while it is already up #3 (should fail)"
        result = click_runner.invoke(cli, [
            'v', random_name, '-c', 'up --provider aws', '--check-existing',
        ])
        print 'v:', result.output.strip()
        assert result.exit_code == 1
        """

        # todo: make sure region and aws_type hasn't changed

        print "Checking aws console for %s" % random_name
        result = click_runner.invoke(cli, [
            'aws', 'console', random_name,
        ])
        print 'aws console:', result.output.strip()
        assert result.exit_code == 0

        # todo: aws stop... sleep... aws start? thats kinda just testing boto.

        # todo: make sure the ssl certs are local

        print "Testing SSH"
        result = click_runner.invoke(cli, [
            'v', random_name, '-c', 'ssh -- mkdir boxer-test && echo test >boxer-test/test',
        ])
        print 'v -c ssh:', result.output.strip()
        assert result.exit_code == 0

        # todo: re-enable this once unison uses vagrant's ssh-config instead of DNS
        """
        print "Testing sync"
        result = click_runner.invoke(cli, [
            'sync',
            random_name, 'uber/boxer-test',
            '--force',
            '--no-repeat',  # i don't like this flag very much
            '--with-fetch-ssl',
            '--no-dns',  # todo: this flag will need to be added
        ])
        print 'sync:', result.output.strip()
        assert result.exit_code == 0

        # todo: assert boxer-test files synced with the right contents
        """
    finally:
        # run terminate at the end
        terminate_result = click_runner.invoke(cli, [
            'terminate', '--force', random_name,
        ])
        print 'terminate:', result.output.strip()
        assert terminate_result.exit_code in (0, 2)

        # todo: assert that the ssl certificates have been cleaned up

        # todo: make this work
        """
        aws_terminate_result = click_runner.invoke(cli, [
            'aws', 'terminate', random_name,
        ])
        print 'aws terminate:', result.output.strip()
        assert aws_terminate_result.exit_code == 0
        """


def test_default_email_failure(click_runner):
    """Fail on default email."""
    result = click_runner.invoke(cli, [
        'create_vagrant',
        '--name', 'goodname',
        '--no-check-existing',
        '--email', 'email@uber.com',
    ])
    print 'create_vagrant:', result.output.strip()
    assert result.exit_code == 2


def test_default_name_failure(click_runner):
    """Fail on default name."""
    result = click_runner.invoke(cli, [
        'create_vagrant',
        '--name', 'vagrantname',
        '--no-check-existing',
        '--email', 'test@uber.com',
    ])
    print 'create_vagrant:', result.output.strip()
    assert result.exit_code == 2


def test_edits(click_runner, monkeypatch, random_name):
    monkeypatch.setattr("click.edit", _default_return)

    try:
        # todo: maybe this should be a fixture?
        result = click_runner.invoke(cli, [
            'create_vagrant',
            '--name', random_name,
            '--email', 'test@uber.com',
            '--no-check-existing',
            '--no-launch',
        ])
        print 'create_vagrant:', result.output.strip()
        assert result.exit_code == 0

        result = click_runner.invoke(cli, [
            'edit',
            random_name,
        ])
        print 'edit:', result.output.strip()
        assert result.exit_code == 0

        result = click_runner.invoke(cli, [
            'diff',
            random_name,
            'kodenom',
            'D0',
        ])
        print 'diff:', result.output.strip()
        assert result.exit_code == 0

        result = click_runner.invoke(cli, [
            'diff',
            random_name,
            'kodenom',
        ])
        print 'diff:', result.output.strip()
        assert result.exit_code == 0

        # todo: set include_files, custom_includes, and custom_files
        result = click_runner.invoke(cli, [
            'puppet_includes',
            random_name,
        ])
        print 'puppet_includes:', result.output.strip()
        assert result.exit_code == 0
    finally:
        # run terminate at the end
        # todo: seems like this could miss something if unsantization fails...
        terminate_result = click_runner.invoke(cli, [
            'terminate', '--force', random_name,
        ])
        print 'terminate:', result.output.strip()
        assert terminate_result.exit_code in (0, 2)


@mock_ec2
def test_list_vagrants_empty(click_runner):
    """List the puppet includes."""
    result = click_runner.invoke(cli, [
        'list_vagrants',
    ])
    assert result.output.strip() == 'aws_region_name aws_id      ip_address       aws_type    uber_role   launch_time               state         days_up  name                             owner'  # noqa
    assert result.exit_code == 0


@mock_ec2
def test_list_vagrants(click_runner, ec2_conn):
    pytest.mock_create_vagrant(ec2_conn, 'test0')
    pytest.mock_create_vagrant(ec2_conn, 'test1', role=None)
    pytest.mock_create_vagrant(ec2_conn, 'test2', service=None)
    pytest.mock_create_vagrant(ec2_conn, 'test3', aws_placement='us-east-1a')

    result = click_runner.invoke(cli, [
        'list_vagrants',
    ])
    print 'list_vagrants:', result.output.strip()
    assert result.exit_code == 0


def test_long_name_failure(click_runner):
    """Fail on long name."""
    result = click_runner.invoke(cli, [
        'create_vagrant',
        '--name', 'vagrantname_that_will_fail_because_it_is_very_very_very_long',
        '--email', 'test@uber.com',
        '--no-check-existing',
    ])
    print 'create_vagrant:', result.output.strip()
    assert result.exit_code == 2


# todo: sanitize more bad characters
def test_name_sanitization(click_runner, random_name):
    """Test creating and then deleting"""
    email = 'bryan+boxertest@uber.com'
    unsanitized_name = '%s name_sanitization' % random_name
    sanitized_name = '%s-name-sanitization' % random_name
    role = 'base'

    try:
        print "Creating vagrant %s" % sanitized_name
        result = click_runner.invoke(cli, [
            'create_vagrant',
            '--name', unsanitized_name,
            '--email', email,
            '--no-check-existing',
            '--no-launch',
            '--role', role,
        ])
        print 'create_vagrant:', result.output.strip()
        assert result.exit_code == 0

        # todo: confirm that returned name is unsanitized_name (and use it in the terminate)

    finally:
        # run terminate at the end
        # todo: seems like this could miss something if unsantization fails...
        terminate_result = click_runner.invoke(cli, [
            'terminate', '--force', sanitized_name,
        ])
        print 'terminate:', result.output.strip()
        assert terminate_result.exit_code in (0, 2)

        # todo: make this work
        """
        # boto terminate for good measure
        aws_terminate_result = click_runner.invoke(cli, [
            'aws', 'terminate', random_name,
        ])
        assert aws_terminate_result.exit_code == 0
        """


def test_no_email_failure(click_runner):
    """Fail on empty email."""
    result = click_runner.invoke(cli, [
        'create_vagrant',
        '--name', 'goodname',
        '--email', ' ',
        '--no-check-existing',
    ])
    print 'create_vagrant:', result.output.strip()
    assert result.exit_code == 2


def test_non_uber_email_failure(click_runner):
    """Fail on non-uber.com email."""
    result = click_runner.invoke(cli, [
        'create_vagrant',
        '--name', 'goodname',
        '--email', 'email@oober.com',
        '--no-check-existing',
    ])
    print 'create_vagrant:', result.output.strip()
    assert result.exit_code == 2


@mock_s3
def test_packer(ctx, click_runner, monkeypatch, random_name, tmpdir):
    """Make sure everything up to calling packer works."""
    env = 'development'  # todo: would be awesome if we could use "test" here
    distro = config.DEFAULT_DISTRO
    build_num = random_name[-8:]
    providers = config.VALID_PROVIDERS
    prefix = 'test'
    role = 'base'

    boxer_config = ctx.find_object(config.BoxerConfig)

    box_dir = boxer_config.get('box_dir')
    test_files = []

    # todo: this seems like a prime candidate for a fixture
    conn = boto.connect_s3()
    conn.create_bucket(boxer_config.get('s3_bucket'))

    def check_call_return(*args, **kwargs):
        """Create empty box file for each provider."""
        for p in providers:
            box_name = get_box_filename(
                distro=distro,
                env=env,
                num=build_num,
                prefix=prefix,
                provider=p,
                role=role,
            )
            with open(os.path.join(box_dir, box_name), 'w') as f:
                print "Created mock box: %s" % f.name
                test_files.append(f.name)
    monkeypatch.setattr("subprocess.check_call", check_call_return)

    try:
        # todo: pass prefix here
        result = click_runner.invoke(cli, [
            'packer',
            '--build-num', build_num,
            '--distro', distro,
            '--env', env,
            '--interactive',
            '--owner-email', 'test@uber.com',
            '--prefix', prefix,
            '--providers', ','.join(providers),
            '--role', role,
            '--with-mark-latest',
            '--with-upload',
        ])
        print 'packer:', result.output.strip()
        assert result.exit_code == 0
    finally:
        for f in test_files:
            if os.path.exists(f):
                print "Cleaning temp box: %s" % f
                os.unlink(f)

    # todo: assert that files are in s3
    # todo: cleanup local files


def test_sync(click_runner, monkeypatch, random_name):
    """List the puppet includes."""
    monkeypatch.setattr("subprocess.check_call", lambda *args, **kwargs: None)

    result = click_runner.invoke(cli, [
        'sync',
        random_name,
        '--no-fetch-ssl',
        '--no-repeat',
    ])
    print 'sync:', result.output.strip()
    assert result.exit_code == 0
    # todo: actually assert something


def test_list_puppet_includes(click_runner):
    """List the puppet includes."""
    result = click_runner.invoke(cli, [
        'list_puppet_includes',
    ])
    print 'list_puppet_includes:', result.output.strip()
    assert result.exit_code == 0
    # todo: actually assert something


def test_vagrant_nothing(click_runner):
    """Fail on vagrant claim and creation."""
    result = click_runner.invoke(cli, [
        'vagrant',
        '--no-claim-vagrant',
        '--no-create-vagrant',
    ])
    print 'vagrant:', result.output.strip()
    assert result.exit_code == 2
