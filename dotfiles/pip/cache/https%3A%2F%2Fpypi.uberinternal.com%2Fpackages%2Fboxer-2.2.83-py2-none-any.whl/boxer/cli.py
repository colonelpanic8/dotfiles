import logging
import os
import signal

import click

from boxer.config import BoxerConfig
from boxer.lib import check_vagrant_version, signal_handler


log = logging.getLogger(__name__)


# todo: any chance these could cause problems? should they be moved to cli?
signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)


@click.group()
@click.version_option()
@click.option('-c', '--config')
@click.option('--home')
@click.option('-v', '--verbose', default=False, is_flag=True)
@click.option('--with-version-check/--no-version-check', default=True, help="Check the version of Vagrant")
@click.option('--with-configure-log/--no-configure-log', default=True)
@click.option('--library', default=False, is_flag=True)  # todo: key this off standalone_mode instead
@click.pass_context
def cli(ctx, config, home, library, verbose, with_configure_log, with_version_check):
    """Uber helper for packer and vagrant and general development"""
    ctx.obj = BoxerConfig(boxer_home=home, filename=config, library=library)

    if with_configure_log:
        if verbose:
            # todo: more verbose format with debug
            log_format = "%(levelname)s - %(message)s"
            log_level = logging.DEBUG
        else:  # pragma: nocover
            log_format = "%(levelname)s - %(message)s"
            log_level = logging.INFO

        # everything below WARNING before this will be hidden, so parse_args will be quiet
        logging.basicConfig(format=log_format, level=log_level)

        # decrease boto logger level because it is verbose and not very helpful
        logging.getLogger('boto').setLevel(logging.ERROR)

    os.environ['VAGRANT_CHECKPOINT_DISABLE'] = '1'
    if with_version_check and not check_vagrant_version():
        fail(ctx, msg="Unable to continue without a proper version of Vagrant")
    # todo: it might be interesting to set VAGRANT_DOTFILE_PATH but existing users would have to migrate

    # todo: check boxer version?
    # todo: check unison version?
    # todo: check packer version?


from boxer.commands import *  # noqa: attach all the commands to the cli command group above
