# pylint: disable=no-absolute-import
from . import syntax_error
