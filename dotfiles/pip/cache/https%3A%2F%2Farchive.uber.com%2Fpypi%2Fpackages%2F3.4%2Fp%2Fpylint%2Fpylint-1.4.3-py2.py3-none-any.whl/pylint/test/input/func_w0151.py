"""check black listed builtins
"""

__revision__ = list(map(str, (1, 2, 3)))

