"""docstring"""
# pylint: disable=W0612
__revision__ = ''

# FIXME: beep


def function():
    '''XXX:bop'''
    variable = "FIXME: Ignore me!"
    test = "text"  # FIXME: Valid test

    # TODO: Do something with the variables
    xxx = "n/a"  # XXX: Fix this later
    #FIXME: no space after hash
