FLAC
====

.. automodule:: mutagen.flac

.. autoclass:: mutagen.flac.FLAC(filename)
    :show-inheritance:
    :members:
    :exclude-members: vc, METADATA_BLOCKS

.. autoclass:: mutagen.flac.StreamInfo
    :members:

.. autoclass:: mutagen.flac.Picture
    :members:

.. autoclass:: mutagen.flac.SeekTable
    :members:

.. autoclass:: mutagen.flac.CueSheet
    :members:

.. autoclass:: mutagen.flac.CueSheetTrack
    :members:

.. autoclass:: mutagen.flac.CueSheetTrackIndex
    :members:
