=======
Credits
=======

Development Lead
----------------

* Ian McCracken <ian.mccracken@gmail.com>

Contributors
------------

* `Aron Parsons <https://github.com/aronparsons>`_
* `Brian Peiris <https://github.com/brianpeiris>`_
* `nschrenk <https://github.com/nschrenk>`_
* `Gabriel M. Schuyler <https://github.com/fnaard>`_
* `Markus Stenberg <https://github.com/fingon>`_
* `aktur <https://github.com/aktur>`_
* `Justin Eldridge <https://github.com/eldridgejm>`_
* `logjames <https://github.com/logjames>`_
* `jgstew <https://github.com/jgstew>`_
* `Bob Gardner <https://github.com/rgardner>`_
* `FRITZ|FRITZ <https://github.com/fritz-fritz>`_