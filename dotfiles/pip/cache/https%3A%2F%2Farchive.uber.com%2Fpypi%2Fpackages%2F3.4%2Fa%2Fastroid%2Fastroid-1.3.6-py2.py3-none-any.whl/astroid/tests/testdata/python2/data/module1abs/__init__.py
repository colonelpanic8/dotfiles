from __future__ import absolute_import
from . import core
from .core import *
print sys.version
