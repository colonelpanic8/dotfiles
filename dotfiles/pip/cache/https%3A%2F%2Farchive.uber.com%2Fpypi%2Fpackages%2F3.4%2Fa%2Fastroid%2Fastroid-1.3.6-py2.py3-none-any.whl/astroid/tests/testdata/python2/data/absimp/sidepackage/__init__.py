"""a side package with nothing in it
"""

