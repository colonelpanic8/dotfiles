boxer
-----
Uber helper for packer and vagrant and more.

boxer started off as a simple script and is slowly growing into a real package.
Work could be done to break it out of scripts and into it's own thing, but a
smooth migration for everyone currently running boxer would need to be planned.


