#!/bin/bash
# this script is run by `vagrant destroy` on servers with the aws provider

echo "destroy_provider_aws.sh starting..."

AWS_ACCESS_KEY_ID=$1
AWS_SECRET_ACCESS_KEY=$2
STACK_NAME=$3

DOMAIN="dev.uber.com"
FQDN="${STACK_NAME}.${DOMAIN}."
STAR_FQDN="\\052.${FQDN}"

export AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY

# let the show begin!

# check that we have access to Route 53 by looking up the ZoneID
# todo: copypastad from the internet. I'm sure these awks and grep can be simplified
ZONEID=`route53 ls | awk '($2 == "ID:"){printf "%s ",$3;getline;printf "%s\n",$3}' | grep $DOMAIN | awk '{print $1}'`
if [ -z "$ZONEID" ]; then
    echo "Failed authenticating with Amazon. Unable to configure DNS"
    exit 1
fi

# check for existing record and delete it if it exists
sleep 1
OLDIP=$(route53 get $ZONEID | grep "^${FQDN}" | awk '{print $4}')
if [ -n "$OLDIP" ]; then
    echo "Deleting existing record. $FQDN IN A $OLDIP"
    sleep 1
    route53 del_record $ZONEID $FQDN A $OLDIP
    sleep 1
    route53 del_record $ZONEID $FQDN CNAME $OLDIP
else
    echo "DNS record does not exist for $FQDN"
fi

# check for existing star record
# if the old IP matches the current IP, do nothing
# if the old IP doesnt match the current IP, but is set, delete it and add a new record
sleep 1
OLDIP=$(route53 get $ZONEID | grep "${STAR_FQDN}" | awk '{print $4}')
if [ -n "$OLDIP" ]; then
    echo "Deleting existing wildcard record. $STAR_FQDN IN A $OLDIP"
    sleep 1
    route53 del_record $ZONEID $STAR_FQDN A $OLDIP
    sleep 1
    route53 del_record $ZONEID $STAR_FQDN CNAME $OLDIP
else
    echo "DNS wildcard record does not exist for $STAR_FQDN"
fi

echo "destroy_provider_aws.sh complete."
