#!/bin/bash
#
# this script is run by `boxer packer` and `boxer v NAME -c provision`
# it is designed to take any apt-based system and make it Uber
# This does NOT use 'set -e'

set -o pipefail

if [ $EUID -ne 0 ]; then
    >&2 echo "This script must be run as root."
    exit 1
fi

if [ -x /usr/bin/curl ]; then
    echo "bootstrap.sh starting on $(curl -s icanhazip.com)..."
else
    echo "bootstrap.sh starting (and curl not installed)..."
fi

cd /tmp
uptime

if [ -e /etc/facts.d/uber.json ]; then
    CURRENT_ENV=$(python -c 'import sys, json; print json.load(sys.stdin)["uber_environment"]' < /etc/facts.d/uber.json)
    # abort if we are not in development
    if [ "$CURRENT_ENV" != 'development' ]; then
        >&2 echo "This is NOT a development box! ABORTING"
        exit 1
    fi
fi

# set variables from args or fallback to env variables
# packer uses env variables while vagrant uses args
if [ -n "$1" ]; then
    UBER_OWNER=${1}
    echo "\$UBER_OWNER = \$1 = '${UBER_OWNER}'"
else
    UBER_OWNER=${UBER_OWNER:-devexp+bootstraping@uber.com}
    echo "\$UBER_OWNER = ${UBER_OWNER}"
fi
if [ -n "$2" ]; then
    HOSTNAME=${2}
    echo "\$HOSTNAME = \$2 = '${HOSTNAME}'"
else
    HOSTNAME=${HOSTNAME:-uber_bootstrap}
    echo "\$HOSTNAME = ${HOSTNAME}"
fi
if [ -n "$3" ]; then
    UBER_ENVIRONMENT=${3}
    echo "\$UBER_ENVIRONMENT = \$3 = '${UBER_ENVIRONMENT}'"
else
    UBER_ENVIRONMENT=${UBER_ENVIRONMENT:-development}
    echo "\$UBER_ENVIRONMENT = ${UBER_ENVIRONMENT}"
fi
if [ -n "$4" ]; then
    UBER_ROLE=${4}
    echo "\$UBER_ROLE = \$4 = '${UBER_ROLE}'"
else
    UBER_ROLE=${UBER_ROLE:-base}
    echo "\$UBER_ROLE = ${UBER_ROLE}"
fi
if [ -n "$5" ]; then
    UBER_SERVICE=${5}
    echo "\$UBER_SERVICE = \$5 = '${UBER_SERVICE}'"
else
    UBER_SERVICE=${UBER_SERVICE:-base}
    echo "\$UBER_SERVICE = ${UBER_SERVICE}"
fi
if [ -n "$6" ]; then
    AWS_DISKS=${6}
    echo "\$AWS_DISKS = \$6 = '${AWS_DISKS}'"
else
    echo "\$AWS_DISKS = ${AWS_DISKS}"
fi
if [ -n "$7" ]; then
    SKIP_BOOTSTRAP_PUPPET=${7}
    echo "\$SKIP_BOOTSTRAP_PUPPET = \$7 = '${SKIP_BOOTSTRAP_PUPPET}'"
else
    echo "\$SKIP_BOOTSTRAP_PUPPET = ${SKIP_BOOTSTRAP_PUPPET}"
fi
if [ -n "$8" ]; then
    WITH_AWS_DNS=${8}
    echo "\$WITH_AWS_DNS = \$8 = '${WITH_AWS_DNS}'"
else
    echo "\$WITH_AWS_DNS = ${WITH_AWS_DNS}"
fi

# setup more variables
ALTNAME="${UBER_ENVIRONMENT}-${HOSTNAME}"

# check the variables
echo "ALTNAME=${ALTNAME}"

if [ -z "$UBER_OWNER" ]; then
    >&2 echo "no UBER_OWNER"
    exit 1
fi
if [ -z "$HOSTNAME" ]; then
    >&2 echo "no HOSTNAME"
    exit 1
fi
if [ -z "$UBER_ENVIRONMENT" ]; then
    >&2 echo "no UBER_ENVIRONMENT"
    exit 1
fi
if [ -z "$UBER_ROLE" ]; then
    >&2 echo "no UBER_ROLE"
    exit 1
fi

export CLUSTO_AUTH="fake:fake"

# let the show begin!

function apt_update_with_retry {
    echo "Running apt-get update..."
    apt-get -q update && EXIT_CODE=0 || EXIT_CODE=$?
    if [ $EXIT_CODE -ne 0 ]; then
        echo "apt-get update exited with $EXIT_CODE. This is generally transient. sleeping 30 seconds, then trying again"
        sleep 30
        apt-get --yes clean
        find /var/lib/apt/lists -type f -not -name lock -print0 | xargs -0 rm
        apt-get update && EXIT_CODE=0 || EXIT_CODE=$?
        if [ $EXIT_CODE -ne 0 ]; then
            echo "WARNING: apt-get update exited with $EXIT_CODE. You may need to apt-get update manually to fix it."
            set -x
            ps aux | grep dpkg
            ps aux | grep apt
            set +x
        fi
    fi
}

function apt_get_install {
    if ! dpkg -s "$1" > /dev/null 2>&1; then
        echo "Installing $1..."

        apt-get install --yes "$1"
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Unable to install $1"
            rm /etc/puppet/disabled
            exit 1
        fi
    fi
}

echo "Disabling standard puppet runs so they don't fight with our apt runs..."
# we can't use disable_puppet because it might not be installed yet
mkdir -p /etc/puppet/
echo "puppet disabled by bootstrap.sh. Run 'boxer v $HOSTNAME -c provision' on your local system to fix" >/etc/puppet/disabled

echo "Killing any other apt, dpkg, or puppet runs..."
pkill -1 apt
pkill -1 dpkg-preconfigure
pkill -1 puppet
if [ -e "/var/lock/.puppet.exclusivelock" ]; then
    echo "Removing leftover puppet lock..."
    rm /var/lock/.puppet.exclusivelock
fi

if [ "$SKIP_BOOTSTRAP_PUPPET" = "true" ]; then
    echo "Not running puppet inside bootstrap.sh. This should make things faster..."
fi

echo "Fixing locales..."
export LANG=en_US.UTF-8
export LANGUAGE=$LANG

# postgres has a slightly different format :(
PG_LOCALE=en_US.utf8

locale-gen $LANG || exit 1

if [ -x /bin/fuser ]; then
    fuser -vk /var/cache/debconf/config.dat
    dpkg-reconfigure locales --force
    if [ $? -ne 0 ]; then
        set -x
        echo "dpkg-reconfigure locales exited non-zero. This is generally transient. sleeping 30 seconds, then trying again"
        pkill -1 dpkg-preconfigure
        sleep 10
        fuser -vk /var/cache/debconf/config.dat
        sleep 10
        rm -v /var/cache/debconf/*.dat
        sleep 10
        dpkg-reconfigure locales || exit 1
        locale
        set +x
    fi
    export LC_ALL=$LANG || exit 1
fi

echo "Checking disks..."
df -h

DISK_MODIFIED="false"

# todo: make sure we only do this on aws
# AWS_DISKS="/dev/xvdb,/mnt;/dev/xvdc,/mntc;"
CONFIGURED_DISKS=""
if [ -n "$AWS_DISKS" ]; then
    IFS=';' read -ra AWS_DISKS <<< "$AWS_DISKS"
    for DISK_DATA in "${AWS_DISKS[@]}"; do
        IFS=',' read -ra DISK_DATA <<< "$DISK_DATA"

        DEV_NAME=${DISK_DATA[0]}
        MOUNT_DIR=${DISK_DATA[1]}
        CONFIGURED_DISKS="$CONFIGURED_DISKS $DEV_NAME"

        if [ "$(file -s "$DEV_NAME")" = "${DEV_NAME}: data" ]; then
            echo "Found an unformated disk at ${DEV_NAME}..."

            mkfs -t ext4 "$DEV_NAME"

            mkdir -p "$MOUNT_DIR"

            ESCAPED_DEV_NAME=$(echo "$DEV_NAME" | sed 's/\//\\\//g')
            sed -i".sed" "/${ESCAPED_DEV_NAME}/d" /etc/fstab

            echo "# Added by vagrant provision" >>/etc/fstab
            echo "${DEV_NAME}       ${MOUNT_DIR}   auto    defaults,nobootwait        0       2" >>/etc/fstab

            mount "${DEV_NAME}" "${MOUNT_DIR}"

            DISK_MODIFIED="true"
        fi
    done
fi

# unmount disks that we don't want
# todo: vagrant //should// be able to do this. https://github.com/mitchellh/vagrant-aws/issues/317
# no aws disks are set. make sure we don't have xvd{b,c,...} in our fstab
MOUNTED_DISKS=$(mount -l | grep xvd | grep -v xvda | cut -d" " -f1)
for disk in $MOUNTED_DISKS; do
    if [[ $CONFIGURED_DISKS =~ $disk ]]; then
        echo "Leaving ${disk} alone..."
        resize2fs "$disk" &
        sleep 10  # give it a couple seconds to think before we do other things
    else
        echo "Unmounting ${disk} and removing it from /etc/fstab..."
        umount -fl "$disk"
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Failed unmounting $disk"
            rm /etc/puppet/disabled
            exit 1
        fi

        escaped_disk=$(echo "$disk" | sed 's/\//\\\//g')
        # todo: this leaves the "# Added by vagrant provision" line :(
        # shellcheck disable=SC2086
        sed -n -i '/'${escaped_disk}'/!p' /etc/fstab
        DISK_MODIFIED="true"
    fi
done

# wtf... T73914... this should not be necessary
echo "Checking disk size..."
resize2fs /dev/xvda1 &

# try to start databases. doing this any earlier may fail if db data is in /mnt
if [ -x "/etc/init.d/postgresql" ]; then
    echo "Starting postgresql if it is stopped..."
    service postgresql status || service postgresql start
fi
if [ -x "/etc/init.d/mysql" ]; then
    echo "Starting mysql if it is stopped..."
    service mysql status || service mysql start
fi

# create swap if we are in dev and don't have any
if [ "$UBER_ENVIRONMENT" = "development" ]; then
    if free | awk '/^Swap:/ {exit !$2}'; then
        echo "Swap is already setup."
    else
        FREE_SPACE_KB=$(df / | sed -n 2p | awk '{print $4}')
        MEM_SIZE_KB=$(free -k | sed -n 2p | awk '{print $2}')

        # swap size is the smaller of 8GB or total RAM
        SWAP_SIZE_KB=$(echo -e "8000000\n${MEM_SIZE_KB}" | sort -g | head -n 1)

        # require we have 5 extra GB free so we don't take all the free space
        NEEDED_SPACE_KB=$((5000000 + SWAP_SIZE_KB))

        if [ "$FREE_SPACE_KB" -le "$NEEDED_SPACE_KB" ]; then
            echo "Not enough free space in / to safely create a swapfile"
        else
            SWAP_SIZE_MB="$((SWAP_SIZE_KB/1024))"

            echo "Creating ${SWAP_SIZE_MB}MB swapfile..."
            /usr/bin/fallocate -l ${SWAP_SIZE_MB}M /var/swap.1
            /bin/chown root:root /var/swap.1
            /bin/chmod 600 /var/swap.1

            echo "Running mkswap (this can take a minute or so)..."
            /sbin/mkswap /var/swap.1

            echo "Running swapon..."
            /sbin/swapon /var/swap.1

            echo "Updating /etc/fstab..."
            echo "# Added by vagrant provision" >>/etc/fstab
            echo "/var/swap.1 swap swap defaults 0 0" >>/etc/fstab

            DISK_MODIFIED="true"
        fi
    fi
fi

if [ "${DISK_MODIFIED}" = "true" ]; then
    echo ""
    echo "Updated fstab:"
    echo ""
    cat /etc/fstab

    echo ""
    echo "Updated df:"
    echo ""
    df -h
    echo ""
fi

if [ ! -x "/usr/sbin/run-puppet" ]; then
    # do these things before puppet and only on INITIAL setup. we need apt-pins for everything before this can be run blindly
    # todo: set an environment variable like IS_FIRST_RUN instead
    FIRST_RUN="true"

    # dist-upgrade sometimes causes puppet to break when new packages are released
    #echo "Running apt-get dist-upgrade..."
    #apt-get dist-upgrade --yes

    # stop ec2 from re-writing /etc/apt/sources.list on first boot
    if [ -e "/etc/cloud/cloud.cfg" ] && ! grep -Fxq "apt_preserve_sources_list:" /etc/cloud/cloud.cfg ; then
        echo "apt_preserve_sources_list: true" >> /etc/cloud/cloud.cfg
    fi

    mkdir -p /etc/facts.d
    echo "{\"clusto_supervisor_version\": \"3.1.3-1~235.gbp661699\", \"dev_no_mnt\": \"true\"}" >/etc/facts.d/from_packer.json

    # add bryan's SSH key so that he can debug while the instance is provisioning
    echo "Allowing temporary access to $(whoami)..."
    mkdir -p ~/.ssh
    echo "# added by bootstrap.sh
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCmrD/YwuJmuD/dRSFm4RjeXDRjVQydbNj68xo+RaCmMyYdHErowJuUJ1h4l9lXmWIh2iWoS0iqm+DEyHOjFmP0s5NSx8X6mlNzpDF6AIIXp8oznMTWuP5tIp0lTZN3Xt5yGIV4WEqDm2EfX8HHuXJcfQUUBnr0CVO96m6ZRFI+PFdnfX8tUCxDY6g+MZQwijV/B5C8knasHoyr904Uy7w4l/Q+ez4Y6gSmSig1c4WvkLufIMCCPchbQSa+WYtQNGRl1Yk3hfy4/qpI4J3Uf3eU16qTCZ8X2tS1HuDQ3c2F8rjjNNbKBzin1T5M931LCviGQjSdtYwuOWpe8zYzavb ignas@pow.lt
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDDCNa641e1FyDvxDOn+f8FxVrj4NeK6gWMLcbz31UisYEsQdrNjK9IklJkmGDNqraocrN3c7vR2gEuIcR2f5m34PKyWjK1aul5ek16AxtF0wk1t+fJF8ZK9ybEZvH6nohfZYhBfuiRAXlpH+S1NmFeiUM0iug4glVSnGIYeOrJgEcLXmqoeH5D+ml6M0usi3IdCNbxWwdY3poL4Tx30svh6aZKzCzt5nH1a3K1rslgyaeRqAHGApRxFxb3rPv1CnZixPtT60uWSThNEEifu6beKX16QHjo3MngI3YLj7V0hJ3yQPvCeeSLQysuP75AWx2g5EzG5u/I2AGpGBGAVDhN jess@Jessicas-MacBook-Pro.local-20140424
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDEH+UMiR6tTFBkRTauuN7qQwG+eBg1rwetMxvqi5LlI+cfxlafwIow89tmtvQCXvekUL/ncOdEFvjcxNOk4BfkXx7r4h6WC3Fm2ECSlAWz17pH1+xQZGAzLtOmIdJlFVrsfo33oxfqGloyV2vY/nBHpfWLjv2slKI7/ZmMi/15GxrvHrI89Kj3bmCKM6V0DNiu+MhaPyM5KeETuaeY+kFJv0he7MXE5RvbzW2wZ0QwgwfD699rWEXyAoLCFnAtrE9rD/wldyCtChBnv9eGNvvg5ILaKZwctbpfPFZqju1RYKdmO/5f+KjC4UhniPmoqH/dQFc50QadH2yV2wPqHMlL bwstitt@uber
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDEjje0iEDHS88PJt0crO/uqziow2OCvnq8NOnj91BkSPYZn3gCsqYr+QvCVsIcKnGfgnym5R2qYJoY+kEYbkG1bNgdu6NeoQ7vUKy8r5J5HCC46j6LxoqopsQZ6MZI/tcWDKcKOerNmnFi/L9XDL42/VuZ0TLBmbhNFkceVbTgWg+DrJskctnvJTJgZLMQK+9jtscCareHeOUdWFR9h8NlNI5Z0Dsy8jkuiE0VtFVFLRimYkXWe+T6DQ0yB2d6itEsvKz+W0LiOjUVoTKW6LSYsM3LAYc2Fynudw3C2hrapMSHXAntlbZTf+ABhBQS67zu1NFW2wFP2V6TAnbwfNYZ sasha@200OK.local
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDHQ/E82MsCuhYyhDOni/2rALQZG/Au114JlNTWcntOVzg7ZJtmVmygJE16RLyo/m0oE34PlPPTZWvffIEYsABiMGgeZpIhPTGSwDhmj3jPERhxhChghDkLey1nH0P/udlJlXlyEx6S9v3z7d6o7UrTUo5yG13vtAnj18A93YWU1ldDCFcP4Xiz5RX2X8tumpl5LQAwsYPYIH8eSil0+C2v1wNlS/xFVYdSx2wuvo+/8kVa+OGrXnXFm1r1Ar3B/a98MQreXMLruFftShAFnUduvfti7bSHKOhqT6V0HKWwG7spq3l14kRuv94q+5UTO/Tl5fD1SAIomWQa5lZBux47 audrius@Audrius-MacBook-Pro.local
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDJHt8i0YHQGnB89pXPXNBcc1aQhmCjUHxf23J/v9pLlWVdHCqMWQ2eiGOf7SIk4V8ZgZmeuoqhrjW3HdQ5higuAHtDp4UFxYmnRFzBGA3V9qKyT0SfzG8lcNfodVROeuIlCEbh6cXpp3nk7TFB5UZug0edT5RTjxLsETjdogPFR23tVfeWHiBQGweQfBuJ8eDThvFI59fdJx/5JZFYYeURughEvPyBIVDluodO4rJlvVVK3ZrqFXLRLNACsMNxVMBCLaeMUmwd8zLBdtkkJZlOce2poXXauv01qHUDt6hJk8czVwqryupnH+HS2b8tknvcOAdWSNiuAvs2mBg9xcF5 rpooley
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDnmi9KmS6E6cWJ2UydA7dmZtUFXFZG1GxKkcxxqy1h7oENQt6kgPuTpira5KYFdm5OMxPtvePialT7/xd6JHf104G4dcvvjQQDxqPzvDFaZM4TsreHpGdxs6/rV+HMcBseuiALdNAdy/fVbpbY0qnvpH6wToGaX1SQTsQl2O86ndBO13NjQHC8jxX1Mdt4qtl5Pd90WEMRYUF/h3qnJ1YHcAX++4aUgAJnq3hmA4hzInobOBEXkCFhtLu3LpJwS6u/ozo4BHGTgRfacEU0aE3ZLjrqsc371Pfcl/BdqB2RBbjs79AC9jUT5Wc+tq3svJMskWMmY7Fbxlu+QyYBuDhj abachm@abachm-thinkpad
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAAEAQCc6kAji6xu90oLsRZaPP2qjWNLldZIGVi5RA9iPcuLJsl0cNFYs24pMWuPk6/Ij5nBlN1cKobQ9v6iRu9pXNCfLqXgnUVRjU90Ei2mIkC9vRlRFvR9pCGq4Je9Lkd+UXbDOOPkdFQmPGqq/ZDsBy+lC1nOcGrQdDoQ86mKMHt8ioFumRXVEYUFPZrcwmTjD00J77Quam3ylvijMYrHmc/wII193a9n6wrqczjqo/kmbtVXq8QX03wAJ5b7Ae6hBoKc9s7+6fDFkHczaY1FmUEeQlAZpUytfVH5gbUGmM5O7g4p9/o6e5pD91smypy7Q1ZOiQbuF9E/T4is1sggutJiqehJEVDX1ARSSP8wCPiduJNiTPsiofO1q87YrH+/Wv0s40Z6E4BHXyfqO7LzRigbGeLqjTMbUSpqBaE3Y3nV21nUc1BlRbxygWuwAw+8Uek+/nsQhzSFOUZ39is8nzBLdq5+rZwRQAXWEQ5bnFeJ/jxCNffOrjBifTHDZx2gjX0IM+IqmpMQEaW9OBFv0CmAr9i2fMc5eJRGO42X6vfN4aaTOqGpP5T7yHO3DTH4EADIa/veTmtAqnjoYPDjf1Td2FFalgZZXHP0kIAJzI6C7TOehXnjIIgB3rRwktH6Syqk/rcgWKfSiC2MjLyFfZ8mFCZf11eLitvw6lcuslxu7ojNFh/wx2+nu72o0MVvX7GdPxPqwBHzWClAx7/hs9KL8CGOlIjAXsjaUEDVC0i/3+CT4J6MC5Hf1Su12LMc+ApuDkAYEgv/RQOqI8bzuFcCkylI0yIVuo6AgJijGQ8UO5zA5f6iEbkxarTEMDBR88L7TSPFhCBxt0t/ugXjDkJkAzkZrjNEU/omoQDrb+9C81ug9DnbFnsxxNoX36+QPHg0srGciDzwBbzhEjp88EKImZCAR+1Iy+KXXbgAvgAFazx8Iej2+2NT5di27+RSVpLcqcC93BpHoe6z0wGXEYAsPs3OM35nSCfrOAL5EwYq2gTNrhCCt1ShWetU+9hLbnBvj7FUGAx9s9N83ZQDPgPNdwTU2Cz0e3LkW/g34JHSJgn7VCatNDmPkqmETsaECtb1tnyW/BrW6z3OeOu2w0QousSLmJg6tQsxa5f3b2ctmLJQcAjgjgZekLdKunPjJc94uVkkCMAewhqtGFM5DCV8kM03FN6TGOGlU/tTTAopnS3WSq3YLXysiKefS+32cwPg7vneepWGFVEM9IYIWVozIUeCQr1Pw9SNmL7P+2k2uxokWGJuBQzHO0avhYNl+gdG8/XqPYttVfB3vK2n4mCf6aSAkbVCSLjxBW8i68OkxpMMa1RH6IB6godxn9B2DoIYuWR/KsRL2C7Rw+vJBLjF abacker@backer-mbp.local
" >>~/.ssh/authorized_keys

    cat ~/.ssh/authorized_keys
else
    FIRST_RUN=""  # clear this just in case
fi

# install this before puppet so we can figure out the distribution
if [ ! -x /usr/bin/lsb_release ]; then
    echo "Updating apt..."
    apt_update_with_retry
    echo "Installing lsb-release..."
    apt-get install --yes lsb-release
fi

DISTRIBUTION=$(lsb_release --codename --short)
echo "DISTRIBUTION=${DISTRIBUTION}"

echo "Configuring uber apt source..."
mkdir -p /root/.ssh
chmod 700 /root/.ssh
touch /root/.ssh/apt_rsa
chmod 400 /root/.ssh/apt_rsa

echo "-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEA/PRC1hoy6K5rypE+FPy2R5+cbko8pStBI25sqntv8u8Y0TJL
dDhB0G59LTkYicPBuLY/h1220Jle5IheSRZrRqwRq7IoC3ooIa+jq0USjeu86gLl
QFdm63vV1xL0bwtwQmU7e3+7PeQQ+mF8zQj8hfRNxhbkrqtnBBN8B4hoXRn83s1e
Aq2AdTs028/TZvPpHuReI1n9F44SYc8trg/IHO8zyTIU9gDHNRQFwR1L+V1arFNB
ZgPef75DDu6yLN+rn6tLsHBMqVNLk8wvgElwiuNMfISp4R+fhMFlvclVrzopY+ET
OJG3qdPSFWxaOGzbA12watCaxEC469MRoHx6hQIDAQABAoIBAQCy/I+SeeVN+aVy
J4W7SfodAhapf8Qbx1iHHqqrkz5qsr5nwGPdr7T6LERMzJrNWIPqFKMtQKWMQwn/
QXMd2kw8LKMwT5bAUEa3V1XDadOwMn9xQm0/MtkzhWORlOr67CgaAxGs2HwAVjGh
SXwKhPJSQsUJhsd3xPbWzoazudTHEqVXB1zhK4kxG1/ZsDSKNWuSeCOa2qMxJulJ
FoPXRYYi3a4EsgB4LWstVpI95yYQERFj74JIDhJloV93bBfUwq5M3xJdYIs+CQHF
7f4jeMGF1b3Fs3aMwE/nhh4nmyH6P/jU/YNR8pDE8QmVnWUabdCvdMNpSNU2vPkx
zL6iWCddAoGBAP+HlAc1H3TRCD48TvX+EsIdnRnUHqTMDSHauHqIB6l4h98+oEVb
nQakXzUb/e/T5hmB7ZbGRIMcKotuql1hIHkxW77xbRBdUzUkX2MqGYs5C8wqDi7/
QlEvEJtcQnQGU4Bxi9BV6HUdYRCVvU+RHiskwvOCGYJdcFIpWiAA7pojAoGBAP1r
eBiZ3r3Q5oyrLF4YPhF+DaNutrAqR/A/A8VDKUBPLgz3bsygZuyszorrR6BW3h7D
Gr9KG1NDttfpKVLi+V8HEK56qhZ77XOe8NpDICPzlYi0ix00W30o/ck9YJrebuHY
nIGsKIqFgS2KnrEL6DRkXjqdcrBJyVdTYnqNVn83AoGBANSDBPEZlRep4JkhvumG
bENULZuVdgbITQOiy1ncV8Lxos5fXxtPncAwY53fsckLCYqdK+MA8Wm4uwlK+BTA
+ijQi+S5FGNPuiuwHER0dtn6j300XKdpUtYBtmX+zKWBvWBNDmItkC4WSOtqHQ9X
OSfYYunxgRWScB9klLeZDtbRAoGAYXmM4CmPO4O2qjTNBARfG2tY45waOPiKYyZZ
1O5YV5wdIm+p9ptb+30clOKa0lmXZk21ZA6lJAnPsozEkFUthhe5muMjuTJBy08/
ZTSckDeJNOP8/ma9Kg8yTs2E8wzLqaMfz+DgVyey4EmJcKAb2MsiU3lsO9Kl1ykD
oA/tTVECgYEA9w1YkUML9CqofC2x0fEwrhvBTCUKhxI7g2JtgR2yVI3xakGpnNzb
PfFQhzNCvo3OQcQODi46lOLKCrxpiFuriBy5LiRLcIE88etlviroqNWiYqSS17QH
VRkADaFixSFM2xoykrjOscjXfu3axfsy4qYIMvm45n7JxynK+s0O3as=
-----END RSA PRIVATE KEY-----
" >/root/.ssh/apt_rsa

echo "mirror.uber.com,104.36.192.209 ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDI3E+WKtsKeFPo3l48BU7+zcMGqzgOoyRgdaeUvW7EuDTNpknA/Z1ZriCD0srGWygjZ4o/AZwfS4voq4KqrBuxY9KHBmiebmQz4P794BqMfOyzU1OQNVn9K9abB0a28hr6OBsJZzjHLTJDzFTzfaq4KZaU1sFRfP1PC7IfhCLt4wGD/hJXPXTpT0LNMBWifk+DDvnPLEbwAhJBrjmVMf6cl+mtNt7RRApVNBQNZfoLH6ZJZro1zil7XvPyHWdP0G0ZzlpiULMF3vcFBEZ47iYkZi6O1upFeOXtVg884J+PtkC044jD47NqZ6RTuvy4rEf64lIYsKsKtX6qaosY/kuR
bastion-sjc1 ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCl+Fl4XvFTecK+aDGQc7ZikDDVH6/W1O0ZYY3lkf7cuJ85mLjkNUNCmGWJXHnJw8iDzy9KKzZlRefB128ZcudcEgcHQkfqCc0213QV6MGcJi2W66hfCMBI5fyL4Md/Av23Sv2x8tRjeas/aiGrE/ydtx1KeUsJQj8SINNQ6bfYLL0aW4TE0PoBY69cEFw5RfEThRdqYf4cmTw1yBmDJwHw/ekcgWbiiALaWjt4qugikwHgAKPac79MaPeiP4wisP9fx4+fICRZ2bdQjiJERgL596/iHWdOxS4MyoHa0Katet6scr7SjB9t8V7mNGA38VzJW2WmnD0X4Zh2XlIVyEcD
code.uber.internal,code01-sjc1,code01-sjc1.prod.uber.internal,[code01-sjc1.prod.uber.internal]:2222,10.31.5.73 ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC856O+bX344L0Hu+Q3NLz8RZxg3DDUrFAAnW43+4eydPpLqmXtlrb/C9XDEJGKtHDn8ts30jIhMzNpA0yrBLB9JPsAaZkLqenz361x91Dr7HoaqQaMfKQqWPFSjGobJ5p8tQoXU8Yv1T/JAvWS68EkaVoMLl5VXvCZy7KONbBurYSvEoB37ovzVuqZMPKsMchP8ylieGu5aBTjmYFlx9VCENZxuaIUudGq9FPn5ZGonAYUgiOIuyxVtSSj0Aq+dOS8iq5CCV4N03OvRjoIxRhy1IpA9tESj48LV78HuogyTIq62m3qORDbrjjDlstszPQw9MoYVmHZsVK9rfHyQ2gV
|1|vwD/2tU7PjhYCkDHGSZBbZd9byg=|TVCFS+L8TvZh/ru2UGF3YDZ+dlE= ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCl+Fl4XvFTecK+aDGQc7ZikDDVH6/W1O0ZYY3lkf7cuJ85mLjkNUNCmGWJXHnJw8iDzy9KKzZlRefB128ZcudcEgcHQkfqCc0213QV6MGcJi2W66hfCMBI5fyL4Md/Av23Sv2x8tRjeas/aiGrE/ydtx1KeUsJQj8SINNQ6bfYLL0aW4TE0PoBY69cEFw5RfEThRdqYf4cmTw1yBmDJwHw/ekcgWbiiALaWjt4qugikwHgAKPac79MaPeiP4wisP9fx4+fICRZ2bdQjiJERgL596/iHWdOxS4MyoHa0Katet6scr7SjB9t8V7mNGA38VzJW2WmnD0X4Zh2XlIVyEcD" >/root/.ssh/known_hosts

# this will be overwritten by puppet. keep this in sync with modules/uber/files/base/root_ssh/config.development
echo -e "# this file is managed by puppet. Changes here will be overwritten hourly

#
# We use apt over SSH
#

Host mirror
    Hostname mirror.uber.com
    IdentityFile /root/.ssh/apt_rsa
    User apt

#
# IMPORTANT: Keep the below in sync with https://infra.uberinternal.com/checks/newengsetup/dotfiles/ssh_config
#

Compression yes
ServerAliveInterval 180

#
# connecting to bastion hosts
#

Host bastion
    HostName bastion.uber.com
    ForwardAgent yes

Host bastion-dca1
    HostName bastion01-dca1.prod.uber.com
    ForwardAgent yes

Host bastion-peak1 bastion-pk1
    HostName bastion01-peak1.prod.uber.com
    ForwardAgent yes

Host bastion-peak3 bastion-pk3
    HostName bastion01-peak3.prod.uber.com
    ForwardAgent yes

Host bastion-sjc1 bastion-sj1
    HostName bastion01-sjc1.prod.uber.com
    ForwardAgent yes

Host bastion* \0041bastion*.uber.com
    # this will work for bastionXX-YYYY
    HostName %h.prod.uber.com
    ForwardAgent yes

#
# proxy through bastion hosts to production
#

Host *-dca1 *-peak1 *-peak3 *-sjc1 \0041bastion*
    # there's no point in doing Compression here because it's already
    # compressed on the tunnel connection through bastion, and
    # double-compression is silly
    Compression no
    HostName %h.prod.uber.internal
    ProxyCommand ssh -q bastion01-\$(echo %h | cut -d. -f1 | awk -F- '{print \$(NF)}') nc -q 1 -w 1 %h %p

#
# connecting through bastion host to gitolite
#

Host code.uber.internal
    ForwardAgent no
    HostName code01-sjc1.prod.uber.internal
    Port 2222
    ProxyCommand ssh -q \${SSH_USER}@bastion-sjc1 nc -q 7 -w 1 %h %p
    ServerAliveInterval 60
    User gitolite" >/root/.ssh/config

echo "Updating /etc/apt/sources.list.d/..."
echo "deb [arch=amd64] ssh://mirror/srv/uber-packages/ uber-${DISTRIBUTION}-${UBER_ENVIRONMENT} main" >"/etc/apt/sources.list.d/uber-${DISTRIBUTION}-${UBER_ENVIRONMENT}.list"

# 2012 uber signing key
if ! apt-key finger | grep "E24F 1F3E 740A DCA2 6AC4  159E 96F2 D8D1 3DDA 06D0" >/dev/null; then
    echo "-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v1.4.11 (GNU/Linux)

mQENBE8MxEkBCADuMZxTNUJriQVom6ZUgLFqt7tBUF5p/ACkc8wvG8EbDUiDgIMB
PYIwXtYfDn7CgDBK87QiCjkrfCYEtVyi/UMYv4MTfv1iCn4afFqt92EEnauq8Uqh
RAviTLRBfQfon9nVzAXEHqBl+2TEE/tioPrRLSdqgUCHsRgO6OYXZCHpqvDskXkl
WnKe73ZMC/7K+DzdBgNamhGWWcZQlWqkivBQCzOC+/O+ARuHW9lnDvDvnWD0YN6i
2/v5wAlT4dssUtxPxZ2jVGYwFqwsP2wmo9Qe+pgLSz22dYJe5DAr70uUlYU768Pl
d/PaPXkMT+S6ETka0nbHHI/hvpfThvBAGgSTABEBAAG0K1ViZXIgUGFja2FnZSBN
YWludGFpbmVyIDxwYWNrYWdlc0B1YmVyLmNvbT6JATgEEwECACIFAk8MxEkCGwMG
CwkIBwMCBhUIAgkKCwQWAgMBAh4BAheAAAoJEJby2NE92gbQMrkH/AwcvpH9OfnV
78f6GwBK1O9dGOIx7wsaNSDs2WBJ2DrEaJDFOVdBCUiiY2q3LncUzKVS2Gp/n+I9
VdDE5JDk4RH0Eze/xG6LqoPoEBcXrHShaEB8A+KCpWcZKMiJ75yTiaeF3h9gaSFX
2QtvhqWhQmhvMkHE+cOpkcXvDWgLZOn1UK5iAWji80n72VHVPKC38lFHJDGxFuUW
4jTH12ZJ3OjKOfXsBT9VYdsYI4p6/qSAUfb+1c9g+ictObyrL6P25sZnK40EVj0l
adQ3ih1eTKPHvZJM9haJZIi7fXArVQq0AQuRi3vjeZV9EFVFqcniNCuVPeW8IxlN
5KE25YFrQ4W5AQ0ETwzESQEIAKwLDhJs9vI9KZ+VXhfZJDEmyE07C/AJHTIhH6uJ
5vuxT4qJJWSXm6bZHklDII5avS7BEAuVm7X4mkYyVEX9we44ptinGNzlSho781im
dFTcJ1po7xUGOaJzBxwz4F3cP4BFOfmP7W1qG4o9wYwRrZBMDwS2XkxheSrABuYa
QC0frQSg3URYVLYMdnOcTxCLfTpf5cg2nZXTdXtmGjYug9jBDKGxRqYCy1OE9pmb
tGv2MBSdJoihElDvhbRLYxfBQachjplumDQu2ds9fe+SS2X9F4/YXm+grbBogCsP
5eSzWckqa3KRlTp6iD3Q44cfjP3yVrXmqSyIV1SytO/d2GsAEQEAAYkBHwQYAQIA
CQUCTwzESQIbDAAKCRCW8tjRPdoG0AusB/4nuT5cVMCA9PVl4L9U7two4hi+k+WB
pzQOkvUlgdoqGPGQ4BUHuKhiMZw04WNBXmJLJesqIcZe7RDEHXwXErbcrVlnyPtG
Z2CIHB5ttEZKu12c1mCO5+cnMNq92jHEjUTqx6+xsExZa3wbqdbgoHzPfL/3u/5O
GpYjeS1+wKjajEjWjyhLaXZLPFHJMZqCTgBKoEeQ3ALDaf3bRkPKU4lfi6wss6E5
r2s2o4t+mtblHOVRSH7tXl9eFns2lvTlgZPcBsXhgDaOzWS5a4eEgxNj8Cjmu/gb
P1nQupJq1qQf2pAfePKJKlWI8zOO27AIKA4Lnmv7tt8lfk1vza0D3eTc
=3KOu
-----END PGP PUBLIC KEY BLOCK-----" | apt-key add -
fi

# puppetlabs key
if ! apt-key finger | grep "47B3 20EB 4C7C 375A A9DA  E1A0 1054 B7A2 4BD6 EC30" >/dev/null; then
    echo "-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v1.4.11 (GNU/Linux)

mQINBEw3u0ABEAC1+aJQpU59fwZ4mxFjqNCgfZgDhONDSYQFMRnYC1dzBpJHzI6b
fUBQeaZ8rh6N4kZ+wq1eL86YDXkCt4sCvNTP0eF2XaOLbmxtV9bdpTIBep9bQiKg
5iZaz+brUZlFk/MyJ0Yz//VQ68N1uvXccmD6uxQsVO+gx7rnarg/BGuCNaVtGwy+
S98g8Begwxs9JmGa8pMCcSxtC7fAfAEZ02cYyrw5KfBvFI3cHDdBqrEJQKwKeLKY
GHK3+H1TM4ZMxPsLuR/XKCbvTyl+OCPxU2OxPjufAxLlr8BWUzgJv6ztPe9imqpH
Ppp3KuLFNorjPqWY5jSgKl94W/CO2x591e++a1PhwUn7iVUwVVe+mOEWnK5+Fd0v
VMQebYCXS+3dNf6gxSvhz8etpw20T9Ytg4EdhLvCJRV/pYlqhcq+E9le1jFOHOc0
Nc5FQweUtHGaNVyn8S1hvnvWJBMxpXq+Bezfk3X8PhPT/l9O2lLFOOO08jo0OYiI
wrjhMQQOOSZOb3vBRvBZNnnxPrcdjUUm/9cVB8VcgI5KFhG7hmMCwH70tpUWcZCN
NlI1wj/PJ7Tlxjy44f1o4CQ5FxuozkiITJvh9CTg+k3wEmiaGz65w9jRl9ny2gEl
f4CR5+ba+w2dpuDeMwiHJIs5JsGyJjmA5/0xytB7QvgMs2q25vWhygsmUQARAQAB
tEdQdXBwZXQgTGFicyBSZWxlYXNlIEtleSAoUHVwcGV0IExhYnMgUmVsZWFzZSBL
ZXkpIDxpbmZvQHB1cHBldGxhYnMuY29tPokBHAQQAQIABgUCTDfARgAKCRAhWv5Q
5BRwMq8TCACgG44+c+KgHBinygdU9Oj/r1wmfXbbmR+tpRgZ5sJytHC6gp3wjKFH
XrmddgmYPzKsAUGTxJxRUqxD+lKeo2sEKuXNAPo1C+4hZUV6Ah2N1qytZfpLOP43
U6WVvMgluQTl6jRaMIwQolUj8ZNjYCdNZQCbfo8tALkedIBPKSrDF5kOwn+zxFyR
3v5A3mwFXK0bepvjlDuMsmktwk7opgfivP1mA3svPLIZu70PKk+u6UAMb06svt6V
SewYMbgTUzw+SCT1e/0xEpqjUqNgsPnPE6hW116goRB2cz6VYwmKfVe+ioljsVMM
mTqj5xWqoeR0ov6yCyxwVVCWOAIR3QSAiQEcBBABAgAGBQJUCeGFAAoJEBM5V+oR
Ao3zE3AH/1GQTS4JX3kS3WXE2Pi8L+gGylfYsf1dDbaDBX8mPfxKO6usZZmX9fIu
qQwQDIEksGrdcb6nrGecHufJDbLmFZiE77LjjoREFlG9tEyaIAVSCw/vyng9wVo8
InDF7j1VHuUueh6eu+yvLjUrFuh3CVNHcx2rEIFzx+X5660TbbRfMgxLpTMkkb4w
7DQjCUmFQD4yLzZzXAzjELc/TgsFGZc3lxo7UuzwX0ZEm15WjrdYwvtMU1TGjjI2
6dgk24K3Kb2OeUnCybQ1mLx6qVx0aFd21beKRG9u3Stp8HHXpfLh/aznbCY5JavO
ShOXgNgq3f0/UImLjyuFv27x0HQFxfeJARwEEAEKAAYFAlQHuw4ACgkQpHBvotfb
FDW/pwf+J6JBPpUHi/EsuLLbqDTQjGbnMTsH35pZRApKheaISPRZH8oqgdmWE599
6e5GwnXMoBJoUvU0VbcO7aEarWlKmO6dpTKsfvjP+PtiSBeXUa8ewNcTq5N0Z7O5
IwF2CiHrSTEcySjjboMKJHS/vQCmsLg1j+MA7wq3quzX0vQsGBX3X1x+n2KOH4s8
BGoXFJs6sM1SInnqkPwryCesj61zc9I72kTM6IsG17X586INWMHoMDzpF/hTWKKw
2c0kFMDIJDpU+KBKr/e4mbKrp8ToP64GjB0MOx6MqjZI6I3k1PQu8zgWmOQ+yQhI
e/UfB8u+eGbhDwUMqKBEHUzV3b5lj4kCHAQQAQIABgUCUeTczgAKCRBKMwua1kj6
4/mED/9RNl8PfjS6SKnqM+UzPHBIP9BqnC07sPiCwZOxd7MOQ73sPbV3Wk1o1PRG
tcAxqDCTUSUPGaf9gdQN8yi9lrZspqCNaZXfzGRaz4+uHU/ji9QMbfQIBTopn6ZM
YtRuiV868N98JOb0yfWLaTEVonFtWFZHrNHbwplHbyzUgGyup5MKSxh90p2S7DX+
PznSFbwwzeE8En/jxUvHlAQV+eVfC3V+n4vKAC+sjInDu8m2xr1CMIiRCTa1y/vu
uGSJnoAO2GBUjHmPfINZKbicuoWnBtBMqs1GsJvldsv+ggx4cm4UgJvYdyQNLUq4
pceaq8O4uhGvT/AURkymzldB6+iZRrsmQx5LmP0C5sIbiDXMoS089oYOx8MoGWMI
cErBTKxCPmgZTnDxW+U4+dLrYMF+yBTbLmKmaYhNiSNI4votfA7rEbn+zEDxzKgl
KZs3bzqKZxjoAeWhOKK7r83tSz4I2uHD9XscC6fnp61YGfdtlYJEYYA8XeomvjLa
xQxjQTcdrs48Qcgp8FvgyImelee1ZPbydB8Xd2VMVO2EDPBydlyHHZ6zjKt8Neff
djh6KyrFYJtOW4StdSiBQQofUqiFJq1gy3F6dy/ttSXMivbbNJQJjJV/1zKDnSQH
L7Qnux4SmobkrlHzP2z/rcFPk6CGaLpsHazmIrl8G3dO7UhinIkCHAQQAQIABgUC
VAesWAAKCRBGnps2mw8PHet2EACTyXdYh4kXGgSwQpY8hUJwd9FPrXPyYMTfeJFq
kIBpG/q60Q72Kqvn0AqUSmnROoKzPnwYW/jE+89tx1JBAT+8EtRAJvJaNH9Hovw4
S3GV5wqImdsmIqJUxl8lh9moB9zfpsqWz2Laa1Xn/TGwmLl/zFL0PWQ4rv8r6pZ/
OhEE/pnqZDLh/+6PxYmQRsIvDfmeVd57XSYLnT6JNXkAYBnmMouw+L7b2B9LWMIs
10lfjdOCplNE1FCTFS7K/j13x8Cyul6yF6eeq+rd5ftcw84XW+1qh3Jsw4bSNc0Z
LvGh7zgRznEWhxZrcGzWwtxnEG1aW7wXiDJ/kqAvBNP1LOhIQQH2NVp3oRW+hB1o
Cb/pbIht3xin7g5EJ0cpplTKNvfVdcitIflpgV9CT51oNkV7dVCtkXbFxwGdxP1L
CnYmfJ8IBumX6a3ue741E1tHHp2dZOHXWiMUI6TjYISQjx4KiiFTXJRpMsm5AQDi
ps+TSnF5TsNJ4776aAhP0hTN6Wy864NRoWEPs9OHltmZFCHzzTixQZrNxaUvLALP
vCmQ++U8f4mxD1+/eLXSzcfWolUoqyneTH/DEWpYXaoE5NalLfmoH7WxCR32LXWR
tJ748SZXI5SFjOzIzLsFr/qq36hGqDb7fqsc4LSz8uvJYo7vAdvkSUL2mkHeX4lD
QzwR/4kCHAQQAQgABgUCTPlA6QAKCRBcE9bbkwUuAxdYD/40FxAeNCYByxkr/XRT
0gFT+NCjPuqPWCM5tf2NIhSapXtb2+32WbAfDzVfqWjC0G0RnQBve+vcjpY4/rJu
4VKIDGIT8CtnKOIyEcXTNFOehi65xO4ypaeiBPSb3ip3P0of1iZZDQrNHMW5VcyL
1c+PWT/6exXSGsePtO/89tc6mupqZtC05f5ZXG4jswMF0U6Q5s3S0tG7Y+oQhKNF
JS4sH4rHe1o5CxKwNRSzqccA0hptKy3MHUZ2+zeHzuRdRWGjb2rUiVxnIvPPBGxF
2JHhB4ERhGgbTxRZ6wZbdW06BOE8r7pGrUpUfCw/WRT3gGXJHpGPOzFAvr3Xl7Vc
DUKTVmIajnpd3SoyD1t2XsvJlSQBOWbViucHdvE4SIKQ77vBLRlZIoXXVb6Wu7Vq
+eQs1ybjwGOhnnKjz8llXcMnLzzN86STpjN4qGTXQy/E9+dyUP1sXn3RRwb+ZkdI
77m1YY95QRNgG/hqh77IuWWg1MtTSgQnP+F27mfo0/522hObhdAe73VO3ttEPiri
Wy7tw3bS9daP2TAVbYyFqkvptkBb1OXRUSzqUuWjBmZ35UlXjKQsGeUHlOiEh84a
ondF90A7gx0X/ktNIPRrfCGkHJcDu+HVnR7xKk+F0qb9+/pGLiT3rqeQTr8fYsb4
xLHT7uEg1gVFB1g0kd+RQHzV74kCPgQTAQIAKAIbAwYLCQgHAwIGFQgCCQoLBBYC
AwECHgECF4AFAk/x5PoFCQtIMjoACgkQEFS3okvW7DAIKQ/9HvZyf+LHVSkCk92K
b6gckniin3+5ooz67hSr8miGBfK4eocqQ0H7bdtWjAILzR/IBY0xj6OHKhYP2k8T
Lc7QhQjt0dRpNkX+Iton2AZryV7vUADreYz44B0bPmhiE+LL46ET5IThLKu/Kfih
zkEEBa9/t178+dO9zCM2xsXaiDhMOxVE32gXvSZKP3hmvnK/FdylUY3nWtPedr+l
HpBLoHGaPH7cjI+MEEugU3oAJ0jpq3V8n4w0jIq2V77wfmbD9byIV7dXcxApzciK
+ekwpQNQMSaceuxLlTZKcdSqo0/qmS2A863YZQ0ZBe+Xyf5OI33+y+Mry+vl6Lre
2VfPm3udgR10E4tWXJ9Q2CmG+zNPWt73U1FD7xBI7PPvOlyzCX4QJhy2Fn/fvzaN
jHp4/FSiCw0HvX01epcersyun3xxPkRIjwwRM9m5MJ0o4hhPfa97zibXSh8XXBno
sBQxeg6nEnb26eorVQbqGx0ruu/W2m5/JpUfREsFmNOBUbi8xlKNS5CZypH3Zh88
EZiTFolOMEh+hT6s0l6znBAGGZ4m/Unacm5yDHmg7unCk4JyVopQ2KHMoqG886el
u+rm0ASkhyqBAk9sWKptMl3NHiYTRE/m9VAkugVIB2pi+8u84f+an4Hml4xlyijg
Yu05pqNvnLRyJDLd61hviLC8GYWJAj4EEwECACgFAkw3u0ACGwMFCQPCZwAGCwkI
BwMCBhUIAgkKCwQWAgMBAh4BAheAAAoJEBBUt6JL1uwwGWsP/2i5hP3qG6V6SFFc
glFkMRLz7TP4f0gCbBtyqBzfbttensLPlB7C/+xfdXHlV0EHQ9nvArWFhXizTNEU
jPYvyjOtIOAryEJZjanaoYtR7IBqiJ2e9v1ywF7p9IGm3wt+qy8MNpHpfmjKUX+f
Eq0rrJGN9tTZzBCZeDrB1doXzbQCIMNnv85vUYaDKRisaB2QrxYZz+7tjNsDKu4j
Qw1m+nVbC6c3ZVX9uNswm7mzwscUFzqQOeq85FD7ifOZnVcOItfaDyBSGVS+aMIr
dUsQjsQYOG/KGjEt+oRJd6rWRvN+K7S33KgJqo4cemibiSzgGDfOEIwxFNzSOSHz
UTL5biHk3A+A7eRQmGoTdOObVtUXOrORgEfEVuORmMEA8xvpJJHnhscBIaglu5zh
7sGSKFSbnzYXdvFBZ/NyhiRwkLeDQQa9yuU3GOmw0BCK6UqZVkgwW3d6dSGqGWNV
kg3T/Tk1Tkm7M9CYoJVplFhlgnXfwjElvw+/91VDiTmEQ8Kbb7UmHIyXPNVFftcw
fq7eS2vzlnuFDjkQ/o1NQE4o0BGhWMQW6gQZBW6ABF6vW7UUMnoKpPnlaR4c2nD+
TWBUzE4bx7k2qTcrXArKOWrv3DMsKgoGNQ33DCco6HLuGwrawHesOJBijTFHcDQ2
ELpR2QyPlIySJ4a2psp4Hc2S43Xh
=eMGE
-----END PGP PUBLIC KEY BLOCK-----" | apt-key add -
fi

# 2015 uber signing key
if ! apt-key finger | grep "6274 DE25 50B4 9DBE 4282  A5BD 6E1F E81A 5875 8881" >/dev/null; then
    echo "-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v1

mQINBFUnHcMBEACz4D/7JsRchq6vF3YsP7UQLi+vie6NtahWR8fUtqIWe7aewDXX
NsMplOHEEwEVt1AgIdeKQYevaUAtEIkDyI+X7Q01ZANIU84PHk1VmNai5cRWAgUm
9XhC36/FySfoH1O9Bfon5uqZANVkImzjm/NmjWvIleVSl1sMkZXhff8jUWNPogAg
gCFmf8isuMGROGEZ87uV5ZRujkRpx24tXvFcLolfuljybm7eCDyaTYwD110Udfhn
EL9+BvnYcQi/QDG14D05kHsw+XpPPoljs2Bnqe42WzufkV7+7xRrin3RPS0YLfop
ic72JhSkgFhbws87Xe7Fwd5P22PXCLa+5M8NhcKFMSvKolcKfDlWfIxBMdQ7OPAD
+dfOeeppSAxyYCLjb9m431ncvUOGZzDnq1TuF9Tr5Pd4x6d8Of5uB/uITkIrHKwa
liBURgKLYLNg0L8QFZAZlTt8WHThdEOnTFK+jwr5sQgl+RhsNu2JElh9gG03nCr4
HJTC3PiJarWvJEr9zq2gNhDNZqDBtRt4VxljNGDqeFWDYtjXMag+V4QuWcNzN1V1
9svIFYaSlhR3y5qfX8kCRwKgle0+N7T+DD4PaKxf/g95sEE9QqpkE7tcUNfMAARS
ffIhGxd90VmKBiSjJL7sdQbBudvsXuKj9pKxiArpZ0o/XyZ/VgA6E7qnrQARAQAB
tCtVYmVyIFBhY2thZ2UgTWFpbnRhaW5lciA8cGFja2FnZXNAdWJlci5jb20+iQI4
BBMBAgAiBQJVJx3DAhsDBgsJCAcDAgYVCAIJCgsEFgIDAQIeAQIXgAAKCRBuH+ga
WHWIgY+oD/wLLEfBo4kl5j8jEGZ/MiC06ah5CSXfWN1DDGJD+5o0ClvEIFm3Jv/l
XoKh7NHjEPjs5jdJdLrnK6ECJhCDIBLP59PZaedmmfn8LgxahrVvMETHslWosWFn
bTyWH1m0Apa2HbnXAsF5gqB77XqgOeZ3kAx6j/EyhJDsaSuJcksM1w7CzRESEyp+
0UlGmeQYR3Y/kLbWdTB54UxisnNMovqWKzmFTCIUAUvbAtZEEIFVs/rjQMDzBydF
fp9mtERWkSGr1Dxq8qA3aW/yjWYEvCXqb58tOilZ4EVeO8gTR6s0E+FJWJ0rZd0c
zyX/5bQITbfRjUQ2Ppl2zBaaDl2YtABMbtz6qsdKIJjDMpg43G1IFgqBfdYWDN6K
agcdqzvfGmDRyUqTD+aa1I/I2axjUKDT+Y3kQM3hlosEdl9hlTBHixPXeJaGwkbq
d4pkqLMf7i/3+eA7q3rd+LVo4ZYCueGB+upbpNx7wN3XhtikrgeU33xOjxCgy8gb
1PUP43hwaH3ghWducwzcEQ2utql/fllXmIZA/ObT9p6Lt7hGjzgCqWxLEdF2a4zo
PY4k00a9vu8YvVpcX2sCpoc1NbL1uJ5tPUCuJ3+iXkkDx6TGYe+8NGMoT7v3QtBZ
eEkcXV+dzWZaV8qxPNaolpg+T2LSxgHvngJfd9vGhR8mibYtqEZ3vrkCDQRVJx3D
ARAAm7K9FhrwKhlX73E5y1DDmmEJwIFubTN/YmjjY3otWFflbwTBMbCJP3SIRdCq
//4tekhD1Q7hSz20kUN7/usbGtbYWbC6WpqqoYNUUIjJP9GfqtPPTJLWWH21d42I
gRntkvAXP8tSoKUzqj+Cbs49hibVdC0kzmtPLYJjYEdHjNSvTchYe2zzmy/rhL5E
3OwlhGPSJ1vkzMO8vXdAHSilmBsiKeiwNVCuEX3/RJbIVVosNxbOogVfx7l0n+4y
5S4x7oLdWC3XamHgww/CmNOOg/oZMxxnIa4voFXfNCMRhxn97INMoXXzcXBD1kfD
nlslfRpWrLiTzxscwJu3EpvPOT4Xh9Fw+glUVcWrJjMQl9GX1wMAVEQSmCT7CKzW
vNRQ7qifYfEnmoqWvCfX8czvcA+aEj2JJbbswC1Kf+QgY6FYmdtnCMQ9aqhfTGY6
QaabwkJS3aRKW7ysiq3oTiDZdAb0hbrzobTbl8bwK7bPtq1TmZRSfJFmDEXDqXfu
yk5L+2QGZg2odCxZRoVcCRPC8EKmPg4WnlQzq+zf0wUYS6rmZ+M6G7LXHUkMgcGg
wH6ZTFNejLw0Yw2Cr6o+idtOccBZ1jtQt+HrlvKVtmvWP5mdaVEh+VbsaU0zGxgx
/VlQjf0RgE35Ime9oYuIRALVNAlFHhvRFH7OWyLvxbTFRmsAEQEAAYkCHwQYAQIA
CQUCVScdwwIbDAAKCRBuH+gaWHWIgfoEEACuoifvyWLrrfs5PQu/8+RpUZxGSnbD
XMhbOyMCTzI+Ryzd8K5a3wqi62ge86vVZ8ofJAb6eMWqML3oznHLRGLh2OCKEAiq
pOSG4DcKsPQxQ3FiQrCIRs0gP9hQWhx8LMXaCD7sgufF2U4PLG1IPO+HcFsiuify
oafrqWYs2kPqN+jcJroFRlSUIQUl4zfakbgyaITXaXbxDwIkKtMU53TUgLd5/Qqi
y+jjj151bKUwX/hMsEzjBwIrhNpYlhjTHay5GB2G0OgAhILxmzxWT6mpizMZbDUc
HlMOQx2/xnMui4kqcGIs/TcdPGdpej2RPp+m5bTAqYNKjiCJyEZHkCmvm3FceYEc
HEGkA8fVyK+SjAXWDw7lQG6oXCD2tv+Hm07uRgX/ld//4ehpaZ3hoxIMJZgOxuye
OHKoZ195dGzn8mm1LB+mCe+7tFqFOxXw+heU+xjwwGym2KNsZpVHc5aAHmrE8R1A
b3GajRH5kPgYrs5BcNNoW4t00gC8lCIlXeYKirbIfgOw8qwo+mBx0iWF3bEy4bVP
8M4QOUJMh/86JfVIjxC0l93uN46ou5wkwO+tkF0ZTGi7goeKOxjr5i+ZPPoy5SCA
Y1z13zbK+LdUnRDbQsFZD3QWdSvRyjmnLXlUQho5pzmZ3PeXtU1Vnt9MtCJrcT98
egJkeMfHDzo8EZkCDQRVJx3DARAAs+A/+ybEXIaurxd2LD+1EC4vr4nujbWoVkfH
1LaiFnu2nsA11zbDKZThxBMBFbdQICHXikGHr2lALRCJA8iPl+0NNWQDSFPODx5N
VZjWouXEVgIFJvV4Qt+vxckn6B9TvQX6J+bqmQDVZCJs45vzZo1ryJXlUpdbDJGV
4X3/I1FjT6IAIIAhZn/IrLjBkThhGfO7leWUbo5EacduLV7xXC6JX7pY8m5u3gg8
mk2MA9ddFHX4ZxC/fgb52HEIv0AxteA9OZB7MPl6Tz6JY7NgZ6nuNls7n5Fe/u8U
a4p90T0tGC36KYnO9iYUpIBYW8LPO13uxcHeT9tj1wi2vuTPDYXChTEryqJXCnw5
VnyMQTHUOzjwA/nXznnqaUgMcmAi42/ZuN9Z3L1Dhmcw56tU7hfU6+T3eMenfDn+
bgf7iE5CKxysGpYgVEYCi2CzYNC/EBWQGZU7fFh04XRDp0xSvo8K+bEIJfkYbDbt
iRJYfYBtN5wq+ByUwtz4iWq1ryRK/c6toDYQzWagwbUbeFcZYzRg6nhVg2LY1zGo
PleELlnDczdVdfbLyBWGkpYUd8uan1/JAkcCoJXtPje0/gw+D2isX/4PebBBPUKq
ZBO7XFDXzAAEUn3yIRsXfdFZigYkoyS+7HUGwbnb7F7io/aSsYgK6WdKP18mf1YA
OhO6p60AEQEAAbQrVWJlciBQYWNrYWdlIE1haW50YWluZXIgPHBhY2thZ2VzQHVi
ZXIuY29tPokCOAQTAQIAIgUCVScdwwIbAwYLCQgHAwIGFQgCCQoLBBYCAwECHgEC
F4AACgkQbh/oGlh1iIGPqA/8CyxHwaOJJeY/IxBmfzIgtOmoeQkl31jdQwxiQ/ua
NApbxCBZtyb/5V6CoezR4xD47OY3SXS65yuhAiYQgyASz+fT2WnnZpn5/C4MWoa1
bzBEx7JVqLFhZ208lh9ZtAKWth251wLBeYKge+16oDnmd5AMeo/xMoSQ7GkriXJL
DNcOws0REhMqftFJRpnkGEd2P5C21nUweeFMYrJzTKL6lis5hUwiFAFL2wLWRBCB
VbP640DA8wcnRX6fZrREVpEhq9Q8avKgN2lv8o1mBLwl6m+fLTopWeBFXjvIE0er
NBPhSVidK2XdHM8l/+W0CE230Y1ENj6ZdswWmg5dmLQATG7c+qrHSiCYwzKYONxt
SBYKgX3WFgzeimoHHas73xpg0clKkw/mmtSPyNmsY1Cg0/mN5EDN4ZaLBHZfYZUw
R4sT13iWhsJG6neKZKizH+4v9/ngO6t63fi1aOGWArnhgfrqW6Tce8Dd14bYpK4H
lN98To8QoMvIG9T1D+N4cGh94IVnbnMM3BENrrapf35ZV5iGQPzm0/aei7e4Ro84
AqlsSxHRdmuM6D2OJNNGvb7vGL1aXF9rAqaHNTWy9biebT1Arid/ol5JA8ekxmHv
vDRjKE+790LQWXhJHF1fnc1mWlfKsTzWqJaYPk9i0sYB754CX3fbxoUfJom2LahG
d765Ag0EVScdwwEQAJuyvRYa8CoZV+9xOctQw5phCcCBbm0zf2Jo42N6LVhX5W8E
wTGwiT90iEXQqv/+LXpIQ9UO4Us9tJFDe/7rGxrW2FmwulqaqqGDVFCIyT/Rn6rT
z0yS1lh9tXeNiIEZ7ZLwFz/LUqClM6o/gm7OPYYm1XQtJM5rTy2CY2BHR4zUr03I
WHts85sv64S+RNzsJYRj0idb5MzDvL13QB0opZgbIinosDVQrhF9/0SWyFVaLDcW
zqIFX8e5dJ/uMuUuMe6C3Vgt12ph4MMPwpjTjoP6GTMcZyGuL6BV3zQjEYcZ/eyD
TKF183FwQ9ZHw55bJX0aVqy4k88bHMCbtxKbzzk+F4fRcPoJVFXFqyYzEJfRl9cD
AFREEpgk+wis1rzUUO6on2HxJ5qKlrwn1/HM73APmhI9iSW27MAtSn/kIGOhWJnb
ZwjEPWqoX0xmOkGmm8JCUt2kSlu8rIqt6E4g2XQG9IW686G025fG8Cu2z7atU5mU
UnyRZgxFw6l37spOS/tkBmYNqHQsWUaFXAkTwvBCpj4OFp5UM6vs39MFGEuq5mfj
Ohuy1x1JDIHBoMB+mUxTXoy8NGMNgq+qPonbTnHAWdY7ULfh65bylbZr1j+ZnWlR
IflW7GlNMxsYMf1ZUI39EYBN+SJnvaGLiEQC1TQJRR4b0RR+zlsi78W0xUZrABEB
AAGJAh8EGAECAAkFAlUnHcMCGwwACgkQbh/oGlh1iIH6BBAArqIn78li6637OT0L
v/PkaVGcRkp2w1zIWzsjAk8yPkcs3fCuWt8KoutoHvOr1WfKHyQG+njFqjC96M5x
y0Ri4djgihAIqqTkhuA3CrD0MUNxYkKwiEbNID/YUFocfCzF2gg+7ILnxdlODyxt
SDzvh3BbIron8qGn66lmLNpD6jfo3Ca6BUZUlCEFJeM32pG4MmiE12l28Q8CJCrT
FOd01IC3ef0Kosvo449edWylMF/4TLBM4wcCK4TaWJYY0x2suRgdhtDoAISC8Zs8
Vk+pqYszGWw1HB5TDkMdv8ZzLouJKnBiLP03HTxnaXo9kT6fpuW0wKmDSo4gichG
R5Apr5txXHmBHBxBpAPH1civkowF1g8O5UBuqFwg9rb/h5tO7kYF/5Xf/+HoaWmd
4aMSDCWYDsbsnjhyqGdfeXRs5/JptSwfpgnvu7RahTsV8PoXlPsY8MBsptijbGaV
R3OWgB5qxPEdQG9xmo0R+ZD4GK7OQXDTaFuLdNIAvJQiJV3mCoq2yH4DsPKsKPpg
cdIlhd2xMuG1T/DOEDlCTIf/OiX1SI8QtJfd7jeOqLucJMDvrZBdGUxou4KHijsY
6+YvmTz6MuUggGNc9d82yvi3VJ0Q20LBWQ90FnUr0co5py15VEIaOac5mdz3l7VN
VZ7fTLQia3E/fHoCZHjHxw86PBE=
=MESN
-----END PGP PUBLIC KEY BLOCK-----" | apt-key add -
fi

# todo?: apt-get install --yes debian-archive-keyring debian-keyring

if ! dpkg -s uber-keyring > /dev/null 2>&1; then
    apt_update_with_retry

    apt-get install --yes uber-keyring
    if [ $? -ne 0 ]; then
        >&2 echo "FATAL ERROR: Unable to install uber-keyring"
        rm /etc/puppet/disabled
        exit 1
    fi

    apt-key update 2>&1  # send stderr to stdout so this isn't scary and red in vagrant
fi

apt_update_with_retry

# install some more things now that we have uber's apt mirrors
apt_get_install curl
apt_get_install virt-what

# todo: also check vmware and any other local machines
if [ "$(virt-what)" = "virtualbox" ]; then
    echo "virtualbox detected"
    DOMAIN="local"  # overlapping with avahi is weird...
    IS_LOCAL="true"
    EC2_STACK_NAME=""

    if [ -e /home/packer/VBoxGuestAdditions.iso ]; then
        echo "Installing dependencies for virtualbox guest additions..."
        apt-get install --yes "linux-headers-$(uname -r)" build-essential dkms

        echo "Installing virtualbox guest additions..."
        mkdir /tmp/VBoxGuestAdditions
        mount /home/packer/VBoxGuestAdditions.iso /tmp/VBoxGuestAdditions
        /tmp/VBoxGuestAdditions/VBoxLinuxAdditions.run
        umount /tmp/VBoxGuestAdditions
        rm -rf /home/packer/VBoxGuestAdditions.iso
    fi
elif [ "$(virt-what)" = "vmware" ]; then
    echo "vmware detected"
    DOMAIN="local"  # overlapping with avahi is weird...
    IS_LOCAL="true"
    EC2_STACK_NAME=""

    echo "Installing Open VMware Tools..."
    if [ "${DISTRIBUTION}" = "precise" ]; then
        VM_TOOL_PKG_NAME="open-vm-tools-lts-trusty"
    else
        VM_TOOL_PKG_NAME="open-vm-tools"
    fi
    apt_get_install $VM_TOOL_PKG_NAME
else
    # todo: don't assume ec2
    echo "virtualbox/vmware not detected. assuming EC2"
    IS_LOCAL=""
    EC2_STACK_NAME=$HOSTNAME

    if [ "$UBER_ENVIRONMENT" = "development" ]; then
        DOMAIN="dev.uber.com"
    elif [ "$UBER_ENVIRONMENT" = "production" ]; then
        >&2 echo "This script is not designed for production systems!"
        rm /etc/puppet/disabled
        exit 1

        # todo: make this script work in dev?
        DOMAIN="prod.uber.com"  # or .internal?
    else
        # todo: make this script work in staging? testing? other?
        >&2 echo "DOMAIN could not be determined from \$UBER_ENVIRONMENT: $UBER_ENVIRONMENT"
        rm /etc/puppet/disabled
        exit 1
    fi
fi
echo "DOMAIN=${DOMAIN}"

# fabric sometimes gets upset if this user doesn't have a config
# this user only exists on ec2
if [ -d "/home/ubuntu" ] && [ ! -e "/home/ubuntu/.ssh/config" ]; then
    echo "Fixing ubuntu user..."
    mkdir -p /home/ubuntu/.ssh
    chmod 750 /home/ubuntu/.ssh
    touch /home/ubuntu/.ssh/config
    chmod 600 /home/ubuntu/.ssh/config
    chown -R ubuntu:ubuntu /home/ubuntu/.ssh/
fi

echo "Setting hostname..."
if ! grep -Fxq "# keep this line last" /etc/hosts; then

    echo "Original /etc/hosts..."
    cat /etc/hosts
    echo ""

    # no /etc/hosts overrides have been run yet
    if [ "$UBER_ENVIRONMENT" = "development" ]; then
        {
            echo;
            echo "# added by packer/vagrant for npm";
            echo "97.64.114.236 archive.local.uber.internal";
            echo "# udeploy slave host name";
            echo "127.0.0.1 devserver-slave";
        } >> /etc/hosts
    fi
    echo "# keep this line last" >> /etc/hosts

else
    sed -i -e '$d' /etc/hosts  # remove the last line (the 127.0.0.1 line) from /etc/hosts
fi
echo "127.0.0.1 ${HOSTNAME}.${DOMAIN} ${ALTNAME}.${DOMAIN} ${HOSTNAME}" >> /etc/hosts
echo "$HOSTNAME" >/etc/hostname
/bin/hostname "$HOSTNAME"  # i thought vagrant would do this on its own, but apparently not on aws

echo "Updated /etc/hosts..."
cat /etc/hosts
echo ""

echo "Setting /etc/altname"
echo "$ALTNAME" >/etc/altname

echo "Setting facts.d..."
if [ -x /usr/bin/update-facts ]; then
    /usr/bin/update-facts /etc/facts.d/uber.json \
        ec2_stack_name="$EC2_STACK_NAME" \
        is_local="$IS_LOCAL" \
        uber_environment="$UBER_ENVIRONMENT" \
        uber_owner="$UBER_OWNER" \
        uber_role="$UBER_ROLE" \
        uber_service="$UBER_SERVICE" 
else
    mkdir -p /etc/facts.d
    echo "{
        \"ec2_stack_name\": \"$EC2_STACK_NAME\",
        \"is_local\": \"$IS_LOCAL\",
        \"uber_environment\": \"$UBER_ENVIRONMENT\",
        \"uber_owner\": \"$UBER_OWNER\",
        \"uber_role\": \"$UBER_ROLE\",
        \"uber_service\": \"$UBER_SERVICE\"
    }" >/etc/facts.d/uber.json
fi

if [ "$UBER_ROLE" = "devserver" ]; then
    if [ -f /tmp/uber_requested_services ]; then
        if [ ! -d /etc/uber ]; then
            echo "Creating /etc/uber"
            mkdir /etc/uber
        fi
        mv /tmp/uber_requested_services /etc/uber/requested_services
        echo "Requested services contains:"
        cat /etc/uber/requested_services
    fi

    echo "Installing udeploy-ds-client..."
    # The version of uDeploy for DevServer is controlled by a file we put into
    # /etc/facts.d and that file is in the udeploy-ds-client package.
    # By installing that manually first, we ensure that the version file is
    # present when puppet runs the first time and picks the correct version of
    # uDeploy to install.
    # udeploy-ds-client is also installed by puppet and kept up-to-date.
    apt_get_install udeploy-ds-client
fi

apt_get_install python-clustoclient
apt_get_install uber-puppet-manifests

# puppet sometimes does weird things when installing ntp. do it here instead
apt_get_install ntp

if [ "$SKIP_BOOTSTRAP_PUPPET" = 'true' ]; then
    # stop puppet from running even if we call `run-puppet` inside this script
    export PUPPET_ALLOW_DISABLED=0
    # Create skip bootstrap puppet file so that we know bootstrap has been skipped
    touch /tmp/bootstrap_skip_puppet
else
    export PUPPET_ALLOW_DISABLED=1
    #rm /tmp/bootstrap_skip_puppet  # todo: remove this line once docs do not recomment touching /tmp/boot...
fi

# do this because packer/vagrant can't upload to /root
if [ -e "/tmp/uber-puppet-manifests/run-puppet" ] && [ ! -e "/root/uber-puppet-manifests" ]; then
    echo "Moving puppet manifests in tmp to /root/..."
    chown -R root:root /tmp/uber-puppet-manifests
    mv /tmp/uber-puppet-manifests /root/
fi

PUPPET_PATCHES="/home/uber/arcpatches/uber-puppet-manifests-*.patch"
if [ -e "/tmp/bootstrap_skip_puppet" ]; then  # todo: use SKIP_BOOTSTRAP_PUPPET instead
    echo "nooping puppet completely because of /tmp/bootstrap_skip_puppet"
    RUN_PUPPET="true"
elif [ "$UBER_ENVIRONMENT" = "development" ] && (stat -t $PUPPET_PATCHES >/dev/null 2>&1 || [ -e /root/uber-puppet-manifests ]); then
    echo "Found arc patches for customization of uber-puppet-manifests..."

    # try to use udeploy's keys since our agent probably requires 2FA
    # WARNING: this is copypasta from run-puppet
    # todo: maybe only do this if the key is recent. If its old, this will definitely fail
    if [ -e "/home/udeploy/.ssh/udeploy_development_1" ]; then
        echo "Using udeploy's SSH keys to clone puppet..."
        # shellcheck disable=SC2046
        eval $(ssh-agent)
        ssh-add /home/udeploy/.ssh/udeploy_development_1
        ssh-add /home/udeploy/.ssh/udeploy_development_2
        ssh-add /home/udeploy/.ssh/udeploy_development_3
        TEMP_SSH_AGENT="true"
        export SSH_USER=udeploy
    elif [ -z "$SSH_AUTH_SOCK" ]; then
        >&2 echo "No SSH_AGENT available and no udeploy development keys to use."
        rm /etc/puppet/disabled
        exit 1
        # this will probably only happen on the very initial run-puppet inside a packer run in which case
        # the manifests should already be up-to-date
    fi

    echo "SSH_USER: ${SSH_USER}"
    if [ "$SSH_USER" = "jenkins" ]; then
        echo "Switching from jenkins to jenkins_packer..."
        export SSH_USER=jenkins_packer
    fi

    ssh-add -L

    apt_get_install git
    apt_get_install make
    apt_get_install python-yaml

    if [ -d "/root/uber-puppet-manifests" ]; then
        echo "/root/uber-puppet-manifests already exists"
    else
        echo "Cloning uber-puppet-manifests..."
        git clone gitolite@code.uber.internal:uber-puppet-manifests /root/uber-puppet-manifests
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Unable to install git clone uber-puppet-manifests"
            rm /etc/puppet/disabled
            exit 1
        fi
    fi

    # todo: copypasta with run-puppet
    pushd /root/uber-puppet-manifests
    if stat -t $PUPPET_PATCHES >/dev/null 2>&1; then
        echo "Found patches for customization of uber-puppet-manifests..."

        echo "Resetting uber-puppet-manifests to origin/master..."
        git fetch
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Unable to install git fetch"
            rm /etc/puppet/disabled
            exit 1
        fi
        git clean -fxd
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Unable to install git clean"
            rm /etc/puppet/disabled
            exit 1
        fi
        git reset --hard origin/master
        if [ $? -ne 0 ]; then
            >&2 echo "FATAL ERROR: Unable to install git reset"
            rm /etc/puppet/disabled
            exit 1
        fi

        for PUPPET_PATCH in $PUPPET_PATCHES; do
            echo "Applying git patch: ${PUPPET_PATCH}"
            cat "$PUPPET_PATCH"
            git apply "$PUPPET_PATCH"
            if [ $? -ne 0 ]; then
                >&2 echo "FATAL ERROR: Unable to apply patch"
                rm /etc/puppet/disabled
                exit 1
            fi
        done
        echo "Git patches applied successfully."
    else
        echo "No patches found at /home/uber/arcpatches for customization of uber-puppet-manifests..."

        if [ "$(git rev-parse --abbrev-ref HEAD)" = "master" ] && test -z "$(git status --porcelain)"; then
            # if /root/uber-puppet-manifests is unmodified master, update it
            git pull
            echo "Making latest master of uber-puppet-manifests..."
        else
            echo ""
            echo ""
            echo "WARNING: NOT updating /root/uber-puppet-manifests or running make because it isn't a clean master checkout"
            echo "YOU MAY NEED TO 'cd /root/uber-puppet-manifests && git merge origin/master' YOURSELF"
            echo ""
            echo ""
            git fetch
        fi
    fi

    if [ "$FIRST_RUN" = "true" ]; then
        # gross hack. we need the uber user to exist to even make our manifests
        adduser --system --group uber
    fi

    echo "Making manifests..."
    make dev all
    if [ $? -ne 0 ]; then
        >&2 echo "FATAL ERROR: Unable to install git"
        rm /etc/puppet/disabled
        exit 1
    fi

    # clean up an ssh-agent if we started one inside this script
    if [ "$TEMP_SSH_AGENT" = "true" ]; then
        kill "$SSH_AGENT_PID"
    fi

    popd

    /bin/chmod 750 /root/uber-puppet-manifests/run-puppet

    export SKIP_APT_UPDATE=1
    # we could call /root/uber-puppet-manifests/run-puppet directly, but then we might miss changes to run-puppet
    RUN_PUPPET="/root/uber-puppet-manifests/run-puppet --show_diff"
    PG_PUPPETBASE="/root/uber-puppet-manifests"
else
    echo "Using packaged puppet..."
    RUN_PUPPET="/usr/sbin/run-puppet"
    PG_PUPPETBASE=""
fi

echo "\$RUN_PUPPET = ${RUN_PUPPET}"

if [ "$FIRST_RUN" != true ]; then
    mkdir -p /etc/puppet
    touch /etc/puppet/hiera.yaml
fi

echo "Running puppet $(puppet --version) for everything (this may fail. that is okay but not great)..."
$RUN_PUPPET
if [ $? -ne 0 ]; then
    >&2 echo "Run puppet failed. Will run puppet again after updating apt (if necessary) and some simple checks"
    MORE_PUPPET="true"
else
    echo "Puppet succeeded. You will probably not need more puppet"
    MORE_PUPPET="false"
fi

if [ "$FIRST_RUN" != "true" ] && [ "$WITH_AWS_DNS" = "true" ] && [ -x "/usr/local/bin/update_dev_dns.sh" ]; then
    # todo: it would be awesome if this was in puppet
    # don't both do this on the first run since instances made with packer don't need DNS setup
    echo "Updating DNS... If this fails, run 'boxer v ${HOSTNAME} -c \"ssh -- /usr/local/bin/update_dev_dns.sh\"'"
    /usr/local/bin/update_dev_dns.sh
    if [ $? -ne 0 ]; then
        >&2 echo "Updating DNS failed. After provisioning completes, run 'boxer v ${HOSTNAME} -c \"ssh -- /usr/local/bin/update_dev_dns.sh\"'"
    fi
fi

if [ -x "/etc/init.d/postgresql" ]; then
    # todo: it would be awesome if this was in puppet or if ubuntu did the right thing in the first place
    echo "Adjusting postgresql if it is installed improperly..."
    # wait up to 2 minutes for postgres to start
    tick=0
    limit=${STARTUP_TIME_LIMIT:-30}
    until sudo -u postgres psql -c '\l'; do
        tick=$((tick + 1))
        echo "waiting... $tick"
        sleep 10
        if [ "$tick" -ge "$limit" ]; then
            echo "Timeout exceeded!"
            break
        fi
    done

    CURRENT_LOCALE=$(sudo -u postgres psql -c "SHOW LC_COLLATE;" | sed -n 3p | tr -d ' ')
    echo "CURRENT_LOCALE: ${CURRENT_LOCALE}"
    echo "EXPECTED LOCALE: ${PG_LOCALE}"
    if [ "$CURRENT_LOCALE" != "$PG_LOCALE" ]; then
        echo "Dropping existing postgres cluster..."
        service postgresql stop && sleep 10
        pg_dropcluster 9.2 main --stop
        if [ -e /mnt/postgres_db_installed ]; then
            rm /mnt/postgres_db_installed
        fi

        echo "Creating minimal postgres cluster..."
        # this is the fastest way to get a very basic working database
        # todo: if postgres isn't running, might be best to move the stopped cluster instead of dropping it
        pg_createcluster --locale="$PG_LOCALE" 9.2 main --start
        sleep 10
        sudo -u postgres psql -c "CREATE ROLE uber WITH LOGIN PASSWORD 'uber' SUPERUSER;"

        # force puppet run to fix postgres configs
        MORE_PUPPET="true"
    fi
fi

if [ -x "/usr/local/bin/install_dev_pg_cluster.sh" ]; then
    # todo: it would be awesome if this was in puppet
    PUPPET_ALLOW_DISABLED=$PUPPET_ALLOW_DISABLED PUPPETBASE=$PG_PUPPETBASE /usr/local/bin/install_dev_pg_cluster.sh
    # exit code 0 means the script worked and ran puppet itself
    # exit code 2 means we didn't change anything
    if [ $? -eq 1 ]; then
        >&2 echo "install_dev_pg_cluster exited with an error."
        MORE_PUPPET="true"
    fi
fi

if [ -x "/usr/local/bin/certs_valid" ] && [ -x "/usr/local/bin/fetch_ssl" ]; then
    # todo: this is also done by puppet, but sometimes puppet is disabled and we still want this
    if /usr/local/bin/certs_valid; then
        echo "SSL certificates were installed correctly and have not expired..."
    else
        echo "Fetching new SSL certificates..."
        /usr/local/bin/fetch_ssl
        if [ $? -ne 0 ]; then
            >&2 echo "Fetching SSL certs failed.  Sleeping 60 seconds, then trying again"
            sleep 60
            /usr/local/bin/fetch_ssl
            if [ $? -ne 0 ]; then
                >&2 echo "Fetching SSL certs failed a second time. Puppet will try again later."
            fi
        fi
        # a full puppet run is excessive. an nginx reload is enough although one day we may need to refresh other things with certs
        # MORE_PUPPET="true"
        service nginx reload
    fi
fi

if [ -x "/etc/init.d/avahi-daemon" ]; then
    # todo: it would be awesome if this was in puppet
    echo "Restarting avahi-daemon... (virtualbox suspends can break it)"
    service avahi-daemon restart
    if [ -e "/etc/supervisor/uber-avahi-publisher.ini" ]; then
        echo "Restarting uber-avahi-publisher... (virtualbox suspends can break it)"
        supervisorctl restart uber-avahi-publisher
    fi
fi

# todo: this seems to be installed even without uber::service::twemproxy
if [ -x "/usr/local/bin/gracefully-restart-twemproxy" ]; then
    # todo: it would be awesome if this was in puppet
    echo "Gracefully restarting twemproxy..."
    # twemproxy gets confused by virtualbox suspends
    # send stderr to stdout because these messages are scary
    /usr/local/bin/gracefully-restart-twemproxy 2>&1
fi

echo "MORE_PUPPET: ${MORE_PUPPET}"
if [ "$MORE_PUPPET" = "true" ]; then
    echo "Running more puppet $(puppet --version) for everything..."
    apt_update_with_retry
    $RUN_PUPPET && EXIT_CODE=0 || EXIT_CODE=$?
    echo "run-puppet exit code for cleanup run: ${EXIT_CODE}"

    if [ $EXIT_CODE -ne 0 ] && [ "$FIRST_RUN" = "true" ]; then
        >&2 echo "Running more puppet $(puppet --version) a second time since this if the first bootstrap (if this fails, we will exit)..."
        apt_update_with_retry
        $RUN_PUPPET && EXIT_CODE=0 || EXIT_CODE=$?
        echo "run-puppet exit code for cleanup run 2: ${EXIT_CODE}"
    fi

    if [ $EXIT_CODE -ne 0 ]; then
        >&2 echo "Puppet $(puppet --version) failed! Ask for help in Eng-To-Eng DevTools HelpDesk."
        rm /etc/puppet/disabled
        # we used to retry a bunch here, but that just leads to long running tests
        # if two runs can't do it (one earlier and then this one), we should fail
        exit 1
    fi
fi

if [ "$FIRST_RUN" = "true" ]; then
    # todo: I would like this to be done every run, but test-puppet-on-vagrant doesn't like it :(
    if [ -x "/etc/init.d/supervisor" ]; then
        echo "Checking supervisor..."
        supervisorctl update
        if [ $? -ne 0 ]; then
            >&2 echo "Supervisor is not running or could not read one of its configs! Aborting the build."
            rm /etc/puppet/disabled
            exit 1
        fi
    fi

    if [ -e "/usr/bin/uds-packer-bootstrap" ]; then
        if [ -s "/etc/uber/requested_services" ]; then
            # if we have no requested services (file has no contents), build legacy-style
            echo "Found /etc/uber/requested_services..."
            cat /etc/uber/requested_services

            echo
            echo "In the future, this file will limit what packer builds"
        else
            echo "/etc/uber/requested_services does not exist. Building all the things..."
        fi

        echo "uDeploy DevServer Toolkit - packer bootstrap script found"

        echo "Checking udeployd-master..."
        supervisorctl status udeployd-master | grep RUNNING
        if [ $? -ne 0 ]; then
            >&2 echo "udeployd-master is not running! Aborting the build."
            rm /etc/puppet/disabled
            exit 1
        fi

        # touch a file so crqm can start
        CRQM_STATE_FILE=/etc/uber/supervisor_ensure.d/api-celery-crqm-load
        if [ ! -e $CRQM_STATE_FILE ]; then
            echo "running" >$CRQM_STATE_FILE
            DELETE_CRQM_STATE_FILE="true"
        fi

        # Make sure that we have the latest uDeploy service and deployment lists from S3
        cd ~uber
        sudo -H -u uber /usr/local/bin/udeploy_services_import

        echo "Running uDeploy import script..."
        /usr/bin/uds-packer-bootstrap
        if [ $? -ne 0 ]; then
            >&2 echo "udeployd-master is not running! Aborting the build."
            rm /etc/puppet/disabled
            exit 1
        fi

        if [ "$DELETE_CRQM_STATE_FILE" = "true" ]; then
            # delete the crqm file if we created it in this script
            rm $CRQM_STATE_FILE
        fi

        if [ ! -x /var/cache/udeploy/provision/api.sh ]; then
            echo "API failed to build under udeploy (and did not generate the /var/cache/udeploy/provision/api.sh script)! Aborting"
            rm /etc/puppet/disabled
            exit 1
        fi
        if [ ! -h /etc/uber/api/logging.yaml ]; then
            echo "API failed to start under udeploy (and did not generate the /etc/uber/api/logging.yaml symlink)! Aborting"
            rm /etc/puppet/disabled
            exit 1
        fi
    fi

    echo "Sanitizing image..."
    rm -rf /etc/ssl/devstar.uber.com.*
    rm -rf /var/lib/uber/dotfiles/*
    apt-get --yes clean
    apt-get --yes autoclean
    apt-get --yes autoremove
    find /var/lib/apt/lists -type f -not -name lock -print0 | xargs -0 rm
    for NAME in /var/cache/*; do
        if [ "$NAME" != "/var/cache/udeploy" ]; then
            rm -rf "$NAME"
        fi
    done

    if [ "$(virt-what)" = "virtualbox" ]; then
        echo "virtualbox first run detected!"

        echo "Cleaning up unused disk space so compressed image is smaller..."
        cat /dev/zero > /tmp/zero.fill
        rm /tmp/zero.fill
        echo "Free space zerod."
    fi
fi

if [ "$SKIP_BOOTSTRAP_PUPPET" = 'true' ]; then
    echo "Leaving puppet disabled. Enable with 'sudo enable_puppet'"
else
    echo "Enabling standard puppet runs..."
    enable_puppet
fi

echo "Waiting for any backgrounded processes to complete..."
wait

echo "bootstrap.sh complete."
uptime
