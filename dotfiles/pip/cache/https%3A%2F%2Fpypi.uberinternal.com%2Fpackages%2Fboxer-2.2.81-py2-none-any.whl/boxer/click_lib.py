import contextlib
import functools
import getpass
import glob
import itertools
import logging
import os
import os.path
import pprint
import subprocess
import sys
import tempfile

from boto.s3.connection import S3Connection
from click.decorators import _make_command
import boto
import click
import lockfile
import yaml

from boxer import config
from boxer.lib import fqdn_from_name, get_box_filename, sanitize_vagrant_name, verify_ssl_certificate


log = logging.getLogger(__name__)

aws_region_type = click.Choice(config.AWS_REGIONS)
aws_type_type = click.Choice(config.AWS_INSTANCE_TYPES)
# current_boxes_type = click.Choice(get_current_boxes().keys())  # import time logic :'(
distro_type = click.Choice(config.VALID_DISTROS)
domain_type = click.Choice(config.VALID_DOMAINS)
provider_type = click.Choice(config.VALID_PROVIDERS)
uber_env_type = click.Choice(config.VALID_UBER_ENV)
vagrant_sort_type = click.Choice(config.VAGRANT_COLS)

_bucket = None
_s3_conn = None
_r53_conn = None


@contextlib.contextmanager
def boxer_lock(click_ctx, lockname, timeout=30):
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    lock_filename = os.path.join(boxer_config.get('boxer_home'), '.lock-%s' % lockname)
    lock = lockfile.LockFile(lock_filename)
    try:
        log.debug("Waiting up to %d seconds to lock: %s", timeout, lockname)

        try:
            lock.acquire(timeout=timeout)
        except lockfile.LockError as e:
            if boxer_config.get('library'):
                raise
            else:
                fail(click_ctx, msg=str(e))

        log.debug("lock acquired: %s", lockname)
        yield
    finally:
        if lock.i_am_locking():
            lock.release()


def click_command(name=None, cls=None, group=None, **kwargs):
    """Helper for click commands that preserves docstrings for sphinx autodoc.

    Inspired by https://coderwall.com/p/et9mjq/making-the-click-command-decorator-behave-well-for-sphinx-auto-docs

    .. TODO:: write a sphinx extension instead. this is pretty hacky and doesn't work great
    """
    if cls is None:
        cls = click.Command

    def decorator(f):
        if os.environ.get('INSIDE_SPHINX', False):  # pragma: no cover
            # this is set by docs/conf.py
            # this does not at all seem to be the right thing to do
            return f
        else:
            r = _make_command(f, name, kwargs, cls)
            r.__doc__ = f.__doc__
            if group:
                group.add_command(r)
            return r
    return decorator


def click_vagrant_options(func):
    """Options shared by vagrant/claim_vagrant/create_vagrant."""

    @click.option('--add-all-boxes', default=False, is_flag=True, help="Add all provider's boxes to vagrant")
    @click.option('--aws-ami', help='Advanced: AWS Only: ami-id to use INSTEAD OF THE BOX')
    @click.option(
        '--aws-disk-size',  # todo: make this work with more than just aws
        default=config.DEFAULT_AWS_DISK_SIZE,
        help='AWS Only: Size in GB of /. If 0, / will be the default for the AMI.',
        type=click.IntRange(min=100, max=1000),
    )
    @click.option('--aws-keypair', default=config.DEFAULT_AWS_KEYPAIR, help='Advanced: AWS Only: root keypair to use',)
    @click.option(
        '--aws-mnt-size',
        default=config.DEFAULT_AWS_MNT_SIZE,
        help='AWS Only: Size in GB of /mnt. If 0, this disk will not be mounted.',
        type=click.IntRange(min=0, max=1000),
    )
    @click.option('--aws-region', default=config.DEFAULT_AWS_REGION, type=aws_region_type)
    @click.option('--aws-type', type=aws_type_type, default=config.DEFAULT_AWS_TYPE)
    @click.option(
        '--aws-zone',
        default='b',  # todo: round robin zones/T34515
        help='AWS Only: Availability zone to launch. Can be full zone or just the suffix',
    )
    @click.option(
        '--box-name',
        # type=current_boxes_type,  # todo: custom time that checks valid values as late as it can
        help="Advanced: Full box name to use. You probably don't need this",
    )
    @click.option('--build-num', help="Box build_num to use. Defaults to the newest box on S3.")
    @click.option('--check-existing/--no-check-existing', default=True)
    @click.option('--create-log', default=None, type=click.File('a+'), help="Send output of 'vagrant up/provision' to this file. Defaults to stdout")
    @click.option(
        '--destroy-scripts-local',
        help="Comma-separated list of additional destroy scripts to run on the localhost",
    )
    @click.option('--distro', default=config.DEFAULT_DISTRO, type=distro_type)
    @click.option('--env', default=config.DEFAULT_UBER_ENV, type=uber_env_type)
    @click.option('--email', envvar='UBER_OWNER')
    @click.option(
        '--fallback-role',
        default='base',
        help='Advanced: Role to fallback to if box for primary role not found'
    )
    @click.option('--force', is_flag=True, default=False, help='Advanced: force creation without prompting')
    @click.option('--launch', '--launch-provider', type=provider_type, help='Provider to launch as soon as the Vagrantfile is ready')
    @click.option('--with-launch/--no-launch', default=True)
    @click.option(
        '--override-role',
        help="Use this role no matter the original box's role",
    )
    @click.option('--prefix', default='uber', help='Box filename prefix')
    @click.option('--private-keys', default=config.DEFAULT_SSH_KEYS, help='Advanced: Comma-separated ssh keys to try')
    @click.option(
        '--providers',
        default=','.join(config.DEFAULT_PROVIDERS),
        help="comma-separated list of vagrant providers to search for",
    )
    @click.option(
        '--provision-scripts-vagrant',
        help="Comma-separated list of additional provision scripts to run on the vagrant",
    )
    @click.option(
        '--puppet-diffs',
        help="Comma-separated list of arc diffs to include in run-puppet",
    )
    @click.option(
        '--puppet-includes',
        help="Comma-separated list of boxer's service files to include in run-puppet",
    )
    @click.option(
        '--puppet-custom-includes',
        help="Comma-separated list of puppet services to include in run-puppet (like uber::service::foo)",
    )
    @click.option(
        '--puppet-custom-include-files',
        help="Comma-separated list of full paths to custom puppet service filess to include in run-puppet",
    )
    @click.option('--role', default=config.DEFAULT_UBER_ROLE)
    @click.option(
        '--ssh-username',
        default='uber',  # todo: stop using a shared user
        help="Advanced: User for Vagrant's SSH (default: uber)",
    )
    @click.option(
        '--services',
        help="Comma-separated list of services to configure instance for (udeploy, puppet)",
    )
    @click.option(
        '--uber-service',
        default='vagrant',
        help="DONT TOUCH ME. Sets AWS tags for filters",
    )
    @click.option('--update/--no-update', default=False, help='Replace an existing Vagrantfile and boxes.yaml')
    @click.option('--vbox-ip', default='33.33.33.10', help='Advanced: Virtualbox Only: IP to use')
    @click.option('--vmware-ip', default='34.33.33.10', help='Advanced: VMware Only: IP to use')
    @click.option('--with-aws-dns/--no-aws-dns', default=True, help='If true, setup DNS with update_dev_dns.sh')
    @click.option('--with-aws-vpc/--no-aws-vpc', help='Launch an instance in the VPC instead of the public Internet',)
    @click.option(
        '--with-bootstrap-puppet/--no-bootstrap-puppet',
        default=True,
        help='If True, run puppet run during the provisioning',
    )
    @click.option(
        '--with-custom-config/--no-custom-config',
        default=False,
        help='If True, open the boxes.yaml for interactive editing',
    )
    @click.option('--with-ssh/--no-ssh', default=True, help='If true, ssh into the box when using --launch')
    @click.option('--with-ssl/--no-ssl', default=True, help='If true, fetch the SSL certificates when using --launch')
    @click.option(
        '--with-update-terminates/--no-update-terminates',
        default=True,
        help='Prompt termination or not on --update',
    )
    @click.pass_context
    @functools.wraps(func)
    def wrapped(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapped


@contextlib.contextmanager
def open_box_config(ctx, name):
    boxer_config = ctx.find_object(config.BoxerConfig)

    vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)
    yaml_filename = os.path.join(vagrant_dir, 'boxes.yaml')

    with open(yaml_filename, 'r') as f:
        box_config = yaml.safe_load(f)

    try:
        yield box_config
    finally:
        # save the yaml
        with open(yaml_filename, 'w') as f:
            f.write(yaml.safe_dump(box_config))


# todo: I don't like this at all. rewrite this to not need the click_ctx
def create_packer_variables(
    click_ctx,
    build_num=None,
    env='development',
    interactive=False,
    owner_email=None,
    prefix='uber',
    role='devserver',
    services_file=None,
):
    """Gather variables from the environment and prompts for packer's -var-file."""
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    if not interactive and not build_num:  # pragma: no cover
        fail(click_ctx, msg="BUILD_NUMBER required, but not set. Try --interactive")

    user = getpass.getuser()

    # variables that packer requires
    # todo: all these should be passed in as flags that click can also get from the env
    possible_data = {
        'aws_access_key': boxer_config.get('AWS_ACCESS_KEY'),
        'aws_secret_key': boxer_config.get('AWS_SECRET_KEY'),
        'image_build_num': build_num or "%s%s" % (user, 0),  # todo: not sure I like this
        'image_name_prefix': prefix,
        'uber_environment': env,
        'uber_owner': owner_email,
        'uber_role': role,
        'aws_region': os.environ.get('AWS_REGION', ''),
        'aws_zone': os.environ.get('AWS_ZONE', ''),
        'instance_type': os.environ.get('INSTANCE_TYPE', ''),
        'puppet_dir': os.environ.get('PUPPET_DIR', ''),
        'source_ami': os.environ.get('SOURCE_AMI', ''),
        'services_file': services_file,
        'vm_cpu': os.environ.get('VM_CPU', ''),
        'vm_memory': os.environ.get('VM_MEMORY', ''),
    }

    # check the variables with the user if interactive
    if interactive:
        data = {}

        # prompt these first
        first_items = [
            'uber_owner',
            'image_build_num',
            'uber_role',
            'uber_environment',
            'puppet_dir',
            'aws_access_key',
            'aws_secret_key',
        ]

        click.secho(
            'Prompting for packer variables interactively. The defaults are probably fine for the most part.\n',
            fg='yellow',
        )

        # todo: prompt for things that need values first
        for key, value in itertools.chain(itertools.izip_longest(first_items, ()), possible_data.iteritems()):
            if key in data:
                # this key has already been prompted
                continue

            if not value and key in first_items:
                value = possible_data.get(key, None)

            # todo: is there a better way to do this?
            if key == 'image_build_num':
                click.secho(
                    ("REQUIRED! We recommend your ldap username and then a number. so bwstitt would use "
                     "bwstitt0, bwstitt1, etc."),
                    fg='yellow',
                )
            elif key == 'uber_owner':
                click.secho(
                    ("REQUIRED! This should be your @uber.com email address. You probably won't get any emails"
                     " from the build, but you might."),
                    fg='yellow',
                )
            elif key == 'puppet_dir':
                click.secho(
                    "Optional absolute path to a local checkout of the puppet-manifests.",
                    fg='yellow',
                )

            data[key] = click.prompt(key, default=value)
            click.echo('')
    else:  # pragma: no cover
        data = possible_data

    # filter empty values and strip bad characters
    for key, value in data.items():
        if key == 'image_build_num':
            # todo: move this to a separate function
            if '-' in value:
                log.info("Replacing dashes in build_num with underscores")
                data[key] = value.replace('-', '_')
        if not value:
            del data[key]

    # return a dict to be turned into json
    loggable_data = data.copy()
    loggable_data['aws_secret_key'] = 'XXXXXXXX'
    log.info("var_file data: %s", pprint.pformat(loggable_data))

    # abort if required things are not set
    # todo: is this necessary anymore?
    if not data.get('image_build_num'):
        # todo: make sure this is not a duplicate
        fail(click_ctx, msg="BUILD_NUMBER required, but not set. Try setting --build-num, --interactive")
    if not data.get('uber_owner'):
        # todo: make sure its a valid email address
        fail(click_ctx, msg="UBER_OWNER required, but not set to an @uber email address. Try --owner-email, --interactive, or set UBER_OWNER")
    if 'puppet_dir' in data and data['puppet_dir'] and not os.path.exists(data['puppet_dir']):
        # todo: make sure the directory exists
        fail(click_ctx, msg="PUPPET_DIR set, but the given path does not exist")

    if interactive:
        click.confirm(click.style("\nStart the build with packer?", fg='yellow'), abort=True, default=True)
    return data


def get_local_certificate_name(click_ctx, fqdn):
    boxer_config = click_ctx.find_object(config.BoxerConfig)
    return os.path.join(
        boxer_config.get('BOXER_SYNC_ROOT'),
        "%s.%s" % (fqdn, boxer_config.get('DEV_SSL_CERTIFICATE')),
    )


def get_current_cloud_vagrants(click_ctx, **kwargs):
    # circular imports... weee....
    from boxer.commands.list_vagrants import list_vagrants

    log.info("Fetching the list of running vagrants...")
    result = click_ctx.invoke(list_vagrants, state='running', with_echo=False, **kwargs)
    if not result:
        fail(click_ctx, msg="Failed listing vagrants")

    return result.output


def check_current_cloud_vagrants(click_ctx, name):
    current_vagrants = get_current_cloud_vagrants(click_ctx, name=name)

    existing_with_same_name = [v for v in current_vagrants if v['name'] == name]

    if existing_with_same_name:
        log.error("Found %d existing vagrant(s) in the cloud named %s!", len(existing_with_same_name), name)

        for v in existing_with_same_name:
            command = click.style("boxer aws terminate {id} --region {region}", fg='yellow').format(
                id=v['aws_id'],
                region=v['aws_region_name'],
            )
            log.error("To terminate the instance launched on %s: %s", v['launch_time'], command)

        log.error(click.style(
            "Refusing to launch an instance with a duplicate name. Terminate other instances first or pick a new name.",
            fg='red',
        ))
        fail(click_ctx)


class BoxerClickReturn(object):
    """Mimic subprocess."""

    def __init__(self, output=None, returncode=0):
        self.output = output
        self.returncode = returncode
        # todo: self.name = name?

    def __bool__(self):
        return self.returncode == 0

    def __str__(self):
        return str(self.output)


def fail(click_ctx, msg="boxer failed", output=None):
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    if boxer_config.get('library'):
        log.error(msg)
        return BoxerClickReturn(output=output, returncode=2)
    else:
        log.error(click.style(msg, fg="red"))
        click_ctx.exit(2)


def get_current_vagrants(click_ctx):
    """yield all directories in the vagrant root dir.boxer_config.

    .. TODO:: support multiple vagrants inside one config
    """
    boxer_config = click_ctx.find_object(config.BoxerConfig)
    root_dir = boxer_config.get('VAGRANT_ROOT')
    for vagrant_dir in glob.glob(os.path.join(root_dir, '*')):
        yield os.path.basename(vagrant_dir)


def is_local_vagrant_or_fail(click_ctx, name, try_import=True, force=None):
    boxer_config = click_ctx.find_object(config.BoxerConfig)
    root_dir = boxer_config.get('VAGRANT_ROOT')

    if force is None and boxer_config.get('library'):
        force = True

    name = sanitize_vagrant_name(name)

    current_vagrants = list(get_current_vagrants(click_ctx))
    if name not in current_vagrants:
        log.info("Vagrant files for '%s' not available in '%s'", name, root_dir)
        if try_import and (force or click.confirm("Attempt to download Vagrantfile for {}?".format(name), default=True)):
            try:
                # circular imports. we can't do this at the top
                from boxer.commands.import_vagrant import import_vagrant
                click_ctx.invoke(import_vagrant, claim=False, delete_remote=False, name=name)
            except Exception:
                # todo: don't except so much
                fail(click_ctx, msg="Vagrant files for '%s' not available remotely" % name)
        else:
            fail(click_ctx, msg="Valid choices for name: %s" % (' '.join(current_vagrants)))

    return name


def get_box_urls(click_ctx, bucket, distro, env, num, prefix, provider, role, expire=86400):
    """get an https url from S3 that will expire."""
    boxer_config = click_ctx.find_object(config.BoxerConfig)
    box_filename = get_box_filename(
        env=env,
        distro=distro,
        num=num,
        prefix=prefix,
        provider=provider,
        role=role,
    )

    results = []

    local_filename = os.path.join(boxer_config.get('BOXER_HOME'), 'boxes', box_filename)
    results.append(local_filename)

    # this used to be "vagrants", but that was too vague
    s3_key = bucket.get_key('vagrant_boxes/' + box_filename)
    if s3_key:
        s3_download_url = s3_key.generate_url(expires_in=expire)
        results.append(s3_download_url)

    return results


def get_s3_bucket(click_ctx):
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    # ghetto global "caching"
    global _bucket
    if _bucket is None:
        _bucket = get_s3_connection(click_ctx).get_bucket(boxer_config.get('S3_BUCKET'))
    return _bucket


def get_s3_connection(click_ctx):
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    # ghetto global "caching"
    # todo: use ~/.boto
    global _s3_conn
    if _s3_conn is None:
        _s3_conn = S3Connection(boxer_config.get('AWS_ACCESS_KEY'), boxer_config.get('AWS_SECRET_KEY'))
    return _s3_conn


def get_route53_connection(click_ctx):
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    # ghetto global "caching"
    # todo: use ~/.boto
    global _r53_conn
    if _r53_conn is None:
        _r53_conn = boto.connect_route53(boxer_config.get('AWS_ACCESS_KEY'), boxer_config.get('AWS_SECRET_KEY'))
    return _r53_conn


def get_server_role(
    click_ctx, name_or_fqdn,
    default_domain=config.DEFAULT_DOMAIN,
    force=False,
    with_dns=True,
    with_vagrantfile=True,
):
    return vagrant_ssh(
        click_ctx, name_or_fqdn,
        command=["cat", "/etc/uber/role"],
        default_domain=default_domain,
        force=force,
        with_dns=with_dns,
        with_vagrantfile=with_vagrantfile,
    )


def is_local_cert_same_with_remote(click_ctx, fqdn, certfile, with_dns=True, with_vagrantfile=True):
    """Compares local SSL cert with remote cert and returns True if same.

    :param str fqdn: The fully qualified domain name to compare SSL cert.
    :param str certfile: The local SSL cert file.
    :return bool: True if both are the same.
    """
    boxer_config = click_ctx.find_object(config.BoxerConfig)

    remote_cert = vagrant_ssh(
        click_ctx,
        fqdn,
        command=[
            "cat",
            "/etc/ssl/%s" % (boxer_config.get('DEV_SSL_CERTIFICATE')),
        ],
        with_dns=with_dns,
        with_vagrantfile=with_vagrantfile,
    )
    local_cert = subprocess.check_output(["cat", certfile])
    return remote_cert == local_cert


def revoke_trust_ssl_certificate(ctx, filename):
    if sys.platform == 'darwin':
        if os.environ.get('TMUX'):
            log.error(
                click.style(
                    "Apple's security tool does not like tmux. Try running your command outside tmux.",
                    fg='red',
                )
            )
            return

        log.info("Revoking trust of %s will prompt for authorization", filename)
        remove_retcode = subprocess.call(
            ["security", "remove-trusted-cert", "-d", filename])
        if remove_retcode != 0:
            log.warning("SSL cert removal failed! It is mostly likely because "
                        "the cert %s was not installed. But if you have any "
                        "question, contact DevTools!", filename)
        else:
            os.unlink(filename)
            log.info("Certificate trust removed for %s", filename)
    else:
        log.info(
            click.style(
                "Automatic removal of keys is not yet supported for '%s'. Please un-trust and delete '%s' manually",
                fg='red',
            ),
            sys.platform,
            filename,
        )


def trust_ssl_certificate(click_ctx, filename):
    if sys.platform == 'darwin':
        if os.environ.get('TMUX'):
            log.error(
                click.style(
                    "Apple's security tool does not like tmux. Try running your command outside tmux.",
                    fg='red',
                )
            )
            return

        log.info("This will prompt for your local password for authorization...")
        ssl_installation_retcode = subprocess.call([
            "security", "add-trusted-cert", "-d", "-r", "trustRoot", "-k",
            "/Users/%s/Library/Keychains/login.keychain" % (getpass.getuser()),
            filename])
        if ssl_installation_retcode != 0:
            log.error("Your devserver SSL certificate installation failed! "
                      "Please contact DevTools!")
        if not verify_ssl_certificate(filename):
            # Raises error if newly installed cert is not valid.
            fail(click_ctx, msg="Certificate installed, but does not appear to be valid. Ask for help")
    else:
        log.info(
            click.style(
                "Automatic installation of keys is not yet supported for '%s'. Please trust '%s' manually",
                fg='yellow',
            ),
            sys.platform, filename,
        )


# todo: allow setting user here?
def vagrant_ssh(
    click_ctx, name_or_fqdn,
    command=[],
    default_domain=config.DEFAULT_DOMAIN,
    force=False,
    ssh_command='ssh',
    with_dns=True,
    with_vagrantfile=True,
):
    full_command = [ssh_command]

    connect_method = None
    temp_ssh_config = None
    try:
        if not connect_method and with_vagrantfile:
            if name_or_fqdn not in get_current_vagrants(click_ctx):
                # todo: run boxer import_vagrant
                log.debug("No local Vagrantfile found for %s", name_or_fqdn)
                pass
            else:
                # no need to append the domain since we are using ssh-config by name
                # todo: ask vagrant for the name? might help with multiple vagrants in one config
                fqdn = name_or_fqdn

                # todo: memoize/cache this?
                try:
                    with tempfile.NamedTemporaryFile(delete=False) as temp_ssh_config:
                        # todo: something to make sure this is a name and not a fqdn
                        temp_ssh_config.write(subprocess.check_output([
                            'boxer', 'v', name_or_fqdn, '-c', 'ssh-config'
                        ]))
                except subprocess.CalledProcessError as e:
                    log.debug("Failed using Vagrantfile for %s: %s", ssh_command, e)
                else:
                    log.debug("Using 'vagrant ssh-config' for %s...", ssh_command)
                    full_command.extend(['-F', temp_ssh_config.name])
                    connect_method = 'Vagrantfile'

        if not connect_method and with_dns:
            log.debug("Using DNS for %s...", ssh_command)

            fqdn = fqdn_from_name(name_or_fqdn, default_domain=default_domain)

            temp_ssh_config = None
            connect_method = 'DNS'

        if not connect_method:
            fail(click_ctx, msg="Could not connect with Vagrantfile or DNS")

        if force:
            full_command.extend(["-o", "StrictHostKeyChecking=no"])

        if ssh_command == 'ssh':
            full_command.append(fqdn)
            full_command.extend(command)
        elif ssh_command == 'scp':
            for c in command:
                full_command.append(c.format(fqdn=fqdn))
        else:  # pragma: no cover
            raise NotImplementedError

        log.debug("Running command: %s", " ".join(full_command))
        result = subprocess.check_output(full_command)
    except subprocess.CalledProcessError as e:
        if e.returncode == 130:
            # ssh exit with 130 is fine
            pass
        else:
            raise
    finally:
        if temp_ssh_config:
            os.unlink(temp_ssh_config.name)

    return result


def vagrant_scp(
    click_ctx,
    name_or_fqdn,
    source_filename,
    target_filename,
    default_domain=config.DEFAULT_DOMAIN,
    force=False,
    with_dns=True,
    with_vagrantfile=True,
):
    # todo: allow adding things to the command?
    return vagrant_ssh(
        click_ctx,
        name_or_fqdn,
        command=[source_filename, target_filename],
        default_domain=default_domain,
        force=force,
        ssh_command='scp',
        with_dns=with_dns,
        with_vagrantfile=with_vagrantfile,
    )


def quick_s3_get(click_ctx, filename, target_filename=None):
    """Download a file from S3 to a returned string or a target_filename"""
    file_link = get_s3_bucket(click_ctx).get_key(filename)
    if not file_link:
        return None
    if target_filename is None:
        return file_link.get_contents_as_string().strip()
    else:
        return file_link.get_contents_to_filename(target_filename)
