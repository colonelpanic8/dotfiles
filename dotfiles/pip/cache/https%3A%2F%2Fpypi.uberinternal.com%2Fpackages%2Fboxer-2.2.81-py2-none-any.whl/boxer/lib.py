from distutils.version import LooseVersion
import logging
import glob
import os
import os.path
import re
import shutil
import subprocess
import sys
import tempfile

import click
import psutil
import which

from boxer import config

try:
    from setuptools.py31compat import TemporaryDirectory
except ImportError:  # pragma: no cover
    # copypasta of https://github.com/jaraco/setuptools/blob/master/setuptools/py31compat.py
    class TemporaryDirectory(object):
        """"
        Very simple temporary directory context manager.
        Will try to delete afterward, but will also ignore OS and similar
        errors on deletion.
        """
        def __init__(self):
            self.name = None  # Handle mkdtemp raising an exception
            self.name = tempfile.mkdtemp()

        def __enter__(self):
            return self.name

        def __exit__(self, exctype, excvalue, exctrace):
            try:
                shutil.rmtree(self.name, True)
            except OSError:  # removal errors are not the only possible
                pass
            self.name = None


log = logging.getLogger(__name__)


def is_valid_hostname(hostname):
    """Ensures hostname contains at least one character and a maximum of 63
    characters, consists only of allowed characters, and doesn't begin or end
    with a hyphen.

    Thanks to Tim Pietzcker and Olli at http://stackoverflow.com/questions/2532053/validate-a-hostname-string

    .. TODO:: The valid_length should be `255 - len('X' * 64 + '.')` so that we
    are sure we can always resolve any subdomain. However, dev SSL cert
    generation fails if the fqdn of the cert is >64. See T59931
    """
    hostname_len = len(hostname)
    if hostname_len > 64:
        raise ValueError("Name is %d character(s) too long" % (hostname_len - 64))

    # strip exactly one dot from the right, if present
    if hostname[-1] == ".":
        hostname = hostname[:-1]

    allowed = re.compile("(?!-)[A-Z\d-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))


def sanitize_vagrant_name(name):
    name = name.lower()
    if '_' in name:
        log.warning(click.style('Underscores in name replaced with dashes', fg='magenta'))
        name = name.replace('_', '-')
    if ' ' in name:
        log.warning(click.style('Spaces in name replaced with dashes', fg='magenta'))
        name = name.replace(' ', '-')
    if '.' in name:
        log.warning(click.style('Periods in name removed', fg='magenta'))
        name = name.replace('.', '')
    return name


def check_vagrant_version():
    # make sure vagrant is installed
    which.which('vagrant')

    version = subprocess.check_output(['vagrant', '-v'], env=os.environ)  # --version gives a lot more

    if not version.startswith('Vagrant'):
        log.warning('vagrant version could not be parsed')
        return False

    _, version = version.split()
    version = LooseVersion(version)
    err_msg = None

    not_bad_version = True
    for bad_version in config.BAD_VAGRANT_VERSIONS:
        if LooseVersion(bad_version) == version:
            not_bad_version = False
            break
    if not not_bad_version:
        err_msg = ("Known bad version of vagrant found: %s in (%s). To upgrade, "
                   "`brew update; brew cask install vagrant`" % (version, ', '.join(config.BAD_VAGRANT_VERSIONS)))

    if config.MIN_VAGRANT_VERSION:
        valid_min = version >= LooseVersion(config.MIN_VAGRANT_VERSION)
    else:  # pragma: no cover
        valid_min = True
    if not valid_min:  # pragma: no cover
        err_msg = ("Vagrant older than than oldest support version: %s < %s. To upgrade, "
                   "`brew update; brew cask install vagrant`" % (version, config.MIN_VAGRANT_VERSION))

    if config.MAX_VAGRANT_VERSION:  # pragma: no cover
        valid_max = version <= LooseVersion(config.MAX_VAGRANT_VERSION)
    else:
        valid_max = True
    if not valid_max:
        err_msg = ("Vagrant newer than than newest support version. %s > %s. To downgrade, go to "
                   "http://www.vagrantup.com/downloads-archive.html" % (version, config.MAX_VAGRANT_VERSION))

    if err_msg:
        log.warning(err_msg)

    # there will only be an error message if something is wrong
    return not err_msg


def edit_diff(box_data, repo, diffs):
    if diffs:
        if isinstance(diffs, basestring):
            diffs = diffs.split(',')
        # filter any empty strings
        diffs = [d for d in diffs if d and d.startswith('D')]
    else:
        diffs = []

    # todo: validate diff names start with D and that the rest is numbers

    # todo: support different diffs on different instances in one boxes.yaml
    for bd in box_data:
        if ':arc_diffs' not in bd:
            bd[':arc_diffs'] = {}
        bd[':arc_diffs'][repo] = list(diffs)

    if diffs:
        log.info("Added %s diffs: %s", repo, ", ".join(diffs))
    else:
        log.debug("There are no custom %s diffs", repo)

    return box_data


def edit_config_csv(box_data, cfg_item, data=[], join=True):
    log.debug("Called with: %s, %s" % (cfg_item, data))
    if not data:
        log.info("Got empty payload %s, unsetting %s in config" % (data, cfg_item))
        join = False
    elif isinstance(data, basestring):
        data = [i for i in data.split(',') if i]
    elif not isinstance(data, list):
        raise ValueError("edit_config_csv data param requires a csv string or array - got %s" % type(data))

    for bd in box_data:
        if cfg_item in bd and bd[cfg_item]:
            log.debug("data is %s - %s - %s" % (data, type(data), bd[cfg_item]))
            if cfg_item == ':services':
                if 'none' in data:
                    join = False
                elif 'none' in bd[cfg_item]:
                    bd[cfg_item].remove('none')

            if join:
                items = [x for x in data if x not in bd[cfg_item]]
                log.info("Appended config item: %s (%s) with values: %s" % (cfg_item, bd[cfg_item], items))
                bd[cfg_item] = bd[cfg_item] + items
            else:
                old_services = bd[cfg_item]
                bd[cfg_item] = data
                log.info("Overwrote config item: %s (%s) with values: %s)" % (cfg_item, old_services, data))
        else:
            log.info("Added config item: %s  with values:  %s" % (cfg_item, data))
            bd[cfg_item] = data
    return box_data


def fqdn_from_name(name_or_fqdn, default_domain=config.DEFAULT_DOMAIN):
    # todo: make this smarter and support loading boxes.yaml and knowing what the provider is
    if '.' in name_or_fqdn or not default_domain:
        fqdn = name_or_fqdn
    else:
        fqdn = "{}.{}".format(name_or_fqdn, default_domain)
        log.debug("Assuming fqdn: %s", fqdn)
    return fqdn


# todo: cache this?
def get_current_boxes():
    """List installed boxes and their providers"""
    current_boxes = {}

    log.debug("Running 'vagrant box list'")
    output = subprocess.check_output(['vagrant', 'box', 'list'], env=os.environ)

    if "no installed boxes" in output:
        return current_boxes

    for l in output.split('\n'):
        if not l:
            continue

        # this is very verbose
        # log.debug("vagrant box list line: %s", l)

        n, p = l.split(' ', 1)  # name (provider)

        try:
            p, v = p.strip()[1:-1].split(', ', 1)  # cut off the parens
        except ValueError:
            raise ValueError("Unable to parse current boxes. You probably need to upgrade packer to 1.5.2+")

        # this makes Bryan sad
        if p == "vmware_desktop":
            p = "vmware"

        if n not in current_boxes:
            current_boxes[n] = [p]
        else:
            current_boxes[n].append(p)
    log.debug("Current boxes: %s", ", ".join(current_boxes))

    return current_boxes


# todo: cache this
def get_current_plugins(check_version=True):
    """List installed plugins"""
    current_plugins = []

    log.debug("Running `vagrant plugin list`")

    output = subprocess.check_output(['vagrant', 'plugin', 'list'], env=os.environ)

    if "no installed plugins" in output:
        return current_plugins
    for l in output.split('\n'):
        if not l:
            continue
        # log.debug("line: %s", l)
        n, v_and_more = l.split(None, 1)  # name (version)

        if check_version:
            # skip known bad plugins/versions
            if n == 'vagrant-aws' and v_and_more.strip() == '(0.5.0)':
                log.info("vagrant-aws installed with known broken version")
                continue

        current_plugins.append(n)

    return current_plugins


def get_box_filename(distro, env, num, prefix, provider, role):
    return '{prefix}-{provider}-{distro}-{env}-{role}-{num}.box'.format(
        env=env,
        distro=distro,
        num=num,
        prefix=prefix,
        provider=provider,
        role=role,
    )


def get_puppet_includes():
    for f in get_puppet_include_filepaths():
        yield os.path.basename(f)


def get_puppet_include_filepaths():
    for f in glob.glob(os.path.join(config.PUPPET_INCLUDE_DIR, '*')):
        yield f


def kill_children(parent_pid, sig, timeout=30):
    try:
        p = psutil.Process(parent_pid)
    except psutil.error.NoSuchProcess:
        return

    children = p.get_children(recursive=True)
    if children:
        log.info("Waiting up to %d seconds for children to stop...", timeout)
        # sleep so packer/vagrant have a chance to do their cleanup
        gone, alive = psutil.wait_procs(children, timeout)

        # sometimes vagrant processes survive wait_procs so kill them dead here
        for a in alive:
            log.info("Timeout exceeded. Sending %s to %s", sig, a)
            a.send_signal(sig)


def is_box_installed(box_name, provider):
    """check if vagrant already has the box added"""
    current_boxes = get_current_boxes()
    return (current_boxes and box_name in current_boxes and provider in current_boxes[box_name])


def prepare_import(box_data, claim=False):
    box_data = simple_delete_box_config(box_data, ':ssh_private_key')

    if claim:
        box_data = simple_delete_box_config(box_data, ':uber_owner')

    # todo: anything else we need to delete?
    return box_data


def signal_handler(signum, frame):
    log.info("Received signal: %s", signum)
    kill_children(os.getpid(), signum)
    # todo: click has an exit helper. not sure if it does anything helpful
    sys.exit(1)


def simple_edit_box_config(box_data, key, value):
    for bd in box_data:
        bd[key] = value
    return box_data


def simple_delete_box_config(box_data, key):
    for bd in box_data:
        if key in bd:
            del bd[key]
    return box_data


def verify_ssl_certificate(certfile):
    """Returns True if given ssl cert is valid."""
    # Only verify SSL cert on MAC for now.
    if sys.platform != 'darwin':
        return False

    ssl_verification_retcode = subprocess.call([
        "security", "verify-cert", "-c", certfile])
    return ssl_verification_retcode == 0
