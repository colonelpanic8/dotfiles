from boxer import config


def test_vagrant_providers():
    assert config.DEFAULT_PROVIDER in config.DEFAULT_PROVIDERS

    for p in config.DEFAULT_PROVIDERS:
        assert p in config.VALID_PROVIDERS
