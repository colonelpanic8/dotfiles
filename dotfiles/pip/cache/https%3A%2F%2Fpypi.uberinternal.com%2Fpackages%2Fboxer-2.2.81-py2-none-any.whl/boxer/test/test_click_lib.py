import boto
import click
import os
import pytest

from boxer import config
from boxer.click_lib import get_box_urls, get_local_certificate_name, get_s3_bucket, get_s3_connection, quick_s3_get


@pytest.fixture
def ctx():
    """A click.Context with our BoxerConfig attached to ctx.obj."""
    ctx = click.Context(click.Command)
    ctx.ensure_object(config.BoxerConfig)
    return ctx


def test_get_box_urls(ctx):
    """Check our silly box name format."""
    boxer_home = ctx.find_object(config.BoxerConfig).get('boxer_home')

    # todo: mock boto with moto
    bucket = get_s3_bucket(ctx)

    urls = get_box_urls(ctx, bucket, 'precise', 'development', '000', 'test', 'aws', 'base')

    assert len(urls) == 1  # there should only be the local path since this isn't in s3
    assert urls[0] == os.path.join(boxer_home, 'boxes', 'test-aws-precise-development-base-000.box')


def test_get_local_certificate_name(ctx):
    """Check our silly certificate name format."""
    name = 'boxer-test'
    get_local_certificate_name(ctx, name)

    # todo: assert something


def test_get_s3_bucket(ctx):
    """http://ihasabucket.com/"""
    # todo: mock boto with moto
    bucket = get_s3_bucket(ctx)
    assert isinstance(bucket, boto.s3.bucket.Bucket)


def test_get_s3_connection(ctx):
    """http://ihasaconnection.com/"""
    s3conn = get_s3_connection(ctx)
    assert isinstance(s3conn, boto.s3.connection.S3Connection)


def test_quick_s3_get_of_nonexistant(ctx):
    """Getting a non-existant file returns None."""
    # todo: mock boto with moto
    result = quick_s3_get(ctx, 'doesnotexist')
    assert result is None
