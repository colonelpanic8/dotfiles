import mock

from boxer.lib import check_vagrant_version, edit_diff, fqdn_from_name, edit_config_csv


def test_bad_vagrant_version():
    """A known bad version should return False."""
    with mock.patch('subprocess.check_output', return_value='Vagrant 1.6.0\n'):
        assert check_vagrant_version() is False


def test_check_vagrant_version():
    """A good version of vagrant should not raise and should return True."""
    with mock.patch('subprocess.check_output', return_value='Vagrant 1.7.2\n'):
        assert check_vagrant_version() is True


def test_edit_diff_string():
    box_config = [{}, {}]

    diffs = ['D000', 'D001']
    box_config = edit_diff(box_config, 'test_repo', ','.join(diffs))
    assert box_config[0][':arc_diffs']['test_repo'] == diffs
    assert box_config[1][':arc_diffs']['test_repo'] == diffs


def test_edit_diff_empty():
    box_config = [{}]

    diffs = []
    box_config = edit_diff(box_config, 'test_repo', diffs)
    assert box_config[0][':arc_diffs']['test_repo'] == diffs


def test_edit_diff_empty_string():
    box_config = [{}]

    diffs = ['', 'D002']
    box_config = edit_diff(box_config, 'test_repo', diffs)
    assert box_config[0][':arc_diffs']['test_repo'] == ['D002']


def test_edit_config_csv():
    box_config = [{}]

    include_files = ['udeploy']
    custom_files = ['custom_file']
    custom_includes = ['uber::service::kodenom']

    box_config = edit_config_csv(box_config, ':puppet_includes', include_files)
    box_config = edit_config_csv(box_config, ':puppet_includes', custom_files)
    box_config = edit_config_csv(box_config, ':puppet_custom_includes', custom_includes)

    assert box_config[0][':puppet_includes'] == include_files + custom_files
    assert box_config[0][':puppet_custom_includes'] == custom_includes


def test_edit_config_csv_string():
    box_config = [{}]

    include_files = ['udeploy', 'infraportal']
    custom_files = ['custom_file', 'custom_file_2']
    custom_includes = ['uber::service::kodenom', 'uber::service::kodenomnom']

    box_config = edit_config_csv(box_config, ':puppet_includes', ','.join(include_files))
    box_config = edit_config_csv(box_config, ':puppet_includes', ','.join(custom_files))
    box_config = edit_config_csv(box_config, ':puppet_custom_includes', ','.join(custom_includes))

    assert box_config[0][':puppet_includes'] == include_files + custom_files
    assert box_config[0][':puppet_custom_includes'] == custom_includes


def test_edit_config_csv_empty():
    box_config = [{}]

    include_files = []
    custom_files = []
    custom_includes = []

    box_config = edit_config_csv(box_config, ':puppet_includes', include_files)
    box_config = edit_config_csv(box_config, ':puppet_includes', custom_files)
    box_config = edit_config_csv(box_config, ':puppet_custom_includes', custom_includes)

    assert box_config[0][':puppet_includes'] == include_files + custom_files
    assert box_config[0][':puppet_custom_includes'] == custom_includes


def test_fqdn_from_name():
    fqdn = fqdn_from_name('test_name', default_domain='test_domain')
    assert fqdn == 'test_name.test_domain'


def test_fqdn_from_fqdn():
    fqdn = fqdn_from_name('test_name.other_domain', default_domain='test_domain')
    assert fqdn == 'test_name.other_domain'


def test_invalid_vagrant_version():
    """Broken vagrant should raise."""
    with mock.patch('subprocess.check_output', return_value='NotVagrant\n'):
        assert check_vagrant_version() is False
