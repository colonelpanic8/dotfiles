class BoxerException(Exception):
    pass


class LifeguardPoolEmpty(BoxerException):
    pass
