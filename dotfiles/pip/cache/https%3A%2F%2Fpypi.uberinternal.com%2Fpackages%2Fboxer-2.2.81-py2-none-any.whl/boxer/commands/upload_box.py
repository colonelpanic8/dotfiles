import logging
import os
import os.path

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail, get_s3_bucket

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('box_name')
@click.option('--with-mark-latest/--no-mark-latest', default=False)
@click.pass_context
def upload_box(ctx, box_name, with_mark_latest):
    """Upload a Vagrant box to S3.

    .. TODO:: flag to delete the local box after it is uploaded
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    with boxer_lock(ctx, 'upload_box-%s' % box_name):
        if not os.path.exists(box_name):
            full_box_name = os.path.join(boxer_config.get('BOX_DIR'), box_name)

            if os.path.exists(full_box_name):
                box_name = full_box_name
            else:
                fail(ctx, msg="Box %s could not be found in the cwd or in %s" % (box_name, boxer_config.get('BOX_DIR')))

        if not box_name.endswith('.box'):
            fail(ctx, msg="%s does not appear to be a box" % (box_name))

        box_basename = os.path.basename(box_name)

        bucket = get_s3_bucket(ctx)

        # todo: check if the key already exists?

        # ship the file to s3
        key = bucket.new_key("vagrant_boxes/%s" % box_basename)
        key.set_contents_from_filename(box_name)

        log.info("Successfully uploaded box %s", box_basename)

        if with_mark_latest:
            build_name, build_num = os.path.splitext(box_basename)[0].rsplit('-', 1)

            latest_key_name = "vagrant_boxes/%s.latest" % build_name

            # todo: handle case of key existing and not existing?
            latest_key = bucket.get_key(latest_key_name)
            if not latest_key:
                latest_key = bucket.new_key(latest_key_name)
            latest_key.set_contents_from_string(build_num)
            log.info("Successfully marked box '%s' as the latest", box_name)

    return BoxerClickReturn(output=True)
