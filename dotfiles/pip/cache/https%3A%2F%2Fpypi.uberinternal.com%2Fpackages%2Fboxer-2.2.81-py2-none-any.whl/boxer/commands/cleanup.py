import logging
import time

from boto.route53.exception import DNSServerError
import boto
import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, get_current_cloud_vagrants, get_route53_connection

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option(
    '--all-regions/--few-regions',
    default=False,
    help="If true, search all of Amazon's regions, not just the ones that boxer currently supports",
)
@click.option('--dry/--shipit', default=True)
@click.option('--delete-before', default=3000, help='Delete all the packer builds older than this id')
@click.pass_context
def clean_ami(ctx, all_regions, delete_before, dry):
    """Delete stale AMI records in AWS."""
    boxer_config = ctx.find_object(config.BoxerConfig)

    deletes = 0

    if all_regions:
        region_names = [r.name for r in boto.ec2.regions()]
    else:
        region_names = config.AWS_REGIONS

    # http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeInstances.html
    filters = {
        'name': 'uber-precise-development-*-*',
        'state': 'available',
    }

    with boxer_lock(ctx, 'clean_ami'):
        for aws_region_name in region_names:
            # todo: maybe squelch boto error logging here
            conn = boto.ec2.connect_to_region(
                aws_region_name,
                aws_access_key_id=boxer_config.get('AWS_ACCESS_KEY'),
                aws_secret_access_key=boxer_config.get('AWS_SECRET_KEY'),
            )
            if not conn:
                log.warning("Failed connecting to region %s" % aws_region_name)
                continue

            log.info("Checking %s", conn)
            for image in conn.get_all_images(filters=filters):
                if not image.name.startswith('uber-precise-development-'):
                    # this shouldn't be possible
                    log.debug("Skipping %s because of start", image.name)
                    continue

                if image.name.count('-') != 4:
                    log.debug("Skipping %s because non-standard format", image.name)
                    continue

                _, build_num = image.name.rsplit('-', 1)

                try:
                    build_num = int(build_num)
                except ValueError:
                    log.debug("Skipping %s because of build_num", image.name)
                    continue

                if build_num >= delete_before:
                    log.debug("Skipping %s because it is new", image.name)
                    continue

                deletes += 1
                if dry:
                    log.info("DRY: Deleting %s", image.name)
                else:
                    log.info("Deleting %s", image.name)
                    image.deregister(delete_snapshot=True)

    if dry:
        log.info("Would have deleted %d records", deletes)
    else:
        log.info("Deleted %d records", deletes)
    return BoxerClickReturn(output=True)


@click_command(group=cli)
@click.option('--dry/--shipit', default=True)
@click.pass_context
def clean_dns(ctx, dry=True, zone_name=u'dev.uber.com.'):
    """Delete stale DNS records in Route53.

    .. TODO:: Allow zones besides dev.uber.com.
    """
    current_vagrant_names = [v['name'] for v in get_current_cloud_vagrants(ctx)]

    blacklist = [
        'mail',  # CNAME to sendgrid.net
    ]

    deletes = 0

    with boxer_lock(ctx, 'clean_dns'):
        zone = get_route53_connection(ctx).get_zone(zone_name)
        for r in zone.get_records():
            if r.type not in ('CNAME', 'A'):
                continue

            # remove . and the zone name from the end
            shortname = r.name[:-1 - len(zone_name)]

            # remove the wildcard
            if shortname.startswith(u'\\052.'):
                shortname = shortname[len(u'\\052.'):]

            if shortname in blacklist:
                continue

            if shortname not in current_vagrant_names:
                if dry:
                    click.echo("DRY: Deleted: %r" % r)
                else:
                    click.echo("Deleted %r" % r)
                    try:
                        zone.delete_record(r)
                    except DNSServerError:
                        log.warning("Error! Sleeping 60 seconds and trying again.")
                        time.sleep(60)
                        zone.delete_record(r)
                    else:
                        time.sleep(0.1)
                deletes += 1

    if dry:
        log.info("Would have deleted %d records", deletes)
    else:
        log.info("Deleted %d records", deletes)
    return BoxerClickReturn(output=True)
