import logging

import click

from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, is_local_vagrant_or_fail, open_box_config
from boxer.lib import edit_config_csv, get_puppet_includes

log = logging.getLogger(__name__)


@click_command(group=cli)
def list_puppet_includes():
    """List available puppet include files."""
    for f in get_puppet_includes():
        click.echo(f)


@click_command(group=cli)
# todo: --list flag that short circuits and list all valid includes
@click.argument('name')
@click.argument('include_files', nargs=-1)
@click.option('-i', '--custom-includes', help='Comma-separated list of additonal things to include')
@click.option('-f', '--custom-files', help='Comma-separated list of **full paths** to a custom include files')
@click.option('-s', '--show', help='reset include list to empty', default=False, is_flag=True)
@click.pass_context
def puppet_includes(ctx, name, include_files, custom_includes, custom_files, show):
    """Prepare files to customize devserver puppet.

    .. WARNING::

        This feature is relatively new and most services do not yet have include files. See
        https://code.uberinternal.com/T37125 for more information.

    The devserver role in puppet was originally designed to run Uber's full stack. With over 100 services with varying
    levels of complexity, puppet runs for this role can take an exceedingly long time. This command allows you to tell
    puppet to only include some services.

    For example, to only apply manifests for udeploy and infraportal::

        \b
        boxer puppet_includes $VAGRANTNAME udeploy infraportal
        boxer v $VAGRANTNAME -c provision

    To see all the available files for inclusion::

        \b
        boxer list_puppet_includes

    For example, to include something that doesnt have a puppet include file::

        \b
        boxer puppet_includes $VAGRANTNAME --custom-includes uber::service::kodenom,uber::service::kodenomnom
        boxer v $VAGRANTNAME -c provision

    For example, to include a custom file with an include on each line::

        \b
        boxer puppet_includes $VAGRANTNAME --custom-files $UBER_HOME/kodenom/.uber/puppet_include,$UBER_HOME/kodenomnom/.uber/puppet_include
        boxer v $VAGRANTNAME -c provision

    To undo customizations and enable includes of all services::

        \b
        boxer puppet_includes $VAGRANTNAME
        boxer v $VAGRANTNAME -c provision

    To see includes configured for a box:

        \b
        boxer puppet_includes $VAGRANTNAME --show
    .. WARNING::

        Puppet is not very good at removing things as it most be told explicitly to remove files. Be warned that
        changing from one include to another is likely to leave some files behind.
    """
    name = is_local_vagrant_or_fail(ctx, name)

    with boxer_lock(ctx, name):
        with open_box_config(ctx, name) as box_data:
            if include_files:
                edit_config_csv(box_data, ':puppet_includes', list(include_files))
            if custom_files:
                edit_config_csv(box_data, ':puppet_includes', custom_files)
            if custom_includes:
                edit_config_csv(box_data, ':puppet_custom_includes', custom_includes)

            if not custom_files and not custom_includes and not include_files and not show:
                edit_config_csv(box_data, ':puppet_includes')
                edit_config_csv(box_data, ':puppet_custom_includes')

            if show:
                for bd in box_data:
                    log.info('puppet_includes: %s' % bd[':puppet_includes'])
                    log.info('custom_includes: %s' % bd[':puppet_custom_includes'])

    # todo: maybe run this automatically?
    log.info("You should now run 'boxer v %s -c provision'", name)
    return BoxerClickReturn(output=True)
