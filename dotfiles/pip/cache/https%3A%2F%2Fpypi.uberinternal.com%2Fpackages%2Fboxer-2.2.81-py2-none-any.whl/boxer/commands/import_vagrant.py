import logging
import os
import os.path
import tarfile
import tempfile

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail, get_s3_bucket, open_box_config, quick_s3_get
from boxer.commands.download_box import download_box
from boxer.commands.create_vagrant import create_vagrant
from boxer.commands.v import v
from boxer.lib import prepare_import, sanitize_vagrant_name

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.option('--claim/--no-claim', default=False)
@click.option('--claim-for', default=None, help='email address to claim for. defaults to UBER_OWNER')
@click.option('--delete-remote/--no-delete-remote', default=False)
@click.option('--force/--no-force', is_flag=True, default=True)
@click.pass_context
def import_vagrant(ctx, claim, claim_for, delete_remote, force, name):
    """Import a vagrant's info from S3."""
    name = sanitize_vagrant_name(name)

    boxer_config = ctx.find_object(config.BoxerConfig)

    with boxer_lock(ctx, name):
        if claim and not claim_for:
            if 'UBER_OWNER' not in os.environ:
                msg = "UBER_OWNER env var not set to your @uber.com email! Please export it in your ~/.bash_profile or similar or set --claim-for"
                fail(ctx, msg=msg)
            claim_for = os.environ['UBER_OWNER']

        vagrant_root = boxer_config.get('VAGRANT_ROOT')
        vagrant_dir = os.path.join(vagrant_root, name)
        vagrant_filename = os.path.join(vagrant_dir, 'Vagrantfile')

        # download tar.gz of vagrant_dir
        tf = None
        tar = None
        try:
            key_name = "vagrants/%s.tar.gz" % name

            if os.path.exists(vagrant_filename):
                log.info("%s already exists locally", name)
            else:
                tf = tempfile.NamedTemporaryFile(delete=False)
                tf.close()

                log.info("Downloading %s.tar.gz", name)
                # todo: i don't think this fails properly if the file does not exist
                quick_s3_get(ctx, key_name, tf.name)

                with tarfile.open(tf.name, 'r') as tar:
                    log.info("Extracting %s.tar.gz", name)
                    tar.extractall(vagrant_root)
        except Exception:
            # todo: exit sanely
            raise
        else:
            if delete_remote:
                bucket = get_s3_bucket(ctx)
                bucket.delete_key(key_name)
                log.info("Deleted remote Vagrant files for %s", name)
        finally:
            # cleanup the file
            if tar:
                if not tar.closed:
                    tar.close()
            if tf:
                if not tf.closed:
                    tf.close()
                os.unlink(tf.name)

        # update the vagrant to make sure Vagrantfile symlink is right
        log.info("Updating config and Vagrantfile for %s", name)
        with open_box_config(ctx, name) as box_data:
            prepare_import(box_data, claim=claim)

        # todo: squelch stdout?
        result = ctx.invoke(create_vagrant, email=claim_for, name=name, update=True, force=True, with_launch=False, with_update_terminates=False)
        if not result:
            fail(ctx, msg="Failed downloading the box for %s" % name)

        log.info("Fetching box for %s", name)
        # todo: this shouldn't be necessary, but vagrant 1.7 seems to have a bug when the box is missing
        result = ctx.invoke(download_box, name=name, provider='aws', force=True)
        if not result:
            fail(ctx, msg="Failed downloading the box for %s" % name)

        if claim:
            log.info("Setting owner for %s to %s", name, claim_for)
            fact_command = [
                'ssh', '--', 'sudo', '/usr/bin/update-facts', '/etc/facts.d/uber.json', 'uber_owner="{}"'.format(claim_for),
            ]
            result = ctx.invoke(v, name=name, command=fact_command, with_exit=False)
            if not result:
                log.warning(click.style("Unable to update-facts! You should run: box v %s -c provision", fg="red"), name)

    log.info(click.style("To login, run: boxer v %s", fg="green"), name)
    return BoxerClickReturn(output=name)
