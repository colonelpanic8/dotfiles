import logging
import os
import os.path

from boto.ec2 import connect_to_region
import click
import yaml

from boxer import config
from boxer.cli import cli
from boxer.click_lib import aws_region_type, BoxerClickReturn, click_command, fail, get_current_vagrants

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('action', type=click.Choice(['console', 'reboot', 'start', 'status', 'stop', 'terminate']))
@click.argument('instance_ids', nargs=-1)
@click.option('--region', default=config.DEFAULT_AWS_REGION, type=aws_region_type)
@click.pass_context
def aws(ctx, action, instance_ids, region):
    """Manage EC2 instances by their IDs. Helpful for cleaning up broken vagrants or instances without a Vagrantfile.

    If you launched your instance in a non-default region, you must specify that region here with --region.

    .. WARNING::

        Sometimes instances get stuck in the stopped state state while rebooting. It is best to stop, WAIT FOR IT TO
        STOP, and then start.

    Generally, you should use ``boxer v $VAGRANTNAME -c halt/up`` or ``boxer terminate``, but if you don't have access
    to the Vagrantfile or Vagrant is otherwise broken, this command will allow you to control at least some things::

        \b
        boxer aws console i-XXXXXXXX
        boxer aws reboot i-XXXXXXXX
        boxer aws start i-XXXXXXXX
        boxer aws status i-XXXXXXXX
        boxer aws stop i-XXXXXXXX
        boxer aws terminate i-XXXXXXXX

    If you don't know the ID, use ``boxer list_vagrants --owner $OWNER@uber.com``
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    # transform any names in the instance id list to the proper id
    real_ids = {}
    for i, i_id in enumerate(instance_ids):
        if i_id.startswith('i-'):
            if region not in real_ids:
                real_ids[region] = []
            real_ids[region].append(i_id)
            continue

        # i_id is a name and not an actual id
        # todo: should we group all the names together?
        result = ctx.invoke(aws_id, names=[i_id])
        if not result or not result.output:
            fail(ctx, msg="No instance id found!")
        real_name, real_id, real_region = result.output[0]
        if real_name != i_id:
            raise ValueError("Names do not match. '%s' != '%s'", i_id, real_name)

        if real_region not in real_ids:
            real_ids[real_region] = []

        real_ids[real_region].append(real_id)

    aws_access_key_id = boxer_config.get('AWS_ACCESS_KEY')
    aws_secret_access_key = boxer_config.get('AWS_SECRET_KEY')

    for reg, i_ids in real_ids.iteritems():
        if not i_ids:
            fail(ctx, msg="No instance ids given for %s after filters" % region)

        conn = connect_to_region(
            reg,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        # todo: put all these into functions?
        if action == 'console':
            reservations = conn.get_all_instances(instance_ids=i_ids)

            if not reservations:
                log.info("No reservations found")
            else:
                for r in reservations:
                    if r.instances:
                        for i in r.instances:
                            output = i.get_console_output()
                            click.echo("Instance id: %s" % i.id)
                            click.echo(output.output)
                            click.echo()
                    else:
                        log.info("No instances found.")

        elif action == 'reboot':
            # conn.reboot_instances didn't seem to be working :s
            # return BoxerClickReturn(output=conn.reboot_instances(instance_ids=i_ids))
            reservations = conn.get_all_instances(instance_ids=i_ids)

            if not reservations:
                log.info("No reservations found")
            else:
                for r in reservations:
                    if r.instances:
                        for i in r.instances:
                            log.info("Rebooting %s. You will likely need to `boxer v NAME -c provision` to fix DNS after the instance is booted", i.id)  # noqa
                            log.warning("Amazon has a known problem of failing to start after stopping! You may need to `boxer aws start %s` after the instance is stopped", i.id)  # noqa
                            i.reboot()
                    else:
                        log.info("No instances found.")
        elif action == 'start':
            conn.start_instances(instance_ids=i_ids)
            log.info("Sent start commands for %s in %s", ", ".join(i_ids), region)
        elif action == 'status':
            results = conn.get_all_instance_status(instance_ids=i_ids, include_all_instances=True)

            for r in results:
                passing_checks = 0
                if r.system_status.details['reachability'] == 'passed':
                    passing_checks += 1
                if r.instance_status.details['reachability'] == 'passed':
                    passing_checks += 1

                click.echo("{}: {} (Passed {}/2 status checks)".format(r.id, r.state_name, passing_checks))

        elif action == 'stop':
            conn.stop_instances(instance_ids=i_ids)
            log.info("Sent stop commands for %s in %s", ", ".join(i_ids), region)
        elif action == 'terminate':
            conn.terminate_instances(instance_ids=i_ids)
            log.info("Sent terminate commands for %s in %s", ", ".join(i_ids), region)
        else:
            raise NotImplementedError

    return BoxerClickReturn(output=True)


@click_command(group=cli)
@click.argument('names', nargs=-1)
@click.pass_context
def aws_id(ctx, names):
    """Get the instance-ids for the given vagrants.

    .. TODO:: support multiple VMs in one yaml
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    results = []
    for name in names:
        if name not in get_current_vagrants(ctx):
            # todo: automate finding the id
            log.warning("Vagrant files for %s not available.", name)
            continue

        vagrant_dir = os.path.join(boxer_config.get('VAGRANT_ROOT'), name)

        aws_id_filename = os.path.join(vagrant_dir, '.vagrant', 'machines', name, 'aws', 'id')
        if not os.path.exists(aws_id_filename):
            log.error("No instance id file found for %s. Are you sure the instance is running?", name)
            continue

        with open(aws_id_filename, 'r') as f:
            instance_id = f.read().strip()

        # todo: better checking?
        if not instance_id.startswith('i-'):
            log.error("Invalid instance id found for %s. Are you sure the instance is running?", name)
            continue

        yaml_filename = os.path.join(vagrant_dir, 'boxes.yaml')
        with open(yaml_filename, 'r') as f:
            box_config = yaml.safe_load(f)

        region = box_config[0][':aws_region']

        click.echo("%s:%s:%s" % (name, instance_id, region))
        results.append((name, instance_id, region))

    return BoxerClickReturn(output=results)
