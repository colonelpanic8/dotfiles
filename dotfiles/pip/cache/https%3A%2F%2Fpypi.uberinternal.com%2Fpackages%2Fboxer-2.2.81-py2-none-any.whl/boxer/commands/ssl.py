import logging
import os

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import (
    boxer_lock, BoxerClickReturn, click_command, domain_type, fail, get_local_certificate_name, get_server_role,
    is_local_cert_same_with_remote, revoke_trust_ssl_certificate, trust_ssl_certificate, vagrant_scp,
)
from boxer.lib import (
    fqdn_from_name,
    verify_ssl_certificate,
)

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name_or_fqdn')  # todo: make a type for this that uses --default-domain?
@click.option('--default-domain', default=config.DEFAULT_DOMAIN)
@click.option('--force', default=None, is_flag=True)
@click.option('--with-dns/--no-dns', default=True, help='Try to connect with DNS if no Vagrantfile available.')
@click.option(
    '--with-vagrantfile/--no-vagrantfile',
    default=True,
    help="Try to connect with 'vagrant ssh-config'.",
)
@click.pass_context
def fetch_dev_ssl(ctx, name_or_fqdn, default_domain, force, with_dns, with_vagrantfile):
    """Fetch and install SSL certificates.

    .. TODO::
        Make this work better with tmux
        Make this work better with linux

    We use self signed certificates in development and your browser will throw errors (Your connection is not private)
    when it sees them unless you trust the cerficiates.

    You can use this command to fetch certificates for any devserver, not only your own.

    For example::

        \b
        boxer fetch_dev_ssl $VAGRANTNAME
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    fqdn = fqdn_from_name(name_or_fqdn, default_domain=default_domain)

    with boxer_lock(ctx, 'ssl-%s' % fqdn):
        boxer_sync_root = boxer_config.get('BOXER_SYNC_ROOT')
        if not os.path.exists(boxer_sync_root):  # pragma: no cover
            os.makedirs(boxer_sync_root)

        remote_role = get_server_role(
            ctx,
            name_or_fqdn,
            default_domain=default_domain,
            force=force,
            with_dns=with_dns,
            with_vagrantfile=with_vagrantfile,
        )
        if not remote_role:
            fail(ctx, msg="Unable to fetch role for %s" % name_or_fqdn)
        if remote_role != 'devserver':
            log.warning("%s has role '%s', not 'devserver'", name_or_fqdn, remote_role)
            return BoxerClickReturn(output="fetch_dev_ssl failed", returncode=3)

        local_ssl_certificate = get_local_certificate_name(ctx, fqdn)

        if (
            not force and
            os.path.exists(local_ssl_certificate) and
            is_local_cert_same_with_remote(
                ctx, name_or_fqdn, local_ssl_certificate,
                with_dns=with_dns,
                with_vagrantfile=with_vagrantfile,
            ) and
            verify_ssl_certificate(local_ssl_certificate)
        ):
            # skip if local ssl cert is in sync with remote server and
            # verification succeeded and force_download not enabled.
            return BoxerClickReturn(output="SSL certificate already trusted")

        log.info("Installing Uber's SSL certificate from %s", fqdn)

        vagrant_scp(
            ctx, name_or_fqdn,
            default_domain=default_domain,
            force=force,
            with_dns=with_dns,
            source_filename="{fqdn}:/etc/ssl/%s" % (boxer_config.get('DEV_SSL_CERTIFICATE')),
            target_filename=local_ssl_certificate,
        )

        # install SSL certificate.
        trust_ssl_certificate(ctx, local_ssl_certificate)

    return BoxerClickReturn(output=local_ssl_certificate)


@click_command(group=cli)
@click.argument('name_or_fqdn')  # todo: make a type for this that uses --default-domain?
@click.option('--default-domain', default=config.DEFAULT_DOMAIN, type=domain_type)
@click.pass_context
def remove_dev_ssl(ctx, name_or_fqdn, default_domain):
    """Remove trust of fetched dev SSL certs.

    .. TODO: Make this work better with tmux

    .. TODO: Make this work better with linux

    :param str name_or_fqdn: The name of the vagrant or a fully qualified domain name.
    :param str default_domain: The domain name to use if a vagrant name is given rather than a fqdn.

    You can use this command to remove installed certificates for any devserver, not only ones you have the Vagrantfile
    for.

    For example::

        \b
        boxer remove_dev_ssl $VAGRANTNAME
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    fqdn = fqdn_from_name(name_or_fqdn, default_domain=default_domain)

    with boxer_lock(ctx, 'ssl-%s' % fqdn):
        local_ssl_certificate = os.path.join(boxer_config.get('BOXER_SYNC_ROOT'),
                                             "%s.%s" % (fqdn, boxer_config.get('DEV_SSL_CERTIFICATE')))

        if os.path.exists(local_ssl_certificate):
            revoke_trust_ssl_certificate(ctx, local_ssl_certificate)

    return BoxerClickReturn(output=True)
