import glob
import logging
import os
import subprocess

import click
import yaml

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command
from boxer.lib import get_current_boxes

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.pass_context
def remove_unused_boxes(ctx):
    """Remove unusued boxes from Vagrant.

    After launching several vagrants, stale box files start to add up. This command will clean up unused boxes which
    will make vagrant faster and free up some disk space.

    .. TODO:: This only cleans up vagrant, ~/.boxer/boxes still has a bunch of files in it

    This command takes no arguments::

        \b
        boxer remove_unused_boxes
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    with boxer_lock(ctx, 'remove_unused_boxes'):
        unused_boxes = get_current_boxes()

        log.debug("Current boxes: %s", ', '.join(unused_boxes))

        vagrant_root = boxer_config.get('VAGRANT_ROOT')
        log.debug("VAGRANT_ROOT: %s", vagrant_root)

        # todo: move this to a method to better handle yamls with multiple vagrants elsewhere
        for box_config_filename in glob.iglob(os.path.join(vagrant_root, '*', 'boxes.yaml')):
            with open(box_config_filename, 'r') as f:
                box_config = yaml.safe_load(f)
                for bc in box_config:
                    box_name = bc[':box']
                    if box_name in unused_boxes:
                        unused_boxes.pop(box_name)

        if not unused_boxes:
            log.info("No unused boxes found.")
        else:
            # skip the dummy box. we don't want to ever remove that
            if 'dummy' in unused_boxes:
                del unused_boxes['dummy']

            log.info("Removing boxes: %s", ", ".join(unused_boxes.iterkeys()))

            # todo: delete matching box file in config.BOX_DIR if it exists

            for name in unused_boxes:
                for provider in unused_boxes[name]:

                    # this makes Bryan sad
                    if provider == 'vmware':
                        real_provider = 'vmware_desktop'  # boxes get added with vmware_DESKTOP
                    else:
                        real_provider = provider

                    subprocess.check_call(['vagrant', 'box', 'remove', name, '--provider', real_provider], env=os.environ)

    log.info('Finished pruning old vagrant boxes')
    return BoxerClickReturn(output=True)
