import logging

import click

from boxer.cli import cli
from boxer.click_lib import boxer_lock, click_command, is_local_vagrant_or_fail, open_box_config
from boxer.lib import edit_config_csv

log = logging.getLogger(__name__)


@click_command(group=cli)
# todo: --list flag that short circuits and list all valid includes
@click.argument('name')
@click.option('-l', '--list', '--service-list', help='Comma-separated list of additonal things to include', default=False)
@click.option('-r', '--reset', help='reset service list to empty', default=False, is_flag=True)
@click.pass_context
def services(ctx, name, reset, service_list):
    """Prepare files to customize devserver puppet.

    .. WARNING::

        This feature is relatively new.

    The devserver role in puppet was originally designed to run Uber's full stack. With over 100 services with varying
    levels of complexity, puppet runs for this role can take an exceedingly long time. This command allows you to tell
    puppet to only include some services.

    For example, to only apply manifests for api and rt-ncar::

        \b
        boxer services $VAGRANTNAME --list api,rt-ncar
        boxer v $VAGRANTNAME -c provision

    Asking for no services forces 'legacy' style, including all the things.
    To run all services::

        \b
        boxer services $VAGRANTNAME --reset
        boxer v $VAGRANTNAME -c provision

    If you are looking for a bare-bones box, ask for 'none'::

        \b
        boxer services $VAGRANTNAME --services none
        boxer v $VAGRANTNAME -c provision


    .. WARNING::

        Puppet is not very good at removing things as it most be told explicitly to remove files. Be warned that
        changing from one service to another is likely to leave some files behind.
    """
    name = is_local_vagrant_or_fail(ctx, name)

    with boxer_lock(ctx, name):
        if reset:
            with open_box_config(ctx, name) as box_data:
                edit_config_csv(box_data, ':services')
        elif service_list:
            with open_box_config(ctx, name) as box_data:
                edit_config_csv(box_data, ':services', [x.encode('ascii', 'ignore') for x in service_list.split(',')])
        else:
            with open_box_config(ctx, name) as box_data:
                for bd in box_data:
                    if ':services' in bd:
                        print("The following services are configured on %s: " % name)
                        print("%s" % bd[':services'])

    # todo: maybe run this automatically?
    log.info("You should now run 'boxer v %s -c provision'", name)
    return True
