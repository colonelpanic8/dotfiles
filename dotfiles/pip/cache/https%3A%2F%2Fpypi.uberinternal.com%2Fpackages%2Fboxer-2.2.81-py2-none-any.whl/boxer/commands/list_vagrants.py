import datetime
import logging
import operator
import os
import os.path
import re
import string
import subprocess
import tempfile

import boto
import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import BoxerClickReturn, click_command, vagrant_sort_type

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option(
    '--all-regions/--few-regions',
    default=False,
    help="If true, search all of Amazon's regions, not just the ones that boxer currently supports",
)
@click.option('--duplicates-only', default=False, is_flag=True, help='Only list duplicate running instances')
@click.option('--name', help='Filter by the Name tag of the instance')
@click.option('--owner')
@click.option('--owner-file', type=click.File('r'))
@click.option('--sort', '--sort-col', default='name', type=vagrant_sort_type)
@click.option('--sort-asc', 'reverse_sort', flag_value=False, default=True)
@click.option('--sort-desc', 'reverse_sort', flag_value=True)
@click.option('--state', default=None, type=click.Choice(['running', 'stopped', 'terminated']))
@click.option('--uber-service', default='vagrant')
@click.option('--with-echo/--no-echo', default=True)
@click.option('--with-puppet/--no-puppet', default=False)
@click.option('--with-unnamed/--no-unnamed', default=False)
@click.option('--mpssh-file', type=click.File('wt'))
@click.pass_context
def list_vagrants(
    ctx, all_regions, duplicates_only, mpssh_file, name, owner, owner_file, reverse_sort, sort_col, state, uber_service,
    with_echo, with_puppet, with_unnamed,
):
    """List currently running AWS instances.

    Filtering by one or more owners is easy::

        \b
        boxer list_vagrants --owner YOUREMAIL@uber.com,THEIREMAIL@uber.com

    This also plays nicely with grep::

        \b
        boxer list_vagrants | grep SOMETHING
    """
    boxer_config = ctx.find_object(config.BoxerConfig)

    owners = set()

    if owner:
        for o in owner.split(','):
            # todo: move this +/@ thing to a function
            if '+' in o and '@' in o:
                plus_index = o.index('+')
                at_index = o.index('@')
                o = o[:plus_index] + o[at_index:]
            owners.add(o)

    if owner_file:
        for o in map(string.rstrip, owner_file.readlines()):
            # if we got a list of ldap names, shove @uber.com on the end
            # todo: special case for bwstitt, rm, marcellus?
            if not o.endswith('@uber.com'):
                o += '@uber.com'
            owners.add(o)

    if owners:
        log.debug("Checking for instances owned by: %s", ", ".join(owners))

    seen_running = set()
    dupes_running = set()
    vagrant_results = {}
    ip_id_map = {}

    if all_regions:
        region_names = [r.name for r in boto.ec2.regions()]
    else:
        region_names = config.AWS_REGIONS
    # we search all aws regions, not just ones boxer currently uses

    # http://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_DescribeInstances.html
    filters = {}
    if name:
        filters['tag:Name'] = name
    if owners:
        if len(owners) <= 200:
            filters['tag:Uber Owner'] = [wild_o.replace('@', '*@') for wild_o in owners]
        else:
            # todo: make conn.get_all_reservations smart enough to paginate this
            log.warning("Unable to filter for more than 200 owners")
    if state:
        filters['instance-state-name'] = state
    if uber_service:
        filters['tag:Uber Service'] = uber_service
    # todo: allow filtering on any arbitrary tag?

    for aws_region_name in region_names:
        # todo: maybe squelch boto error logging here
        conn = boto.ec2.connect_to_region(
            aws_region_name,
            aws_access_key_id=boxer_config.get('AWS_ACCESS_KEY'),
            aws_secret_access_key=boxer_config.get('AWS_SECRET_KEY'),
        )
        if not conn:
            log.warning("Failed connecting to region %s" % aws_region_name)
            continue

        try:
            for reservation in conn.get_all_reservations(filters=filters):
                for instance in reservation.instances:
                    try:
                        instance_name = instance.tags['Name']
                    except KeyError:
                        try:
                            instance_name = instance.tags[u'aws:cloudformation:stack-name']
                        except KeyError:
                            # this is way too verbose
                            # log.debug("Unable to fetch name for %s", instance.id)

                            if with_unnamed:
                                instance_name = '__No_Name__'
                            else:
                                continue

                    # filter Kelvin spark instances along with unnamed instances
                    if not with_unnamed:
                        if instance_name.startswith('Kelvin-') \
                           or instance_name.startswith('jlu-spark-') \
                           or instance_name.startswith('puppet-vagrant-test-') \
                           or instance_name.startswith('test-udeploy-devserver-build-') \
                           or instance_name == 'Packer Builder':
                                continue

                    try:
                        instance_owner = instance.tags['Uber Owner']
                    except:
                        # this is way too verbose
                        # log.debug("Unable to fetch owner for %s", instance.id)
                        instance_owner = '__No_Owner__'
                    else:
                        # todo: move this to a function
                        if '@' in instance_owner and '+' in instance_owner:
                            plus_index = instance_owner.index('+')
                            at_index = instance_owner.index('@')
                            instance_owner = instance_owner[:plus_index] + instance_owner[at_index:]

                    # eventhough we filter the request to amazon, we still need to filter better here
                    # bryan@uber.com should not match if we are looking for instances owned by b@uber.com
                    if (
                        any(owners) and
                        (instance_owner == '__No_Owner__' or instance_owner not in owners)
                    ):
                        # log.debug("%s is not in owners", instance_owner_ldap)
                        continue
                    ip_address = instance.ip_address or instance.private_ip_address or '__No_IP__'
                    if ip_address != '__No_IP__':
                        ip_id_map[ip_address] = instance.id

                    # last_puppet will be looked up later in parallel
                    last_puppet = '__Pooppet__'

                    # this doesn't seem like the right way to parse the timestamp
                    try:
                        launch_datetime = datetime.datetime.strptime(instance.launch_time, "%Y-%m-%dT%H:%M:%S.%fZ")
                    except ValueError:
                        # moto seems to have a different format than boto
                        launch_datetime = datetime.datetime.strptime(instance.launch_time, "%Y-%m-%dT%H:%M:%S.%f")
                    uptime = datetime.datetime.utcnow() - launch_datetime

                    data = dict(
                        days_up=uptime.days,
                        aws_id=instance.id,
                        aws_type=instance.instance_type,
                        ip_address=ip_address,
                        last_puppet=last_puppet,
                        launch_time=instance.launch_time,
                        name=instance_name,
                        owner=instance_owner,
                        aws_region_name=aws_region_name,
                        state=instance.state,
                    )

                    possibles = {
                        'Distro': ('distro', '???'),
                        'Lifeguard Status': ('lifeguard_status', '???'),
                        'Uber Environment': ('uber_env', '???'),
                        'Uber Role': ('uber_role', '???'),
                        'Uber Service': ('uber_service', '???'),
                        'Services': ('services', '???')
                    }
                    for tag_name, (key, default) in possibles.iteritems():
                        if tag_name in instance.tags:
                            data[key] = instance.tags[tag_name]
                        else:
                            data[key] = default

                    vagrant_results[instance.id] = data

                    if duplicates_only:
                        if instance_name != '__No_Name__' and instance.state == 'running':
                            if instance_name in seen_running:
                                dupes_running.add(instance_name)
                            else:
                                seen_running.add(instance_name)
        except boto.exception.EC2ResponseError:
            log.warning("unable to connect to region %s", aws_region_name)

    if duplicates_only:
        vagrant_results = {k: v for k, v in vagrant_results.iteritems() if v['name'] in dupes_running}

    if mpssh_file:
        mpssh_file.writelines("%s\n" % i for i in ip_id_map.iterkeys())

    if with_puppet:
        # try to connect to all of the hosts with mpssh and get the last puppet run time
        if mpssh_file:
            mpssh_file_temp = False
        else:
            mpssh_file = tempfile.NamedTemporaryFile(delete=False)
            for ip in ip_id_map.iterkeys():
                mpssh_file.write("%s\n" % ip)
            mpssh_file_temp = True

        mpssh_file.close()

        log.info("Checking puppet status for %d hosts...", len(ip_id_map))

        try:
            commands = [
                "mpssh",
                "-f", mpssh_file.name,
                "--nokeychk",
                "--conntmout", "3",
                "stat -c %Y /var/tmp/puppet.success",
            ]
            log.debug("Running command: %s", " ".join(commands))

            output = subprocess.check_output(
                commands,
                env=os.environ,
                stderr=subprocess.STDOUT,
            )
        except subprocess.CalledProcessError:
            log.exception("Unable to connect with mpssh")
        else:
            print subprocess.check_output(['cat', mpssh_file.name])

            for line in output.splitlines():
                # "54.190.0.190 -> 1406071091" into ('54.190.0.190', '1406071091')
                result = re.search('([0-9.]+) -> ([0-9]+)', line)
                if result:
                    ip, last_puppet = result.groups()

                    instance_id = ip_id_map[ip]

                    now = datetime.datetime.utcnow()
                    last_puppet_datetime = datetime.datetime.fromtimestamp(int(last_puppet))
                    vagrant_results[instance_id]['last_puppet'] = (now - last_puppet_datetime).days
                else:
                    # this is way too verbose
                    # log.debug("bad line: %s", line)
                    pass

        if mpssh_file_temp:
            # os.unlink(mpssh_file.name)
            pass

    sorted_results = sorted(vagrant_results.itervalues(), key=operator.itemgetter(sort_col), reverse=reverse_sort)

    if with_echo:
        # this is getting to bet a lot of columns
        click.echo(" ".join(k for k in [
            'aws_region_name'.ljust(15),
            'aws_id'.ljust(11),
            'ip_address'.ljust(16),
            'aws_type'.ljust(11),
            'uber_role'.ljust(11),
            'launch_time'.ljust(25),
            'state'.ljust(13),
            'days_up'.ljust(8),
            'last_puppet'.ljust(12) if with_puppet else None,
            'name'.ljust(32),
            'owner',
        ] if k))

        for row in sorted_results:
            click.echo(" ".join(k for k in [
                row['aws_region_name'].ljust(15),
                row['aws_id'].ljust(11),
                row['ip_address'].ljust(16),
                row['aws_type'].ljust(11),
                row['uber_role'].ljust(11),
                row['launch_time'].ljust(25),
                row['state'].ljust(13),
                str(row['days_up']).ljust(8),
                str(row['last_puppet']).ljust(12) if with_puppet else None,
                row['name'].ljust(32),
                row['owner'],
            ] if k))

        click.echo('')
    else:
        return BoxerClickReturn(output=sorted_results)

    # todo: echo/return virtualbox/vmware instances

    return BoxerClickReturn(output=True)
