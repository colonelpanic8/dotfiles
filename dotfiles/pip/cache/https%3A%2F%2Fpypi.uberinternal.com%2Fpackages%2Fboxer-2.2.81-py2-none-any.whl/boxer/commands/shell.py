import inspect
import logging

import click

from boxer.cli import cli
from boxer.click_lib import click_command

log = logging.getLogger(__name__)


# todo: I think click provides this for us
@click_command(group=cli)
@click.pass_context
def shell(ctx):  # pragma: no cover
    """Start an interactive ipython shell.

    This will try to use ipython and fall back to a boring shell::

        \b
        boxer shell
    """
    banner = "Welcome to Uber's boxer shell"

    frame = inspect.currentframe()
    try:
        # evaluate commands in current context
        context = frame.f_globals.copy()
        context.update(frame.f_locals)
    finally:
        del frame

    try:
        import IPython
        IPython.embed(banner1=banner, user_ns=context)
    except ImportError:
        log.warning('Unable to import IPython')
        try:
            # optional, will allow Up/Down/History in the console
            import readline  # noqa
        except ImportError:
            log.warning('Unable to import readline')
        import code
        code.interact(banner=banner, local=context)
