import logging
import os
import os.path
import subprocess
import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, fail
from boxer.lib import get_current_plugins, is_box_installed

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option('--force', default=None, is_flag=True)
@click.option('--with-virtualbox/--no-virtualbox', default=False)
@click.option('--with-vmware/--no-vmware', default=False)
@click.pass_context
def bootstrap(ctx, force, with_virtualbox, with_vmware):
    """Install plugins and dummy box for vagrant.

    A vanilla install of vagrant can only manage virtualbox instances. This
    command installs additional vagrant plugins to enable more providers. It
    also installs a dummy box that allows for launching AWS instances directly
    with an AMI id.

    The default arguments are almost always what you want::

        \b
        boxer bootstrap
    """
    with boxer_lock(ctx, 'bootstrap'):
        # install dummy box
        if not force and is_box_installed('dummy', 'aws'):
            log.info("dummy aws box is already installed")
        else:
            subprocess.check_call([
                'vagrant',
                'box',
                'add',
                '--force',
                'dummy',
                'https://github.com/mitchellh/vagrant-aws/raw/master/dummy.box',
            ], env=os.environ)

        # install vagrant plugins
        plugins = config.VAGRANT_PLUGINS
        if force:
            current_plugins = []
        else:
            current_plugins = get_current_plugins(ctx)

        if not with_virtualbox:
            if 'vagrant-vbguest' in plugins:
                plugins.remove('vagrant-vbguest')
            if 'vagrant-vbox-snapshot' in plugins:
                plugins.remove('vagrant-vbox-snapshot')

        # todo: make this work better with mac and linux
        if not with_vmware:
            if 'vagrant-vmware-fusion' in plugins:
                plugins.remove('vagrant-vmware-fusion')

        log.debug("plugins to check/install: %s", ", ".join(plugins))

        try:
            for vp in plugins:
                if vp in current_plugins:
                    log.info("%s is already installed.", vp)
                else:
                    subprocess.check_call(['vagrant', 'plugin', 'install', vp], env=os.environ)
        except subprocess.CalledProcessError:
            # todo: actually inspect the error message
            log.error(click.style(
                "If the error above is 'Net::HTTPNotFound', please wait a minute and then try again.",
                fg='magenta',
            ))
            log.error(click.style(
                ("If the error above is about nokogiri, try "
                 "https://code.uberinternal.com/w/troubleshooting/devexperience/#bootstrap-fails-with-nok."),
                fg='magenta',
            ))
            log.error(click.style(
                "If the error above is something else, ask for help in HipChat",
                fg='magenta',
            ))
            fail(ctx)

    log.info('Finished bootstrapping boxer')
    return BoxerClickReturn(output=True)
