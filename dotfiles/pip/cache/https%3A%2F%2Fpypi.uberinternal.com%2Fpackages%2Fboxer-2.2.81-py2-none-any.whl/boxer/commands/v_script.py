import logging
import subprocess
import sys

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import click_command, vagrant_scp, vagrant_ssh

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name_or_fqdn')
@click.argument('script', type=click.Path())
@click.option('--default-domain', default=config.DEFAULT_DOMAIN)
@click.option('--force', default=None, is_flag=True)
@click.option('--user', default='uber')
@click.option('--script-args', default='')
@click.option('--with-dns/--no-dns', default=True, help='Try to connect with DNS if no Vagrantfile available.')
@click.option(
    '--with-vagrantfile/--no-vagrantfile',
    default=True,
    help="Try to connect with 'vagrant ssh-config'.",
)
@click.pass_context
def v_script(ctx, default_domain, force, name_or_fqdn, script, user, with_dns, with_vagrantfile):
    """Run a script on your vagrant."""
    try:
        # scp the script to the vagrant
        vagrant_scp(
            ctx, name_or_fqdn,
            default_domain=default_domain,
            force=force,
            source_filename=script,
            target_filename="/tmp/boxer_v_script",
            with_dns=with_dns,
            with_vagrantfile=with_vagrantfile,
        )

        # todo: run the script as the right user
        try:
            vagrant_ssh(
                ctx, name_or_fqdn,
                command=['/tmp/boxer_v_script'],
                default_domain=default_domain,
                force=force,
                with_dns=with_dns,
                with_vagrantfile=with_vagrantfile,
            )
        except subprocess.CalledProcessError as e:
            return_code = e.returncode
            log.error("%s exited non-zero!", script)
        else:
            return_code = 0
    finally:
        # delete the script
        vagrant_ssh(
            ctx, name_or_fqdn,
            command=['rm', '/tmp/boxer_v_script'],
            default_domain=default_domain,
            force=force,
            with_dns=with_dns,
            with_vagrantfile=with_vagrantfile,
        )

    # exit with the scripts exit code
    # todo: use click's helper for this
    sys.exit(return_code)
