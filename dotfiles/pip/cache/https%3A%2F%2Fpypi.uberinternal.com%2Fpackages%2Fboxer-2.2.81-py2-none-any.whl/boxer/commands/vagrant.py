import logging
import os

import click

from boxer.cli import cli
from boxer.click_lib import click_command, click_vagrant_options, fail
from boxer.commands.claim_vagrant import claim_vagrant
from boxer.commands.create_vagrant import create_vagrant
from boxer.exc import BoxerException
from boxer.lib import sanitize_vagrant_name

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.option('--name')  # todo: do the lowering and underscore replacing with a click type
@click.option(
    '--try-claim-vagrant/--no-claim-vagrant',
    default=True,
)
@click.option(
    '--try-create-vagrant/--no-create-vagrant',
    default=True,
)
@click_vagrant_options
def vagrant(
    ctx, check_existing, email, force, name, try_claim_vagrant, try_create_vagrant, update, **kwargs
):
    """Claim or create a vagrant.

    This will ask lifeguard for a vagrant with :meth:`boxer.commands.claim_vagrant.claim_vagrant`. If one is
    available, it will be imported. If one is not available, one will be launched with
    :meth:`boxer.commands.create_vagrant.create_vagrant`

    To control the vagrant claimed/created with this command, use :meth:`boxer.commands.v.v`
    """
    email = email or os.environ.get('UBER_OWNER')
    if not email:
        fail(ctx, msg="UBER_OWNER env var not set to your @uber.com email! Please export it in your ~/.bash_profile or similar")

    if not name:
        if update:
            fail(ctx, msg="Cannot run update without a --name")
        if '+' in email:
            raise NotImplementedError("Cannot currently handle emails with a + in them")
        name, _ = email.split('@', 1)

    name = sanitize_vagrant_name(name)

    # update and try_claim_vagrant don't make sense to use together
    if not update:
        if try_claim_vagrant:
            try:
                return ctx.invoke(
                    claim_vagrant,
                    email=email,  # pass this through since it may have changed
                    force=force,
                    name=name,  # pass this through since it may have changed
                    **kwargs
                )
            # todo: check exit code/return instead of checking for an exception
            except BoxerException as e:
                log.info("Unable to claim an instance from lifeguard: %s", e)
                # todo: guess time from the role being built
            except Exception as e:
                log.error("Unable to claim an instance for an unexpected reason! %s", e)

    if try_create_vagrant:
        return ctx.invoke(
            create_vagrant,
            check_existing=check_existing,  # pass this through since it may have changed
            email=email,  # pass this through since it may have changed
            force=force,
            name=name,  # pass this through since it may have changed
            update=update,
            **kwargs
        )

    fail(ctx, msg="Failed to claim or create a vagrant", output=False)
