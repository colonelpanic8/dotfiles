import logging
import os
import os.path
import shutil
import tarfile
import tempfile

import click

from boxer import config
from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, get_s3_bucket, is_local_vagrant_or_fail

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.option('--delete-local/--no-delete-local', default=False)
@click.pass_context
def export_vagrant(ctx, delete_local, name):
    """Export a vagrant's info to S3."""
    name = is_local_vagrant_or_fail(ctx, name)

    boxer_config = ctx.find_object(config.BoxerConfig)

    vagrant_root = boxer_config.get('vagrant_root')
    if not vagrant_root:  # pragma: no cover
        raise Exception("VAGRANT_ROOT not found in config!")

    with boxer_lock(ctx, name):
        vagrant_dir = os.path.join(vagrant_root, name)

        # create tar.gz of vagrant_dir
        tf = None
        tar = None
        try:
            tf = tempfile.NamedTemporaryFile(delete=False)
            tf.close()

            with tarfile.open(tf.name, 'w:gz') as tar:
                tar.add(vagrant_dir, arcname=name)

            # ship the file to s3
            bucket = get_s3_bucket(ctx)
            key = bucket.new_key("vagrants/%s.tar.gz" % name)
            key.set_contents_from_filename(tf.name)
            log.info("Uploaded %s.tar.gz to S3", name)
        except Exception:
            raise
        else:
            if delete_local:
                shutil.rmtree(vagrant_dir)
                log.info("Deleted local copy of the Vagrantfile")
        finally:
            # cleanup the file
            if tar:
                if not tar.closed:
                    tar.close()
            if tf:
                if not tf.closed:
                    tf.close()
                os.unlink(tf.name)

    return BoxerClickReturn(output=key)
