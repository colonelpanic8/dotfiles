import logging
import urllib
import urlparse

import click

from boxer.cli import cli
from boxer.click_lib import click_command, click_vagrant_options, fail
from boxer.commands.import_vagrant import import_vagrant
from boxer.exc import LifeguardPoolEmpty

log = logging.getLogger(__name__)


lifeguard_keys = [
    'aws_disk_size',
    'aws_mnt_size',
    'aws_region',
    'aws_type',
    'aws_zone',  # todo: this doesn't do anything right now
    'build_num',
    'distro',
    'owner',
    'services',
    'uber_env',
    'uber_role',
    'uber_service',
    'with_aws_vpc',
]
lifeguard_map = {
    'owner': ['email'],
    'uber_role': ['override_role', 'role', 'fallback_role'],
    'uber_env': ['env'],
}


@click_command(group=cli)
@click.option('--beta', default=False, is_flag=True)
@click.option('--lifeguard-url', default='https://lifeguard.uberinternal.com/')
@click_vagrant_options
def claim_vagrant(
    ctx, beta, lifeguard_url, **extra_kwargs
):
    """Ask lifeguard for a vagrant.

    .. TODO::
        link to click_vagrant_options for the rest of the vagrant commands
        support things not AWS?

    The simplest usage is to run this one command then follow the instructions it prints::

        \b
        boxer claim_vagrant VAGRANTNAME
    """
    if not beta:
        raise LifeguardPoolEmpty("The pool is closed")

    email = extra_kwargs.get('email')
    if email is None or not email.strip():
        # todo: I thought required=True on there would do this for us :(
        fail(ctx, msg="UBER_OWNER env var not set to your @uber.com email! Please export it in your ~/.bash_profile or similar or use --email")

    if '.dev.uber' in lifeguard_url and not extra_kwargs['uber_service'].endswith('_dev'):
        old_uber_service = extra_kwargs['uber_service']
        extra_kwargs['uber_service'] = old_uber_service + '_dev'
        log.info("Changing uber_service from %s to %s", old_uber_service, extra_kwargs['uber_service'])

    # filter out all of the args that we don't need to give lifeguard
    claim_params = {}
    for key in lifeguard_keys:
        value = None

        if key in extra_kwargs:
            value = extra_kwargs[key]
        elif key in lifeguard_map:
            for boxer_key in lifeguard_map[key]:
                if boxer_key in extra_kwargs:
                    value = extra_kwargs[boxer_key]
                    if value is not None:
                        break

        if value is None:
            continue

        claim_params[key] = value

    lifeguard_url = lifeguard_url.replace('http://', 'https://')
    if not lifeguard_url.startswith('https://'):
        lifeguard_url = 'https://' + lifeguard_url

    claim_url = urlparse.urljoin(lifeguard_url, '/vagrant/claim')
    claim_url += '?' + urllib.urlencode(claim_params)

    # boxer can't query lifeguard directly because it is behind OAM
    click.echo("Opening %s" % claim_url)
    click.echo()
    click.launch(claim_url)

    name = click.prompt("Please enter the vagrant name given by lifeguard or press [Enter] to launch a vagrant yourself").lower()
    if not name:
        raise LifeguardPoolEmpty("No instance name given")

    return ctx.invoke(import_vagrant, name=name)
