import logging

import click

from boxer.cli import cli
from boxer.click_lib import boxer_lock, BoxerClickReturn, click_command, is_local_vagrant_or_fail, open_box_config
from boxer.lib import edit_diff

log = logging.getLogger(__name__)


@click_command(group=cli)
@click.argument('name')
@click.argument('repo')
@click.argument('diffs', nargs=-1)
@click.pass_context
def diff(ctx, name, repo, diffs):
    """Setup arc diffs for use during provisioning.

    For example, to apply DXXXX to the uber-puppet-manifests::

        \b
        boxer diff $VAGRANTNAME uber-puppet-manifests DXXXX
        boxer v $VAGRANTNAME -c provision

    You can also apply multiple diffs::

        \b
        boxer diff $VAGRANTNAME uber-puppet-manifests DXXXX DYYYY
        boxer v $VAGRANTNAME -c provision

    If you update the diff, simply re-run provision. This will patch the latest master with the latest version of the
    diff::

        \b
        boxer v $VAGRANTNAME -c provision

    To remove all puppet diffs and return to using the packaged puppet manifests::

        \b
        boxer diff $VAGRANTNAME uber-puppet-manifests
        boxer v $VAGRANTNAME -c provision
    """
    name = is_local_vagrant_or_fail(ctx, name)

    with boxer_lock(ctx, name):
        with open_box_config(ctx, name) as box_data:
            edit_diff(box_data, repo, diffs)

    # todo: maybe run this automatically?
    log.info("You should now run 'boxer v %s -c provision'", name)
    return BoxerClickReturn(output=True)
