
#? ['raise']
raise

#? ['except', 'Exception']
except
