*******
Authors
*******

Contributors to pyspotify in the order of appearance:

.. include:: ../AUTHORS
