Session settings
****************

.. currentmodule:: spotify

.. autoclass:: Settings
    :members:
