Error handling
==============
.. currentmodule:: spotify


.. exception:: SpotifyError

This is the exception used by *pyspotify* to transmit Spotify errors to the
Python application.
