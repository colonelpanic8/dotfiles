.. include:: ../README.rst

Table of contents
=================

.. toctree::
    :maxdepth: 2

    introduction
    managers/index
    audiosink
    api/index
    changes
    development
    authors
    licenses
