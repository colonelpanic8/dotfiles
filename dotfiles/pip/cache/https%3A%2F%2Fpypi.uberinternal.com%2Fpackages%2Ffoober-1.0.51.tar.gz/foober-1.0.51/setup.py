#!/usr/bin/env python
"""All the code that has no home."""
import imp
foober_setup = imp.load_source('foober_setup', "foober/setup.py")


foober_setup.setup(
    author='Ignas Mikalajunas',
    author_email='ignas@uber.com',
    description=__doc__,
    name='foober',
    version='1.0.51',
    package_data={'foober': ['sh/*.sh',
                             'templates/*/*']},
    entry_points={
        'console_scripts': [
            'foober = foober.script.main:main',
        ]
    })
