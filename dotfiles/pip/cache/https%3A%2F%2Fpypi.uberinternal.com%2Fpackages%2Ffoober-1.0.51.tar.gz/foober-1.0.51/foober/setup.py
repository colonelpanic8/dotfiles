# This module should not depend on anything not installed in a clean virtualenv
import sys
import os
from setuptools.command.test import test as TestCommand

from setuptools import setup as setuptools_setup, find_packages


def requirements(*filenames):
    requires = []

    for filename in filenames:
        if not os.path.exists(filename):
            continue
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    # skip blank lines and comments
                    continue
                requires.append(line)

    return requires


class Tox(TestCommand):
    """Class to get setuptools/distribute to run tox.

    This makes `python setup.py test` work.
    """

    user_options = [('tox-args=', 'a', "Arguments to pass to tox")]

    def initialize_options(self):
        TestCommand.initialize_options(self)
        self.tox_args = None

    def finalize_options(self):
        TestCommand.finalize_options(self)
        self.test_args = []
        self.test_suite = True

    def run_tests(self):
        # import here, cause outside the eggs aren't loaded
        import tox
        args = []
        if self.tox_args:
            import shlex
            args = shlex.split(self.tox_args)
        errno = tox.cmdline(args=args)
        sys.exit(errno)


def setup(**kwargs):
    defaults = dict(
        classifiers=['Private :: Do Not Upload'],
        cmdclass={'test': Tox},
        extras_require={
            'dev': requirements('requirements-dev.txt'),
            'tests': requirements('requirements-tox.txt', 'requirements-tests.txt'),
        },
        install_requires=requirements('requirements.txt'),
        packages=find_packages(),
        tests_require=requirements('requirements-tox.txt'),
        url='https://engdocs.uber.com/{}/'.format(kwargs['name']))
    defaults.update(kwargs)
    setuptools_setup(**defaults)
