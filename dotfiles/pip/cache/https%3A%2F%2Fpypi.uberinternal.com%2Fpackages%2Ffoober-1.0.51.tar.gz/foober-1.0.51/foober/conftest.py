import pytest


class StaticRegistry(object):
    """Dummy registry that only has a dict of facts."""

    def __init__(self):
        self._facts = {}

    def getFact(self, key):
        return self._facts[key]

    def setFact(self, key, value):
        self._facts.setdefault(key, value)


@pytest.fixture
def static_registry():
    return StaticRegistry()
