#!/bin/bash

set -e

THRIFT_DIR="./thrift/"

if [ ! -d "$THRIFT_DIR" ]; then
    echo "thrift directory doesn't exist."
    exit 0
fi

CUR_DIR="$(pwd)"
TEMP_DIR="$(mktemp -d thrift-docs-XXXX)"
INDEX_THRIFT="$TEMP_DIR/index.thrift"

trap "rm -rf '$TEMP_DIR' 2> /dev/null" EXIT

#find all the .thrift
#create tmp/index.thrift to include all the .thrift file
find "$THRIFT_DIR" -name "*.thrift" | while read line; do
    include_line="include '$CUR_DIR/$line'"
    echo "$include_line" >> "$INDEX_THRIFT"
done

#generate html doc
if [ -f "$INDEX_THRIFT" ]; then
    DOC_PATH="thrift_docs/html"
    mkdir -p "$DOC_PATH"
    thrift -r -out "$DOC_PATH"  --gen html "$INDEX_THRIFT"
fi
