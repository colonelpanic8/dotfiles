#!/bin/bash
set -e
set -v
set -x

WORKSPACE=${WORKSPACE:-`pwd`/workspace}
export PGPORT=${PGPORT:-9876}

PRUNE_TARGET=$1
PRUNE_BUCKET=${2:-"uber-devtools/prunes"}

clean_exit() {
    local error_code="$?"
    echo $(jobs -p)
    kill -2 $(jobs -p) >/dev/null 2>&1 || true
    echo $(jobs -p)
    sleep 20
    echo $(jobs -p)
    kill -9 $(jobs -p) >/dev/null 2>&1 || true
    echo $(jobs -p)
    rm -rf "$PGSQL_DATA"
    return $error_code
}

check_for_cmd () {
    if ! which "$1" >/dev/null 2>&1
    then
        echo "Could not find $1 command" 1>&2
        exit 1
    fi
}

wait_for_line () {
    while read line
    do
        echo "$line"
        echo "$line" | grep -q "$1" && break
    done < "$2"
    # Read the fifo for ever otherwise process would block
    cat "$2" >/dev/null &
}

check_for_cmd pg_config

trap "clean_exit" EXIT

# Start PostgreSQL process for tests
PGSQL_DATA=`mktemp -d $WORKSPACE/PGSQL-XXXXX`
PGSQL_PATH=`pg_config --bindir`
${PGSQL_PATH}/initdb -E UNICODE -U ${PRUNE_TARGET} ${PGSQL_DATA}

# empty file
touch ${PGSQL_DATA}/pg_ident.conf

printf "#postgres config by jenkins
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all             ${PRUNE_TARGET}                               trust
" >> ${PGSQL_DATA}/pg_hba.conf

printf "#postgres config by jenkins
listen_addresses = ''
max_connections = 10
ssl = false
shared_buffers = 1500MB
work_mem = 64MB
maintenance_work_mem = 1GB
client_encoding = 'UTF8'
lc_messages = 'en_US.utf8'
lc_monetary = 'en_US.utf8'
lc_numeric = 'en_US.utf8'
lc_time = 'en_US.utf8'
default_text_search_config = 'pg_catalog.english'
autovacuum = off
checkpoint_segments = 64
wal_level = minimal
archive_mode = off
max_wal_senders = 0
" >> ${PGSQL_DATA}/postgresql.conf

mkfifo ${PGSQL_DATA}/out
${PGSQL_PATH}/postgres -F -k ${PGSQL_DATA} -p ${PGPORT} -D ${PGSQL_DATA} &> ${PGSQL_DATA}/out &
POSTGRESQL_PID="$!"
echo "Postgresql pid is $POSTGRESQL_PID"

((while kill -0 $$ ; do sleep 1; done; kill -2 $POSTGRESQL_PID ; sleep 20 ; kill -9 $POSTGRESQL_PID ; rm -rf $PGSQL_DATA) >/dev/null 2>/dev/null & ) >/dev/null 2>/dev/null &


# Wait for PostgreSQL to start listening to connections
wait_for_line "database system is ready to accept connections" ${PGSQL_DATA}/out

export PGHOST=${PGSQL_DATA}

load_table_dump_file () {
    FILENAME=${1##*/}
    TABLENAME=${FILENAME%.dump}
    psql -p ${PGPORT} -h ${PGHOST} -U ${PRUNE_TARGET} ${PRUNE_TARGET} -c "COPY ${TABLENAME} FROM '`pwd`/$1' WITH BINARY"
}

createdb -p ${PGPORT} -h ${PGHOST} -E UTF8 -U ${PRUNE_TARGET} ${PRUNE_TARGET}
pg_restore -p ${PGPORT} -h ${PGHOST} -U ${PRUNE_TARGET} -d ${PRUNE_TARGET} --jobs 4 --no-owner dumps/${PRUNE_TARGET}.dump || true
for f in `find dumps/tables -name "*.dump"`; do
    load_table_dump_file $f
done

## run-post-processing scripts
foober prune postprocess | psql -p ${PGPORT} -h ${PGHOST} -U ${PRUNE_TARGET} ${PRUNE_TARGET}

S3_DIR="s3://${PRUNE_BUCKET}/${PRUNE_TARGET}/"

TIMESTAMP=`date +%s`
PRUNED_DATA_SNAPSHOT=${PRUNE_TARGET}-pruned-${TIMESTAMP}
PRUNED_DATA_SNAPSHOT_TXT=latest-${PRUNE_TARGET}-pruned-encrypted.txt
echo "${PRUNED_DATA_SNAPSHOT}.custom.gpg" > ${PRUNED_DATA_SNAPSHOT_TXT}

# Dump the completed pruned database
pg_dump -p ${PGPORT} -h ${PGHOST} -U ${PRUNE_TARGET} --format=custom -E UTF8 ${PRUNE_TARGET} | foober prune encrypt - - > dumps/${PRUNED_DATA_SNAPSHOT}.custom.gpg
[ "$(ls -A dumps/tables)" ] && du -h dumps/tables/*
du -h dumps/*

# Upload the pruned database to s3
s3cmd put --multipart-chunk-size-mb 5120 dumps/${PRUNED_DATA_SNAPSHOT}.custom.gpg ${S3_DIR} && s3cmd put ${PRUNED_DATA_SNAPSHOT_TXT} ${S3_DIR}
