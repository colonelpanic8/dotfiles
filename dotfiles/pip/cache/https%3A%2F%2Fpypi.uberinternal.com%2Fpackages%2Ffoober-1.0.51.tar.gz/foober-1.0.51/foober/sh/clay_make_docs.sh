#!/bin/bash

set -e

VIRTUALENV=${VIRTUALENV:-env_docs}

# check requirements and potentially force REBUILD_VIRTUALENV to true
ls requirements*.txt docs/requirements*.txt | xargs md5sum > tmp.md5
if [ -f "$VIRTUALENV/requirements.md5" ]; then
  cat "$VIRTUALENV/requirements.md5" tmp.md5

  if diff "$VIRTUALENV/requirements.md5" tmp.md5; then
    echo "requirements match!"
  else
    echo "requirements differ!"
    REBUILD_VIRTUALENV="true"
  fi
fi

# Create virtualenv if we need to
if [ "$REBUILD_VIRTUALENV" = "true" ]; then
  rm -rf "$VIRTUALENV" || true
else
  echo "Leaving virtualenv alone..."
fi
if [ ! -d "$VIRTUALENV" ]; then
  mkdir -p $VIRTUALENV
  virtualenv $VIRTUALENV
fi

# save a hash of the requirements we are going to install in the env
mv tmp.md5 $VIRTUALENV/requirements.md5

# enter the virtualenv
. $VIRTUALENV/bin/activate

# make sure pip is recent
pip install --upgrade "pip >=1.5.6, <1.6"

set -x

# install the app and some extras
ls requirements*.txt docs/requirements*.txt | xargs -n1 pip install -r
if [ -f "setup.py" ]; then
    pip install -e .
fi

# make the docs
cd docs
SPHINXOPTS=-W make html
