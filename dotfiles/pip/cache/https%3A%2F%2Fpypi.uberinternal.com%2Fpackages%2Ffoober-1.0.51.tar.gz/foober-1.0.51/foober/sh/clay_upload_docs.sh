#!/bin/bash
set -ex
ARGS=( "$@" )
PROJECT_NAME="${ARGS[0]}"
rsync -av --delete docs/_build/html/ "uber@engdocs-master.uber.internal:/srv/engdocs/${PROJECT_NAME}"
