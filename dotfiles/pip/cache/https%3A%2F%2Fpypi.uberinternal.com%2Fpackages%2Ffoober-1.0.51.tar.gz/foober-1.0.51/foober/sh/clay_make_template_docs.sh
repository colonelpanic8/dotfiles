#!/bin/bash

SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
ARGS=( "$@" )
PROJECT_NAME="${ARGS[0]}"
PROJECT_TITLE="${ARGS[1]:-$PROJECT_NAME}"
WORKING_DIR=`pwd`

set -e

clean_exit() {
    local error_code="$?"
    rm -f "${WORKING_DIR}/docs/Makefile"
    rm -f "${WORKING_DIR}/docs/conf.py"
    rm -f "${WORKING_DIR}/docs/requirements-docs.txt"
    rm -f "${WORKING_DIR}/docs/docs_params.py"
    return $error_code
}

trap "clean_exit" EXIT SIGTERM SIGQUIT SIGABRT

cp "${SCRIPT_DIR}/../templates/clay-docs/Makefile" docs/Makefile
cp "${SCRIPT_DIR}/../templates/clay-docs/conf.py-template" docs/conf.py
cp "${SCRIPT_DIR}/../templates/clay-docs/requirements-docs.txt" docs/requirements-docs.txt

mkdir -p "${WORKING_DIR}/docs/_static"

cat > docs/docs_params.py <<EOF
import pkg_resources
package = """${PROJECT_NAME}"""  # the name of the egg
try:
    distribution = pkg_resources.get_distribution(package)
    version = distribution.version
    project = distribution.project_name
except:
    version = '1.0.0'
    project = package
one_line = """${PROJECT_TITLE}"""
EOF

. "${SCRIPT_DIR}/clay_make_docs.sh"
