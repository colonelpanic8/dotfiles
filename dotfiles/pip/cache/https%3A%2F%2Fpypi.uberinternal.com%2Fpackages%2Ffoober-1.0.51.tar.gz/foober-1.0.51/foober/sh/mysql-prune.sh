#!/bin/bash
set -e
set -v
set -x

WORKSPACE=${WORKSPACE:-`pwd`/workspace}
PRUNE_TARGET=$1
PRUNE_DATABASE=${2:-$PRUNE_TARGET}
PRUNE_BUCKET=${3:-"uber-devtools/prunes"}
if [ ! -d ${WORKSPACE} ]; then
    mkdir -p ${WORKSPACE}
fi

MYSQL_DATA=`mktemp -d $WORKSPACE/MYSQL-XXXXX`
MYSQL_SOCKET=${MYSQL_DATA}/mysql.sock
MYSQL_PATH=${MYSQL_PATH:-/usr}

S3_DIR="s3://${PRUNE_BUCKET}/${PRUNE_TARGET}/"

clean_exit() {
    local error_code="$?"
    echo $(jobs -p)
    kill -2 $(jobs -p) >/dev/null 2>&1 || true
    echo $(jobs -p)
    sleep 20
    echo $(jobs -p)
    kill -9 $(jobs -p) >/dev/null 2>&1 || true
    echo $(jobs -p)
    rm -rf "$MYSQL_DATA"
    return $error_code
}

check_for_cmd () {
    if ! which "$1" >/dev/null 2>&1
    then
        echo "Could not find $1 command" 1>&2
        exit 1
    fi
}

wait_for_line () {
    while read line
    do
        echo "$line"
        echo "$line" | grep -q "$1" && break
    done < "$2"
    # Read the fifo for ever otherwise process would block
    cat "$2" >/dev/null &
}

check_for_cmd mysqld

trap "clean_exit" EXIT SIGTERM SIGQUIT SIGABRT

printf "# prune db config
[mysqld]
skip-networking
bind-address=127.0.0.1
innodb_buffer_pool_size=1GB
innodb_flush_method=O_DIRECT
innodb_flush_log_at_trx_commit=2
" > ${WORKSPACE}/my.cnf

# Create the database
${MYSQL_PATH}/bin/mysql_install_db --user=${PRUNE_TARGET} --datadir=${MYSQL_DATA} --basedir=${MYSQL_PATH} --defaults-file=${WORKSPACE}/my.cnf

mkfifo ${MYSQL_DATA}/out
# Start server and wait for database to start listening to connections
${MYSQL_PATH}/sbin/mysqld --defaults-file=${WORKSPACE}/my.cnf --socket=${MYSQL_SOCKET} --datadir=${MYSQL_DATA} &> ${MYSQL_DATA}/out &
MYSQL_PID="$!"
echo "Mysql pid is $MYSQL_PID"

((while kill -0 $$ ; do sleep 1; done; kill $MYSQL_PID ; sleep 20 ; kill -9 $MYSQL_PID ; rm -rf $MYSQL_DATA) >/dev/null 2>/dev/null & ) >/dev/null 2>/dev/null &
wait_for_line "mysqld: ready for connections." ${MYSQL_DATA}/out

# Give MySQL enough time to actually setup the socket
sleep 5

# Create database and permissions
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root -e "CREATE DATABASE ${PRUNE_DATABASE};"
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root -e "CREATE USER '${PRUNE_TARGET}' IDENTIFIED BY '';"
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root -e "GRANT ALL ON ${PRUNE_DATABASE}.* TO '${PRUNE_TARGET}'@'localhost';"
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root -e "UPDATE mysql.user SET Super_Priv='Y' WHERE user='${PRUNE_TARGET}' AND host='localhost';"
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root -e "FLUSH PRIVILEGES;"
${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u ${PRUNE_TARGET} ${PRUNE_DATABASE} < dumps/${PRUNE_TARGET}.dump

## Restore pruned tables
for f in `find dumps/tables -name "*.dump"`; do
  FILENAME=${f##*/}
  ${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root ${PRUNE_DATABASE} < `pwd`/$f
done

## run-post-processing scripts
foober prune postprocess | ${MYSQL_PATH}/bin/mysql --socket=${MYSQL_SOCKET} -u root ${PRUNE_DATABASE}

TIMESTAMP=`date +%s`
PRUNED_DATA_SNAPSHOT=${PRUNE_TARGET}-pruned-${TIMESTAMP}
PRUNED_DATA_SNAPSHOT_TXT=latest-${PRUNE_TARGET}-pruned-encrypted.txt
echo "${PRUNED_DATA_SNAPSHOT}.custom.gpg" > ${PRUNED_DATA_SNAPSHOT_TXT}

# Dump the completed pruned database
${MYSQL_PATH}/bin/mysqldump --opt --set-gtid-purged=off --socket=${MYSQL_SOCKET} -u ${PRUNE_TARGET} ${PRUNE_DATABASE} | foober prune encrypt - - > dumps/${PRUNED_DATA_SNAPSHOT}.custom.gpg
[ "$(ls -A dumps/tables)" ] && du -h dumps/tables/*
du -h dumps/*

# Upload the pruned database to s3
s3cmd put --multipart-chunk-size-mb 5120 dumps/${PRUNED_DATA_SNAPSHOT}.custom.gpg ${S3_DIR} && s3cmd put ${PRUNED_DATA_SNAPSHOT_TXT} ${S3_DIR}
