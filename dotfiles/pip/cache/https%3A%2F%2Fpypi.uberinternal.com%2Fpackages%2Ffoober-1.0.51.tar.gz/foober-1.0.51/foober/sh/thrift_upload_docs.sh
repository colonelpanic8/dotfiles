#!/bin/bash
set -ex
ARGS=( "$@" )
PROJECT_NAME="${ARGS[0]}"
rsync -av --delete thrift_docs/html/ "uber@engdocs-master.uber.internal:/srv/engdocs/${PROJECT_NAME}/thrift"
