"""Context for all the foober commands."""
from __future__ import absolute_import
import atexit
import functools
import os
import urllib
import urllib2

import json

from foober.lib.jenkins import FooberJenkinsClient
from foober.lib.phabricator import arc
from foober.lib.proxies import LazyProxy
from foober.lib.utils import FooberLocalPath


def initialize_repo(repo_dir, repo_url, phab_callsign):
    if phab_callsign and repo_url is None:
        repos = arc('repository.query',
                    dict(callsigns=[phab_callsign]))
        repo_url = repos[0]['remoteURI']

    if repo_url is None and repo_dir is None:
        repo_dir = FooberLocalPath(os.path.abspath('.'))
    elif repo_url:
        repo_dir = FooberLocalPath.mkdtemp()
        atexit.register(repo_dir.remove)
        FooberLocalPath(FooberLocalPath.sysfind('git')).system(
            'clone', repo_url, str(repo_dir))
    else:
        repo_dir = FooberLocalPath(repo_dir)
    os.chdir(str(repo_dir))
    return repo_dir


class CommandContext(object):
    """A class that constructs a context for a command.

    Context is:

      - the directory to run the command in
      - the environment for the command (jenkins/osx/production/development)
      - fact overrides from environment, command line and files
      - handle to fact extraction objects

    TODO: decide if this class should be the place that handles
    creation of the context if passed a gitolite/github uri.

    """

    def __init__(self):
        """Constructor takes no parameters.

        This is so we could initialize it outside of cli context.
        """

    def detectEnvironment(self):
        """Environment detection code.

        Execution environments supported (for now):

         - jenkins
         - osx
         - production
         - development

        """
        if 'JENKINS_URL' in os.environ:
            return 'jenkins'

        if 'Darwin' in os.uname():
            return 'osx'

        try:
            with open('/etc/facts.d/uber.json') as facts_file:
                facts = json.load(facts_file)
                if facts['uber_environment'] == 'development':
                    return 'development'
        except IOError:
            # If we can't open the file, just ignore it
            pass
        # By default assume production
        return 'production'

    def setEnvironment(self, environment=None):
        # XXX: Should this be a property?
        if environment is None:
            self.environment = self.detectEnvironment()
        else:
            self.environment = environment

    def _parseCommandLineFact(self, fact):
        return fact.split('=', 1)

    def setUp(self, repo_dir, environment, registry=None, facts=(),
              repo_url=None, phab_callsign=None):
        """All initialization is performed in this method."""
        self.setEnvironment(environment)

        self.root = LazyProxy(functools.partial(initialize_repo,
                                                repo_dir, repo_url,
                                                phab_callsign))

        if registry is not None:
            self.registry = registry
        else:
            from foober.lib.facts.registries import registry as extractor_registry
            from foober.lib.facts import FactRegistry
            self.registry = FactRegistry(self.root, extractor_registry)

        # Pre-set all the facts passed via command line
        for fact in facts:
            key, value = self._parseCommandLineFact(fact)
            self.registry.setFact(key, value)

    def getFact(self, key):
        """Strict getter, raises error if fact not found."""
        return self.registry.getFact(key)

    def queryFact(self, key, default=None):
        """Return None or default if fact not found."""
        return self.registry.getFact(key, default)

    def clustoRequest(self, endpoint, **kwargs):
        password = self.getFact('secret.clusto.password')
        username = self.getFact('secret.clusto.username')
        req = urllib2.Request('http://clusto.local.uber.internal/api%s?%s' % (
            endpoint, urllib.urlencode(kwargs)
        ), headers={
            'Authorization': 'Basic %s' % '{username}:{password}'.format(
                username=username,
                password=password).encode('base64'),
        })
        resp = urllib2.urlopen(req)
        return json.load(resp)

    _jenkins = None

    @property
    def jenkins(self):
        if self._jenkins is None:
            self._jenkins = FooberJenkinsClient(self.registry)
        return self._jenkins
