import click
import datetime
import time

from foober.script.cli import cli
from foober.lib.phabricator import arc, find_user_phids, whoami
from pytz import timezone


@cli.group()
def phab():
    """Root command for phab."""
    pass


@phab.command()
@click.option('--status', '-s', default='open',
              type=click.Choice(['open', 'closed', 'any']),
              help='Show tasks that or open, closed or all, default is open.')
@click.option('--owner', '-o', multiple=True, default=None,
              help='Only show tasks assigned to the given username, default is you.')
@click.option('--period', '-p', default=0, type=int,
              help='Display only tasks modified during given period of days.')
def tasks(status, owner, period):
    """List Phabricator tasks."""
    owners = list(set(owner))

    time_from = None
    if period > 0:
        # Timezone on Phabricator config
        phab_tz = timezone('America/Los_Angeles')
        date_from = datetime.datetime.now(phab_tz) - datetime.timedelta(days=period)
        time_from = int(time.mktime(date_from.date().timetuple()))

    if not owners:
        owners = (whoami()['userName'],)

    phids = find_user_phids(owners)

    if len(owners) > len(phids):
        missing = set(owners) - set(phids.keys())
        click.echo(click.style("Warning: Missing users ({})".format(", ".join(missing)), fg="red"),
                   err=True)

        if not len(phids):
            return

    for username in phids:
        if len(owners) > 1:
            click.echo("========================================")
            click.echo(u"@{} tasks:".format(username))
            click.echo("========================================")

        task_list = arc("maniphest.query", {"ownerPHIDs": [phids[username]],
                                            "status": "status-{}".format(status),
                                            "order": "order-modified"})

        filtered_tasks = [
            task for task in task_list.values()
            if time_from <= int(task['dateModified'])]

        # Calculate widths for columns
        width = {}
        for column in ['id', 'statusName', 'priority']:
            width['w_' + column] = max([len(t[column]) for t in filtered_tasks])

        template = (u"T{id:{w_id}}  {statusName:{w_statusName}}"
                    "  {priority:{w_priority}} {title}")
        for task in filtered_tasks:
            click.echo(template.format(**dict(width.items() + task.items())))
