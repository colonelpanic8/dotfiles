"""The cli integration file.

All the sub-commands of foober must be imported in here to get
registered with the root click group.
"""


import foober.script.docs  # noqa
import foober.script.jenkins  # noqa
import foober.script.prune  # noqa
import foober.script.phab  # noqa
from foober.script.cli import cli as main  # noqa
