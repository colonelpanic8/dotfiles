"""Root foober command"""
import atexit
import functools

import json
import click

from foober.lib.utils import yaml_dump
from foober.script.context import CommandContext


@click.group()
@click.option('--repo-dir', default=None, help='Directory of the repository')
@click.option('--repo-url', default=None, help='Url of the repository')
@click.option('--phab-callsign', default=None, help='Phabricator callsign')
@click.option('--environment', default=None, help='Environment to run command in')
@click.option('--trace', 'tracing', flag_value='trace')
@click.option('--insecure-trace', 'tracing', flag_value='all')
@click.option('--fact', default=None, help='', multiple=True,
              envvar='FOOBER_FACTS')
@click.pass_context
def cli(ctx, repo_dir, repo_url, phab_callsign, environment, tracing, fact):
    """Root foober command group.

    Sets up the repository context in which sub-commands will be
    executed.
    """
    ctx.obj = CommandContext()
    ctx.obj.setUp(repo_dir, environment, facts=fact, repo_url=repo_url,
                  phab_callsign=phab_callsign)

    if tracing:
        atexit.register(functools.partial(ctx.obj.registry.printTrace,
                                          with_secrets=(tracing == 'all')))


@cli.command()
@click.argument('fact', nargs=-1)
@click.option('--format', type=click.Choice(["json", "yaml"]), default="yaml")
@click.pass_obj
def debug(ctx, fact, format):
    """Print debug info."""
    if not fact:
        fact = ['project.name',
                'project.type',
                'project.git_url']

    result = {
        fact_name: ctx.getFact(fact_name)
        for fact_name in fact}

    result.update({
        'environment': ctx.environment,
        'working_dircetory': str(ctx.root)})

    if format == 'yaml':
        formatter = yaml_dump
    else:
        formatter = functools.partial(json.dumps, indent=2)

    click.echo(formatter(result))


@cli.command()
@click.argument('fact', nargs=-1)
@click.pass_obj
def trace(ctx, fact):
    if not fact:
        fact = ['project.name', 'project.type']
    for fact_name in fact:
        ctx.getFact(fact_name)
    ctx.registry.printTrace(fact, stdout=True)


# XXX add --ignore-all-errors to ignore all exceptions not just fact related ones
@cli.command()
@click.option('--ignore-errors/--show-errors', default=False)
@click.pass_obj
def extract_all(ctx, ignore_errors):
    """Extract all the facts that we can."""
    print yaml_dump(ctx.registry.extractAllFacts(ignore_errors))
