import os
import pkg_resources
import click

from foober.lib.utils import FooberLocalPath
from foober.script.cli import cli


@cli.group()
def docs():
    """Root command for docs."""


@docs.command()
@click.pass_obj
def upload(ctx):
    """Upload docs to the docs server."""
    # XXX: Maybe only allow running this on jenkins
    upload_sh = ctx.root.join('bin/upload_docs.sh')
    if upload_sh.exists():
        exit(upload_sh.system())

    status = 0
    # Clay
    generated_index = ctx.root.join('docs/_build/html/index.html')
    if generated_index.exists():
        command_path = os.path.abspath(
            pkg_resources.resource_filename('foober', 'sh/clay_upload_docs.sh'))
        status |= FooberLocalPath(command_path).system(ctx.getFact('project.name'))

    # Thrift
    generated_index = ctx.root.join('thrift_docs/html/index.html')
    if status == 0 and generated_index.exists():
        command_path = os.path.abspath(
            pkg_resources.resource_filename('foober', 'sh/thrift_upload_docs.sh'))
        status |= FooberLocalPath(command_path).system(ctx.getFact('project.name'))

    exit(status)


@docs.command()
@click.option('--thrift-only', is_flag=True, help='build only thrift service documentation')
@click.pass_obj
def make(ctx, thrift_only):
    """Build a docs for a repo."""
    status = 0
    if not thrift_only:
        for config_path in [
                ctx.root.join('config', 'docs.yaml'),
                ctx.root.join('config', 'test.yaml'),
                ctx.root.join('config', 'development.yaml')]:
            if config_path.exists():
                os.environ['CLAY_CONFIG'] = str(config_path)
                break

        make_sh = ctx.root.join('bin/make_docs.sh')
        if make_sh.exists():
            exit(make_sh.system())

        # Clay
        docs_make_file = ctx.root.join('docs/Makefile')
        docs_index_file = ctx.root.join('docs/index.rst')

        if docs_make_file.exists():
            command_path = os.path.abspath(
                pkg_resources.resource_filename('foober', 'sh/clay_make_docs.sh'))
            status |= FooberLocalPath(command_path).system()
        elif docs_index_file.exists():
            command_path = os.path.abspath(
                pkg_resources.resource_filename('foober', 'sh/clay_make_template_docs.sh'))
            status |= FooberLocalPath(command_path).system(ctx.getFact('project.name'),
                                                           ctx.getFact('project.title'))

    # Thrift
    if status == 0:
        command_path = os.path.abspath(
            pkg_resources.resource_filename('foober', 'sh/thrift_make_docs.sh'))
        status |= FooberLocalPath(command_path).system()

    exit(status)
