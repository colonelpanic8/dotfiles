import click
import lxml.etree
from lxml.doctestcompare import LXMLOutputChecker

from foober.lib.phabricator import arc
from foober.script.cli import cli

JOB_TEMPATES = {'test': {'python-clay': 'test-playdoh-template-clay',
                         'python-library': 'test-playdoh-template-clay',
                         'node': 'test-playdoh-template-playdoh'},
                'prune': 'foober-template-prune'}


@cli.group()
def jenkins():
    pass


@jenkins.command()
def test():
    click.echo('Running tests')


@jenkins.group()
def job():
    pass


def get_template_name(template, project_type):
    job_names = JOB_TEMPATES[template]
    if isinstance(job_names, basestring):
        return job_names
    return job_names[project_type]


def register_with_phabricator(ctx, job_name=None, job_token=None):
    if job_name is None:
        job_name = 'test-' + ctx.getFact('project.name')
    build_plan_name = job_name

    click.echo("Registering '{}' with phabricator".format(job_name))

    plans = arc('harbormaster.uber_querybuildplans',
                dict(names=[build_plan_name]))

    if plans:
        plans = [plan
                 for phid, plan in plans.items()
                 if plan['planStatus'] == 'active']

    if plans:
        click.echo("Build plan '{}' already exists, not doing anything".format(
            build_plan_name))
        # TODO: Validate the plan for being active, having right build
        # steps and having a herald rule (can't do that now as there
        # is no way to query herald rules)
        return

    repo_phid = ctx.getFact('project.phab.phid')
    if job_token is None:
        job_token = ctx.jenkins.get_job_token(job_name)

    click.echo("Making a new build plan '{}'".format(build_plan_name))
    plan = arc("harbormaster.uber_createbuildplan", dict(name=build_plan_name))

    build_plan_phid = plan['phid']
    build_plan_id = plan['id']

    click.echo("Adding build steps for '{}'".format(build_plan_name))
    arc("harbormaster.uber_addbuildstep_httprequest",
        dict(plan_id=build_plan_id,
             name='Make HTTP Request',
             method='POST',
             uri=('https://ci.uber.com/buildByToken/'
                  'buildWithParameters?job=test-foober'
                  '&token=' + job_token +
                  '&DIFF_ID=${buildable.diff}'
                  '&PHID=${target.phid}'),
             waitForMessage=1,
             description=''))

    herald_rule_name = "{} Diffs should triger {} jenkins job".format(
        ctx.getFact('project.name'),
        build_plan_name)

    click.echo("Adding herald rule '{}'".format(herald_rule_name))
    arc("herald.uber_createrule_repobuilds",
        dict(name=herald_rule_name,
             repo_phids=[repo_phid],
             build_plans_phids=[build_plan_phid]))


@job.command()
@click.argument('job_type', type=click.Choice(JOB_TEMPATES))
@click.option('--template-job-name', default=None,
              help='Job to copy and modify')
@click.option('--job-name', default=None,
              help='Test job name')
@click.pass_obj
def make(ctx, job_type, template_job_name=None, job_name=None):
    title = ctx.getFact('project.name')
    if job_name is None:
        job_name = "{}-{}".format(job_type, title)
    if template_job_name is None:
        project_type = ctx.getFact('project.type')
        template_job_name = get_template_name(job_type, project_type)
    git_url = ctx.getFact('project.git_url')
    click.echo('Creating jenkins job named {} from {} for repo {}'.format(
        job_name, template_job_name, git_url))
    url = ctx.jenkins.create_job_from_template(title, job_name, git_url, template_job_name)
    click.echo("Created {}".format(url))
    register_with_phabricator(ctx, job_name)


@job.command()
@click.option('--job-name', default=None,
              help='Test job name')
@click.option('--job-token', default=None,
              help='Test job auth token')
@click.pass_obj
def register(ctx, job_name=None, job_token=None):
    register_with_phabricator(ctx, job_name, job_token)


@job.command()
@click.argument('template', type=click.Choice(JOB_TEMPATES))
@click.pass_obj
def update(ctx, template):
    click.echo('Updating foober jenkins {} job'.format(template))


@job.command()
@click.argument('template', type=click.Choice(JOB_TEMPATES))
@click.pass_obj
def delete(ctx, template):
    click.echo('Deleting foober jenkins {} job'.format(template))


@job.command()
@click.argument('job_name')
@click.pass_obj
def get(ctx, job_name):
    print ctx.jenkins.get_job_config(job_name)


# '/project/properties/hudson.security.AuthorizationMatrixProperty'
# '/project/builders'
# '/project/description'
@job.command()
@click.argument('this_job')
@click.argument('other_job')
@click.argument('xpath')
@click.pass_obj
def compare(ctx, this_job, other_job, xpath):
    this = ctx.jenkins.get_job_config_tree(this_job)
    other = ctx.jenkins.get_job_config_tree(other_job)

    this_section = this.xpath(xpath)[0]
    other_section = other.xpath(xpath)[0]

    loc = LXMLOutputChecker()
    match = loc.compare_docs(this_section, other_section)
    if match:
        print "Elements are equal"
    else:
        print lxml.etree.tostring(this_section)
        print lxml.etree.tostring(other_section)
