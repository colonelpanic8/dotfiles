from __future__ import absolute_import

import os
import logging
import subprocess
import urllib2
import json
import yaml

from foober.lib.extractors import Extractor, AppInfoExtractor, AppTypeExtractor, RequirementExtractor, SetupPyExtractor,\
    LoggingExtractor, SentryExtractor, ProductionExtractor, PDTeamExtractor, UdeployExtractor, CommittersExtractor,\
    Email2PhidExtractor, PhabTaskInfoExtractor, NodeDependenciesExtractor, RepoHeadExtractor, PuppetHeadExtractor,\
    ClayYamlConfigExtractor


log = logging.getLogger('extract_app_info')


def normalize_path(app_repo):
    return app_repo.replace('/', '--')


def ensure_repo(app_repo, repo_dir):
    normalized_path = os.path.join(repo_dir, normalize_path(app_repo))
    if not os.path.exists(normalized_path):
        subprocess.check_output(['git', 'clone',
                                 'gitolite@code.uber.internal:{}'.format(app_repo),
                                 normalized_path],
                                stderr=subprocess.STDOUT)
    else:
        subprocess.check_output(['git pull'],
                                cwd=normalized_path,
                                stderr=subprocess.STDOUT)
    return normalized_path


class Fact(object):
    """Deprecated fact storage class."""

    error = False
    ok = False
    data = None
    important = True

    def __init__(self, name, state):
        self.name = name
        self.state = state


class ProjectState(object):
    """Collection of the project facts."""

    extractor_factories = [
        AppTypeExtractor,
        AppInfoExtractor,
        RepoHeadExtractor,
        PuppetHeadExtractor,
        ClayYamlConfigExtractor,
        RequirementExtractor,
        SetupPyExtractor,
        LoggingExtractor,
        SentryExtractor,
        ProductionExtractor,
        PDTeamExtractor,
        UdeployExtractor,
        CommittersExtractor,
        Email2PhidExtractor,
        PhabTaskInfoExtractor,
        NodeDependenciesExtractor,
    ]

    def __init__(self, app_repo, path, puppet_manifests_path):
        self.path = path
        self.app_repo = app_repo
        self.state = {}
        self.extractors = []
        self.puppet_manifests_path = puppet_manifests_path
        self._facts = {}

    def info(self, name, data=None, important=True):
        fact = self.__getattr__(name)
        fact.ok = True
        fact.data = data
        fact.important = important

    def error(self, name, data=None):
        fact = self.__getattr__(name)
        fact.error = True
        fact.data = data

    def __getattr__(self, name):
        if name not in self._facts:
            self._facts[name] = Fact(name, self)
        return self._facts[name]

    @property
    def facts(self):
        return [fact
                for fact in self._facts.values()
                if not fact.error and fact.important]

    @property
    def errors(self):
        return [fact
                for fact in self._facts.values()
                if fact.error]

    def initialize(self, extractor_factories=None):
        if extractor_factories is None:
            extractor_factories = self.extractor_factories
        for factory in extractor_factories:
            extractor = factory(self)
            self.extractors.append(extractor)

    def extract(self):
        for extractor in self.extractors:
            if (extractor.apps
                    and (self.app_type.data not in extractor.apps)):
                continue

            try:
                extractor.extract()
            except Exception as e:
                self.error('{}_failed_phase1'.format(extractor.__class__.__name__),
                           str(e))
                log.exception('{}_failed_phase1'.format(extractor.__class__.__name__))

    def extract2(self):
        for extractor in self.extractors:
            try:
                extractor.extract2()
            except Exception as e:
                self.error('{}_failed_phase2'.format(extractor.__class__.__name__),
                           str(e))
                log.exception('{}_failed_phase1'.format(extractor.__class__.__name__))

    def report(self):
        report = {}
        report[self.app_repo] = results = {}

        for fact in self.facts:
            results.setdefault('facts', {})
            results['facts'][fact.name] = fact.data

        for error in self.errors:
            results.setdefault('errors', {})
            results['errors'][error.name] = error.data
        return report


def test_state_facts():
    state = ProjectState(None, None)
    assert state.requirements_txt
    assert state.requirements_txt in state.facts
    state.requirements_txt.important = False
    assert not state.facts
    state.requirements_txt.error = True
    assert state.requirements_txt not in state.facts
    assert state.requirements_txt in state.errors
    assert state.requirements_txt.name == 'requirements_txt'


def test_state_report():
    state = ProjectState('clay/app', None)
    state.info('woot', 'Ima Fact')
    state.info('woot', 'Ima Fact importante', important=True)
    state.error('even', 'cant')
    assert state.report() == {
        'clay/app': {'errors': {'even': 'cant'},
                     'facts': {'woot': 'Ima Fact importante'}}}


def test_extractor():
    state = ProjectState('clay/app', None)

    class DummyExtractor(Extractor):
        def extract(self):
            self.state.info('wat', 'yep')
            self.foo.data = self.wat.data == 'yep'

    DummyExtractor(state).extract()
    assert state.wat.data == 'yep'
    assert state.foo.data

    assert state.report() == {'clay/app': {'facts': {'foo': True, 'wat': 'yep'}}}


def extract_app_info(app_repo, app_path, puppet_manifests_path, extractor_factories=None):
    state = ProjectState(app_repo, app_path, puppet_manifests_path)
    state.initialize(extractor_factories)
    state.extract()
    state.extract2()

    Dumper = yaml.SafeDumper
    Dumper.ignore_aliases = lambda self, data: True
    return yaml.dump(state.report(), default_flow_style=False, Dumper=Dumper)


def post_app_info(repo, report, uinfra_post_url):
    data = {
        "format": "yaml",
        "source": "foober",
        "check_results": {
            repo: report
        }
    }
    headers = {
        'Content-Type': 'application/json',
    }
    req = urllib2.Request(uinfra_post_url, data=json.dumps(data), headers=headers)
    resp = urllib2.urlopen(req)
    resp = json.load(resp)
    if resp.get('error'):
        log.error("error when posting %r to uInfra: %s", repo, resp.get('error'))


def main(repositories, repo_dir, uinfra_post_url):
    puppet_manifests = os.path.join(os.getenv('UBER_HOME'), 'uber-puppet-manifests')
    for repo in repositories:
        try:
            path = ensure_repo(repo, repo_dir)
            report = extract_app_info(repo, path, puppet_manifests)
            print report
            if uinfra_post_url:
                post_app_info(repo, report, uinfra_post_url)
        except Exception:
            log.exception("Error while processing %r", repo)
