"""Fact registry and Extractor registry tests."""
from foober.lib.facts.tests.conftest import StubExtractor
from foober.lib.facts.tests.conftest import StubSecondTierExtractor


def test_you_can_register_extractor(extractor_registry):
    extractor_registry.registerExtractor(StubExtractor())
    assert len(extractor_registry.extractors) == 1
    assert extractor_registry.facts == ['project.name']


def test_you_can_register_more_extractors(extractor_registry):
    extractor_registry.registerExtractor(StubExtractor())
    extractor_registry.registerExtractor(StubSecondTierExtractor())
    assert len(extractor_registry.extractors) == 2
    assert extractor_registry.facts == ['git.url', 'project.name']


def test_you_can_get_extractors_for_fact(extractor_registry, extractor):
    extractor_registry.registerExtractor(extractor)
    assert extractor_registry.getExtractors('project.name') == [extractor]


def test_you_can_set_facts(registry):
    registry.setFact('project.name', 'dummy')
    assert registry.getFact('project.name') == 'dummy'


def test_you_can_get_facts_from_extractors(registry_with_extractors):
    assert registry_with_extractors.getFact('git.url') \
        == 'git@github.com:uber/foobie'


def test_nice_errors(registry):
    def loopy_extractor1(r):
        r.getFact('f2')

    def loopy_extractor2(r):
        r.getFact('f1')

    registry.extractors.registerExtractor(loopy_extractor1, ('f1',))
    registry.extractors.registerExtractor(loopy_extractor2, ('f2',))
    try:
        registry.getFact('f1')
    except Exception as e:
        assert e.message == 'Fact loop detected f1 => f2 => f1!'


def test_set_facts_twice(registry):
    """Setting same fact twice means first fact wins."""
    registry.setFact('wat', 'wot')
    registry.setFact('wat', 'wat')
    assert registry.getFact('wat') == 'wot'


def test_wildcard_extractors(registry):
    def wildcard_extractor(r):
        r.setFact('f1.x', 'fact')

    def normal_extractor(r):
        r.setFact('f1.y', 'fact_too')

    registry.extractors.registerExtractor(wildcard_extractor, ('f1.*',))
    registry.extractors.registerExtractor(normal_extractor, ('f1.y',))

    assert registry.getFact('f1.x') == 'fact'
    assert registry.getFact('f1.y') == 'fact_too'


def extractor_empty(r):
    """Extractor that does not register any facts."""


def extractor_one(r):
    r.setFact('f1', 'fact1')


def extractor_two(r):
    r.setFact('f1', 'fact2')


def extractor_three(r):
    r.setFact('f1', 'fact3')


def test_ordering_facts_simple(registry):
    registry.extractors.registerExtractor(extractor_one, ('f1',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    registry.extractors.registerExtractor(extractor_three, ('f1',))
    assert registry.getFact('f1') == 'fact1'


def test_ordering_facts_reversed(registry):
    registry.extractors.registerExtractor(extractor_three, ('f1',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    registry.extractors.registerExtractor(extractor_one, ('f1',))
    assert registry.getFact('f1') == 'fact3'


def test_ordering_facts_simple_wildcard(registry):
    registry.extractors.registerExtractor(extractor_one, ('*',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    registry.extractors.registerExtractor(extractor_three, ('f1',))
    assert registry.getFact('f1') == 'fact1'


def test_ordering_facts_reversed_wildcard(registry):
    registry.extractors.registerExtractor(extractor_three, ('*',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    registry.extractors.registerExtractor(extractor_one, ('f1',))
    assert registry.getFact('f1') == 'fact3'


def test_facts_empty(registry):
    registry.extractors.registerExtractor(extractor_empty, ('f1',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    assert registry.getFact('f1') == 'fact2'


def test_facts_empty_wildcard(registry):
    registry.extractors.registerExtractor(extractor_empty, ('f1',))
    registry.extractors.registerExtractor(extractor_two, ('*',))
    assert registry.getFact('f1') == 'fact2'


def test_facts_empty_reverse_wildcard(registry):
    registry.extractors.registerExtractor(extractor_empty, ('*',))
    registry.extractors.registerExtractor(extractor_two, ('f1',))
    assert registry.getFact('f1') == 'fact2'


def test_no_unserializable_fact_values():
    pass
