from foober.lib.facts import registry


class DefaultFact(object):
    """Default values for facts.

    Only used if no-other extractor can extract the fact.
    """

    def __init__(self, key, fact):
        self.key = key
        self.fact = fact
        self.facts = (key, )

    def __call__(self, registry):
        registry.setFact(self.key, self.fact)


def registerDefaultFacts(registry, facts):
    """Register default facts as separate items.

    We do this, so extracting one of them would not override any other
    facts.
    """
    for key, fact in facts.items():
        registry.registerExtractor(DefaultFact(key, fact))


DEFAULTS = {'prune.bucket': "uber-devtools",
            'prune.remote_snapshots_dir': "prunes",
            'prune.local_snapshots_dir': "./db_snapshots",
            'foober.interactive': False,
            'jenkins.url': 'https://ci.uber.com',
            'prune.decryption_keyring': '/etc/uber/prune_encryption/private_keyring',
            'prune.encryption_keyring': '/etc/uber/prune_encryption/public_keyring'}


registerDefaultFacts(registry, DEFAULTS)
