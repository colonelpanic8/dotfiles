from foober.lib.phabricator import arc
from foober.lib.facts import registry


@registry.registerExtractor(facts='project.phab.*')
def extract_phabricator_info(reg):
    repos = arc('repository.query',
                dict(remoteURIs=[reg.getFact('project.git_url')]))
    if repos:
        repo = repos[0]

    for key, value in repo.items():
        reg.setFact('project.phab.{}'.format(key),
                    value)
