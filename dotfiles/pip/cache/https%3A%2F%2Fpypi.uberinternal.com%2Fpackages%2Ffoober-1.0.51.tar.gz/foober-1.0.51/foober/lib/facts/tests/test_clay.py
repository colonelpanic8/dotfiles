#
import pkg_resources
import pytest
import textwrap


from foober.lib.facts import FactRegistry
from foober.lib.utils import FooberLocalPath
from foober.lib.utils import yaml_dump


@pytest.fixture
def clay_app(tmpdir):
    configs = tmpdir.join('config')
    configs.join('production.yaml').write(
        yaml_dump({
            'woot': 'wat'
        })
    )


@pytest.fixture
def project_tmpdir(tmpdir):
    tmpdir.join('setup.py').write(textwrap.dedent("""\
    from setuptools import setup

    setup(
        author='Ignas Mikalajunas',
        license='closed',
        name='fake_package',
        version='1.0.17',
        zip_safe=False)

    """))
    return FooberLocalPath(tmpdir)


@pytest.fixture
def flipr_fixture(project_tmpdir):
    configs = project_tmpdir.join('config').ensure_dir()
    configs.copy_from(pkg_resources.resource_filename(
        'foober.lib.facts.tests', 'fixtures/flipr-backend'))
    return project_tmpdir


@pytest.fixture
def cleopatra_fixture(project_tmpdir):
    configs = project_tmpdir.join('config').ensure_dir()
    configs.copy_from(pkg_resources.resource_filename(
        'foober.lib.facts.tests', 'fixtures/cleopatra'))
    return project_tmpdir


@pytest.fixture
def querybuilder_fixture(project_tmpdir):
    configs = project_tmpdir.join('config').ensure_dir()
    configs.copy_from(pkg_resources.resource_filename(
        'foober.lib.facts.tests', 'fixtures/querybuilder'))
    return project_tmpdir


def get_all_facts(registry, facts):
    return {key: registry.getFact(key, default=None)
            for key in facts}


def test_integration_flipr_config(flipr_fixture):
    registry = FactRegistry(flipr_fixture)
    expected = {
        'clay.config.sqlalchemy.db_name': 'flipr_backend',
        'clay.config.sqlalchemy.db_ro_file': '/etc/uber/mysql/flipr_backend_ro.cnf',
        'clay.config.sqlalchemy.db_rw_file': '/etc/uber/mysql/flipr_backend_rw.cnf',
        'clay.config.sqlalchemy.db_type': 'mysql'}
    assert get_all_facts(registry,
                         ['clay.config.sqlalchemy.db_name',
                          'clay.config.sqlalchemy.db_type',
                          'clay.config.sqlalchemy.db_ro_file',
                          'clay.config.sqlalchemy.db_rw_file']) == expected


def test_integration_cleopatra_config(cleopatra_fixture):
    registry = FactRegistry(cleopatra_fixture)
    expected = {'clay.config.sqlalchemy.db_name': 'cleopatra',
                'clay.config.sqlalchemy.db_ro_file': None,
                'clay.config.sqlalchemy.db_rw_file': None,
                'clay.config.sqlalchemy.db_type': 'postgresql'}
    assert get_all_facts(registry,
                         ['clay.config.sqlalchemy.db_name',
                          'clay.config.sqlalchemy.db_type',
                          'clay.config.sqlalchemy.db_ro_file',
                          'clay.config.sqlalchemy.db_rw_file']) == expected


def test_integration_querybuilder_config(querybuilder_fixture):
    registry = FactRegistry(querybuilder_fixture)
    expected = {'clay.config.sqlalchemy.db_name': 'querybuilder',
                'clay.config.sqlalchemy.db_ro_file': None,
                'clay.config.sqlalchemy.db_rw_file': None,
                'clay.config.sqlalchemy.db_type': 'postgresql'}
    assert get_all_facts(registry,
                         ['clay.config.sqlalchemy.db_name',
                          'clay.config.sqlalchemy.db_type',
                          'clay.config.sqlalchemy.db_ro_file',
                          'clay.config.sqlalchemy.db_rw_file']) == expected
