"""Interactive fact extractors.

I am not sure how useful these will be, but for now if you run foober
with foober.interactive fact set to True you will get prompted for all
the missing facts.

So for example running::

   $ foober --fact="foober.interactive=true" prune make

Will ask you to enter any data that is missing in your repo or
foober.yaml file, and suggest storing it in ~/.foober.yaml
"""
import os
import yaml

from click import prompt

from foober.lib.facts import registry
from foober.lib.utils import yaml_dump
from foober.lib.utils import FooberLocalPath


def promptFact(registry, fact_name, hide_input=False):
    value = prompt("Please enter value for {}".format(fact_name),
                   hide_input=hide_input,
                   default="N/A")
    if value == 'N/A':
        empty = prompt("You have not entered anything,"
                       " should we set the value to None",
                       default='N')
        if empty == 'N':
            return
        else:
            value = None
    registry.setFact(fact_name, value)
    store = prompt("Do you want to store this value in ~/.foober.yaml",
                   type=bool, default='N')
    if store:
        home = FooberLocalPath(os.path.expanduser('~'))
        dotfile = home.join('.foober.yaml')
        if dotfile.exists():
            orig = dotfile.read()
            values = yaml.safe_load(orig)
        else:
            values = {}
        values[fact_name] = value
        dotfile.write(yaml_dump(values))


@registry.registerExtractor(facts=('secret.*',))
@registry.whenTrue('foober.interactive')
def extractSecretInteractive(registry):
    fact_name = registry._fact_stack[-1]
    promptFact(registry, fact_name, hide_input=True)


@registry.registerExtractor(facts=('*',))
@registry.whenTrue('foober.interactive')
def extractFactInteractive(registry):
    fact_name = registry._fact_stack[-1]
    if fact_name.startswith('secret.'):
        return
    promptFact(registry, fact_name, hide_input=True)
