import os.path
import urllib2
import yaml

from clay_config_file import ClayConfigFileLoader

from foober.lib.facts import registry


class ClayConfigExtractor(ClayConfigFileLoader):
    """Load clay yaml configuration."""

    facts = ('clay.config.*',)

    def _getFileKey(self, local_path):
        return 'clay.config.{}'.format(
            local_path.basename)

    def _setClayConfigFact(self, registry, local_path):
        key = self._getFileKey(local_path)
        try:
            registry.setFact(key, self.load_from_file(str(local_path)))
        except yaml.YAMLError:
            registry.setError(key,
                              "Cannot process clay yaml config file %s" % local_path)

    def _load_from_parent_file(self, config, parent_filename, *args):
        """Override parent file loading to handle absolute paths.

        TODO: add foober check to erradicate those.
        """
        parent_filename = os.path.expandvars(parent_filename)
        if parent_filename.startswith('/home/uber'):
            segments = parent_filename.split(os.path.sep)
            segments = segments[segments.index('config') + 1:]
            parent_filename = os.path.sep.join(segments)

        if not os.path.isabs(parent_filename):
            if self.registry.root.join(parent_filename).exists():
                parent_filename = str(self.registry.root.join(parent_filename))
            else:
                parent_filename = str(self.registry.root
                                      .join('config')
                                      .join(parent_filename))

        if not os.path.exists(str(parent_filename)):
            return dict(config)

        return super(ClayConfigExtractor, self)._load_from_parent_file(
            config, str(parent_filename), *args)

    def __call__(self, registry):
        self.registry = registry
        if registry.getFact('project.type') != 'python-clay':
            return

        for local_path in registry.root.join('config').listdir('*.yaml'):
            self._setClayConfigFact(registry, local_path)


class ClaySqlalchemyUrlExtractor(object):
    """Load clay yaml configuration."""

    facts = ('clay.config.sqlalchemy.url',
             'clay.config.sqlalchemy.master_url',
             'clay.config.sqlalchemy.slave_url',
             'clay.config.sqlalchemy.batch_url')

    def setFact(self, registry, key, value):
        registry.setFact('clay.config.sqlalchemy.{}'.format(key), value)

    def getUrlFromSettings(self):
        pass

    def traverseConfig(self, config, path):
        for el in path:
            if el not in config:
                return None
            config = config[el]
        return config

    def __call__(self, registry):
        if registry.getFact('project.type') != 'python-clay':
            return

        master_paths = [
            ('sqlalchemy', 'master', 'url'),
            ('database', 'sqlalchemy.url'),
            ('database', 'master', 'sqlalchemy.url'),
            # XXX: Cerebro special case
            ('database', 'replicated', 'sqlalchemy.url')
        ]

        slave_paths = [
            ('sqlalchemy', 'slave', 'url'),
            ('database', 'slave', 'sqlalchemy.url')
        ]

        batch_paths = [
            ('sqlalchemy', 'batch', 'url'),
            ('database', 'batch', 'sqlalchemy.url')
        ]

        config = registry.getFact('clay.config.production.yaml')

        for path in batch_paths:
            url = self.traverseConfig(config, path)
            if not url:
                continue
            self.setFact(registry, 'batch_url', url)

        for path in slave_paths:
            url = self.traverseConfig(config, path)
            if not url:
                continue
            self.setFact(registry, 'slave_url', url)
            self.setFact(registry, 'batch_url', url)

        for path in master_paths:
            url = self.traverseConfig(config, path)
            if not url:
                continue
            self.setFact(registry, 'url', url)
            self.setFact(registry, 'master_url', url)
            self.setFact(registry, 'slave_url', url)
            self.setFact(registry, 'batch_url', url)


def parse_url(url):
    result = urllib2.urlparse.urlsplit(url)
    if '?' in result.path:
        path, query = result.path.split('?', 1)
    else:
        path, query = result.path, result.query
    scheme = result.scheme
    params = urllib2.urlparse.parse_qs(query)
    return scheme, path, params


@registry.registerExtractor(facts=('clay.config.sqlalchemy.db_name',
                                   'clay.config.sqlalchemy.db_type',
                                   'clay.config.sqlalchemy.db_ro_file',
                                   'clay.config.sqlalchemy.db_rw_file'))
@registry.whenEqual('project.type', 'python-clay')
def extract_sqlalchemy_url_components(registry):
    master_url = registry.getFact('clay.config.sqlalchemy.url')
    scheme, path, params = parse_url(master_url)
    if scheme.startswith('mysql'):
        db_type = 'mysql'
    elif scheme.startswith('postgres'):
        db_type = 'postgresql'
    registry.setFact('clay.config.sqlalchemy.db_type', db_type)

    db_name = path[1:]  # Remove the slash
    registry.setFact('clay.config.sqlalchemy.db_name', db_name)

    if db_type == 'mysql':
        master_url = registry.getFact('clay.config.sqlalchemy.url')
        scheme, path, params = parse_url(master_url)
        registry.setFact('clay.config.sqlalchemy.db_rw_file',
                         params['read_default_file'][0])

    if db_type == 'mysql':
        slave_url = registry.getFact('clay.config.sqlalchemy.slave_url')
        scheme, path, params = parse_url(slave_url)
        registry.setFact('clay.config.sqlalchemy.db_ro_file',
                         params['read_default_file'][0])


@registry.registerExtractor(facts='project.title')
def extract_one_line_description(registry):
    index = registry.root.join('docs').join('index.rst')
    if index.exists():
        project_title = index.read().splitlines()[0]
    else:
        project_title = registry.getFact('project.name')
    registry.setFact('project.title', project_title)


registry.registerExtractor(ClaySqlalchemyUrlExtractor())
registry.registerExtractor(ClayConfigExtractor())
