from foober.lib.facts.base import project_name_extractor


def test_project_name_extractor_top_level(static_registry):
    static_registry.setFact('project.git_url',
                            'gitolite@code.uber.com:infraportal')
    project_name_extractor(static_registry)
    assert static_registry.getFact('project.name') == 'infraportal'


def test_project_name_extractor_multi_level(static_registry):
    static_registry.setFact('project.git_url',
                            'gitolite@code.uber.com:infra/foo/infraportal')
    project_name_extractor(static_registry)
    assert static_registry.getFact('project.name') == 'infraportal'


def test_project_name_extractor_top_level_git(static_registry):
    static_registry.setFact('project.git_url',
                            'gitolite@code.uber.com:cleopatra.git')
    project_name_extractor(static_registry)
    assert static_registry.getFact('project.name') == 'cleopatra'


def test_project_name_extractor_multi_level_git(static_registry):
    static_registry.setFact('project.git_url',
                            'git@github.com:infra/foober.git')
    project_name_extractor(static_registry)
    assert static_registry.getFact('project.name') == 'foober'
