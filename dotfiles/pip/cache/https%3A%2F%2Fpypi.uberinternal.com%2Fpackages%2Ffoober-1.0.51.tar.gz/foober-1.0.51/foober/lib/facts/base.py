import sh
import os

from foober.lib.facts import registry


@registry.registerExtractor(facts='project.git_url')
def git_url_extractor(registry):
    try:
        url = str(sh.git('config', '--get', 'remote.origin.url').strip())
    except sh.ErrorReturnCode:
        return
    if '@' not in url:
        if url.startswith('code'):
            url = 'gitolite@' + url
        elif url.startswith('github.com'):
            url = 'git@' + url
        elif url.startswith('g:'):
            url = 'gitolite@code.uber.internal' + url[1:]
    registry.setFact('project.git_url', url)


@registry.registerExtractor(facts='project.name')
def project_name_extractor(registry):
    url = registry.getFact('project.git_url')
    repo = url.split(':')[-1]
    name = repo.split('/')[-1]
    if name.endswith('.git'):
        name = name[:-len('.git')]
    registry.setFact('project.name', name)


@registry.registerExtractor(facts='project.type')
def project_type_extractor(registry):
    if registry.root.join('setup.py').exists():
        if registry.root.join('config').exists():
            registry.setFact('project.type', 'python-clay')
        else:
            registry.setFact('project.type', 'python-library')
    elif registry.root.join('package.json').exists():
        # XXX: detect servers
        registry.setFact('project.type', 'node')
