from foober.lib.facts import registry


@registry.registerExtractor(facts='prune.settings.database_type')
@registry.whenEqual('project.type', 'python-clay')
def get_prune_db_type(reg):
    reg.setFact('prune.settings.database_type',
                reg.getFact('clay.config.sqlalchemy.db_type'))


@registry.registerExtractor(facts='prune.settings.database')
@registry.whenEqual('project.type', 'python-clay')
def get_prune_db_name(reg):
    reg.setFact('prune.settings.database',
                reg.getFact('clay.config.sqlalchemy.db_name'))


@registry.registerExtractor(facts='prune.settings.upload_pattern')
def get_prune_upload_pattern(reg):
    prune_suffix = reg.getFact('prune.settings.prune_suffix')
    prune_suffix = '-%s' % prune_suffix if prune_suffix else ''
    pattern = ("%s%s-{timestamp}{extension}" % (
        reg.getFact('prune.settings.database'), prune_suffix))
    reg.setFact('prune.settings.upload_pattern', pattern)


@registry.registerExtractor(facts='prune.settings.prune_title')
def get_prune_title(reg):
    reg.setFact('prune.settings.prune_title', None)


@registry.registerExtractor(facts='prune.settings.latest_filename')
def get_prune_latest_filename(reg):
    suffix = reg.getFact('prune.settings.prune_suffix', None)
    if suffix is None:
        template = 'latest-{database}.txt'
    else:
        template = 'latest-{database}-{suffix}.txt'
    reg.setFact('prune.settings.latest_filename',
                template.format(database=reg.getFact("prune.settings.database"),
                                suffix=suffix))


@registry.registerExtractor(facts='prune.settings.latest_filename_fallback')
def get_prune_latest_filename_fallback(reg):
    reg.setFact('prune.settings.latest_filename_fallback',
                'latest-{}-pruned-encrypted.txt'.format(reg.getFact("prune.settings.database")))


@registry.registerExtractor(facts='prune.settings.s3_directory_fallback')
def get_prune_s3_directory_fallback(reg):
    reg.setFact('prune.settings.s3_directory_fallback',
                '{}/{}'.format(reg.getFact('prune.remote_snapshots_dir'),
                               reg.getFact('prune.settings.database')))


@registry.registerExtractor(facts='prune.settings.s3_directory')
def get_prune_s3_directory(reg):
    reg.setFact('prune.settings.s3_directory',
                '{}/{}'.format(reg.getFact('prune.remote_snapshots_dir'),
                               reg.getFact('project.name')))
