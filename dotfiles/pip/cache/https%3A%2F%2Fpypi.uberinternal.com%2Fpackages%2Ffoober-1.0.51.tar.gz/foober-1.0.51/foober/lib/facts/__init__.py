from foober.lib.facts.registries import registry  # noqa
from foober.lib.facts.registries import FactRegistry  # noqa
from foober.lib.facts.registries import FactExtractorRegistry  # noqa

# Must be first, to override any facts coming after
import foober.lib.facts.core

import foober.lib.facts.base
import foober.lib.facts.clay
import foober.lib.facts.phab
import foober.lib.facts.prune

# Must go after all extractors, so default facts would not override any fact
import foober.lib.facts.defaults  # noqa

# Only trigger interactive extractors for missing facts
import foober.lib.facts.interactive  # noqa
