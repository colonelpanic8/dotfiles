from collections import defaultdict
from functools import wraps
import types

import click


class ExtractorBase(object):
    """Base class/interface for fact extractors."""

    facts = ()

    def __call__(self, registry):
        """Populates registry with facts extracted using this extractor."""
        raise NotImplementedError


class FactRegistryError(Exception):
    """Base class for fact registry errors."""

    def __init__(self, extractor_stack, fact_stack, message):
        super(FactRegistryError, self).__init__(message)
        self.extractor_stack = extractor_stack
        self.fact_stack = fact_stack
        self.message = message

    def __str__(self):
        """Custom __str__ to display fact and extractor stacks."""
        template = "{message}\nExtractors: {extractors}\nFacts: {facts}"
        return template.format(
            message=self.message,
            extractors=' => '.join(map(str, self.extractor_stack)),
            facts=' => '.join(self.fact_stack))


class FactExtractorRegistry(object):
    """Class that maintains registered extractors.

    A global registry under the name "registry" in this module is used
    to track the default extractors.
    """

    def __init__(self):
        self.extractors = []
        self.extractor_map = defaultdict(list)

    def whenEqual(self, fact, value):
        def whenEqualDecorator(extractor):
            @wraps(extractor)
            def whenEqualWrapper(registry):
                if registry.getFact(fact, None) != value:
                    return
                return extractor(registry)
            return whenEqualWrapper
        return whenEqualDecorator

    def whenTrue(self, fact):
        def whenExistsDecorator(extractor):
            @wraps(extractor)
            def whenExistsWrapper(registry):
                truths = ['true', '1', 't', 'y', 'yes']
                value = registry.getFact(fact, '')
                if isinstance(value, basestring):
                    value = value in truths
                if not value:
                    return
                return extractor(registry)
            return whenExistsWrapper
        return whenExistsDecorator

    def registerExtractor(self, extractor=None, facts=None):
        def registrator(extractor, facts=facts):
            self.extractors.append(extractor)
            if facts is None:
                facts = extractor.facts
            if isinstance(facts, basestring):
                facts = (facts,)
            for fact in facts:
                self.extractor_map[fact].append(extractor)
            return extractor
        if extractor is None:
            return registrator
        else:
            return registrator(extractor, facts)

    def getExtractors(self, key):
        extractors = set()
        for candidate_key, candidate_extractors in self.extractor_map.items():
            if (candidate_key == key or
                (candidate_key.endswith('*') and
                 key.startswith(candidate_key[0:-1]))):
                extractors.update(candidate_extractors)
        extractors = sorted(list(extractors), key=self.extractors.index)
        return extractors

    @property
    def facts(self):
        return sorted(self.extractor_map)


registry = FactExtractorRegistry()


class FactRegistry(object):
    """The stateful friend of the ExtractorRegistry.

    This class keeps all the state, so if you do multiple extractions
    in the same process, you should just make a bunch of
    FactRegistries (one per project path) with the same
    ExtractorRegistry.

    This class does not mutate the extractor registry in any way.

    """

    def __init__(self, root, extractor_registry=None,
                 trace=False, trace_all=False):
        self.executed_extractors = []
        self._facts = {}
        if extractor_registry is not None:
            self.extractors = extractor_registry
        else:
            self.extractors = registry
        self.root = root

        self.trace = trace
        self.trace_all = trace_all

        # debugging data for nice verbose errors
        self._extractor_stack = []
        self._fact_stack = []

        # Dictionaries with fact dependencies
        self._fact_deps = defaultdict(list)
        self._fact_extractors = {}

    def _error(self, message, exception=FactRegistryError):
        extractor_stack = self._extractor_stack
        fact_stack = self._fact_stack
        self._extractor_stack = []
        self._fact_stack = []
        raise exception(extractor_stack,
                        fact_stack,
                        message)

    def extract(self, extractor):
        self._extractor_stack.append(extractor)
        if extractor in self.executed_extractors:
            self._error("Extractors should be executed only once!")
        extractor(self)
        self._extractor_stack.pop()
        self.executed_extractors.append(extractor)

    def extractAllFacts(self, ignore_errors=True):
        for extractor in self.extractors.extractors:
            if extractor not in self.executed_extractors:
                try:
                    self.extract(extractor)
                except FactRegistryError:
                    if not ignore_errors:
                        raise
        return {k: v
                for k, v in self._facts.items()
                if not k.startswith('secret.')}

    # Sentinel for no fact being found
    NO_FACT = object()

    def getFact(self, key, default=NO_FACT):
        if key in self._fact_stack:
            self._error("Fact loop detected {} => {}!".format(
                ' => '.join(self._fact_stack), key))
        self._fact_stack.append(key)
        if key not in self._facts:
            extractors = self.extractors.getExtractors(key)
            for extractor in extractors:
                if extractor in self.executed_extractors:
                    continue

                self.extract(extractor)
                # Only iterate until we get the fact for the first time
                if key in self._facts:
                    break
            else:
                if default is not self.NO_FACT:
                    self._fact_stack.pop()
                    self._traceGet(key, default, default=True)
                    return default
                self._error("Failed to extract a fact {}".format(key))
        self._fact_stack.pop()
        value = self._facts[key]
        self._traceGet(key, value)
        return value

    def _traceGet(self, key, value, default=False):
        depending_key = None
        if self._fact_stack:
            depending_key = self._fact_stack[-1]
        self._fact_deps[depending_key].append((key, value, default))

    def getLastExtractor(self):
        if not self._extractor_stack:
            return "Set directly"
        else:
            last_extractor = self._extractor_stack[-1]
            if isinstance(last_extractor, types.FunctionType):
                return "{}:{}".format(last_extractor.__module__,
                                      last_extractor.__name__)
            else:
                return "{}:{}".format(last_extractor.__class__.__module__,
                                      last_extractor.__class__.__name__)

    def setFact(self, key, value):
        # XXX: Decide if I want to do first fact wins, last fact wins
        # or only one fact can be there

        # For now - ignore duplicate fact updates, this is so
        # overrides would work, while still allowing for wildcard
        # facts
        if key in self._facts:
            return

        self._fact_extractors[key] = self.getLastExtractor()
        self._facts[key] = value

    def formatValue(self, value, max_len=80):
        value = repr(value)
        if len(value) > 80:
            value = repr(value)[:77] + '...'
        return value

    def printSubTree(self, facts, indent='', stdout=False, with_secrets=False):
        if not with_secrets:
            facts = [fact
                     for fact in facts
                     if not fact[0].startswith('secret.')]
        for n, (fact, value, default) in enumerate(facts):
            new_indent = indent + '|   '
            if len(facts) == n + 1:
                new_indent = indent + '    '

            if not default:
                extractor = self._fact_extractors[fact]
                click.echo("{}`--{} ({} via {})".format(
                    indent,
                    fact,
                    self.formatValue(value),
                    extractor), err=not stdout)
                self.printSubTree(self._fact_deps[fact], indent=new_indent)
            else:
                click.echo("{}`--{} (used default: {})".format(
                    indent,
                    self.formatValue(fact),
                    value), err=not stdout)

    def printTrace(self, facts=(), stdout=False, with_secrets=False):
        if not facts:
            # Get all the facts that depend on nothing
            facts = self._fact_deps[None]
        else:
            facts = [
                (fact, self._facts.get(fact, None), False)
                for fact in facts]
        self.printSubTree(facts, stdout=stdout, with_secrets=with_secrets)
