import os.path

import click
import yaml

from foober.lib.utils import FooberLocalPath
from foober.lib.facts import registry


class FactOverrideExtractor(object):
    """Fact overrides.

    Facts coming from foober.yaml in the project sandbox override any
    default or extracted facts.
    """

    facts = ('*',)

    def loadFacts(self, path):
        if not path.accessible():
            return {}
        try:
            return yaml.safe_load(path.read())
        except yaml.parser.ParserError as e:
            click.echo("Warning: could not parse {}:\n{}".format(
                path, e), err=True)
            # Ignore broken yaml files
            return {}

    def storeFacts(self, registry, facts):
        if not facts:
            return
        for key, fact in facts.items():
            registry.setFact(key, fact)

    def __call__(self, registry):
        for path in [
                registry.root.join('foober.yaml'),
                FooberLocalPath(os.path.expanduser('~')).join('.foober.yaml')
        ]:
            self.storeFacts(registry, self.loadFacts(path))

        global_config_path = FooberLocalPath('/etc/foober/')
        if not global_config_path.accessible():
            return

        for path in sorted(FooberLocalPath('/etc/foober/').listdir('*.yaml')):
            self.storeFacts(registry, self.loadFacts(path))


registry.registerExtractor(FactOverrideExtractor())


class SecretExtractor(object):
    """Get secrets populated by puppet."""

    facts = ('secret.*',)

    def __call__(self, registry):
        clusto_client_conf = FooberLocalPath('/etc/clusto-client.conf')
        # XXX check if it's readable
        if clusto_client_conf.exists():
            username, password = clusto_client_conf.read().split(':')
            registry.setFact('secret.clusto.username', username)
            registry.setFact('secret.clusto.password', password)


registry.registerExtractor(SecretExtractor())
