import pytest

from foober.lib.facts import FactRegistry
from foober.lib.facts import FactExtractorRegistry


class StubExtractor(object):
    """Dummy extractor."""

    facts = ('project.name',)

    def __call__(self, registry):
        registry.setFact('project.name', 'foobie')


class StubSecondTierExtractor(object):
    """Extractor that depends on another extractor."""

    facts = ('git.url',)

    def __call__(self, registry):
        registry.setFact('git.url',
                         'git@github.com:uber/{}'.format(
                             registry.getFact('project.name')))


@pytest.fixture
def extractor_registry():
    """Fact extractor registry."""
    return FactExtractorRegistry()


@pytest.fixture
def registry(extractor_registry):
    """Fact registry.

    It uses the extractor registry without any extractors.
    """
    # XXX: ExtractorRegistry needs it's own tests
    return FactRegistry(root=None, extractor_registry=extractor_registry)


@pytest.fixture
def extractor(request):
    """Dummy extractor."""
    return StubExtractor()


@pytest.fixture
def registry_with_extractors(request, extractor_registry):
    """Fact registry with extractors registered."""
    extractor_registry.registerExtractor(StubExtractor())
    extractor_registry.registerExtractor(StubSecondTierExtractor())
    return FactRegistry(root=None, extractor_registry=extractor_registry)
