from __future__ import absolute_import
import random

import lxml.etree
from jenkins import Jenkins


AUTH_KEY_PARTS = map(chr,
                     [i for i in (range(ord('0'), ord('9')) +
                                  range(ord('A'), ord('Z')) +
                                  range(ord('a'), ord('z')))])


def make_auth_key():
    return ''.join([random.choice(AUTH_KEY_PARTS)
                    for x in range(32)])


class FooberJenkinsClient(Jenkins):
    """Jenkins client with foober specific extensions."""

    def __init__(self, registry):
        self.registry = registry
        super(FooberJenkinsClient, self).__init__(
            registry.getFact('jenkins.url'),
            registry.getFact('secret.jenkins.username'),
            registry.getFact('secret.jenkins.password'))

    def get_job_config_tree(self, *args, **kwargs):
        return lxml.etree.fromstring(self.get_job_config(*args, **kwargs))

    def get_job_token(self, job_name):
        template_tree = self.get_job_config_tree(job_name)
        return template_tree.xpath('/project/authToken')[0].text

    def create_job_from_template(
            self, title, job_name, repo_uri, template):
        template_tree = self.get_job_config_tree(template)

        description = template_tree.xpath('/project/description')[0]
        description.text = "{} test build".format(title.capitalize())

        authToken = template_tree.xpath('/project/authToken')[0]
        authToken.text = make_auth_key()

        git_uri = template_tree.xpath('/project/scm/userRemoteConfigs/'
                                      'hudson.plugins.git.UserRemoteConfig/url')[0]
        git_uri.text = repo_uri

        # builders = template_tree.xpath('/project/builders/'
        #                                'hudson.tasks.Shell/command')[0]
        # builders.text = 'sh bin/test.sh'

        job_xml = lxml.etree.tostring(template_tree)
        self.create_job(job_name, job_xml)
        return self.server + 'job/{}'.format(job_name)
