import copy
import json
import os
import pkg_resources
import subprocess
import urllib
import urllib2
import yaml

from collections import defaultdict, Mapping


class Extractor(object):

    apps = []

    def __init__(self, state):
        self.state = state

    def extract(self):
        pass

    def extract2(self):
        pass

    def __getattr__(self, name):
        """Acquisition FTW

        I am so sorry.
        """
        return getattr(self.state, name)

    def ensure_path(self, fact, path, error=True):
        full_path = os.path.join(self.state.path, path)
        if not os.path.exists(full_path):
            fact.error = error
            fact.important = False
            fact.data = '{} is missing'.format(path)
        else:
            fact.ok = True
            fact.content = open(full_path).readlines()
            fact.important = False


class AppTypeExtractor(Extractor):

    def extract(self):
        self.ensure_path(self.setup_py, 'setup.py', error=False)
        if self.setup_py.ok:
            self.info('app_type', 'clay')
            return

        packages = subprocess.check_output(
            ['find', self.state.path, '-name', 'package.json']).splitlines()
        if packages:
            self.info('package_jsons', [path.replace(self.state.path + '/', '')
                                        for path in packages])
            self.info('app_type', 'node')


def extract_head_hash(repo_path, repo_name, fact):
    try:
        result = subprocess.check_output(
            ['cd {}; git rev-parse HEAD'.format(repo_path)],
            shell=True)
        fact.ok = True
        fact.data = result.splitlines()[0]
    except subprocess.CalledProcessError:
        fact.error = True
        fact.data = "Could not extract head of repo %s" % repo_name


class RepoHeadExtractor(Extractor):

    def extract(self):
        extract_head_hash(self.state.path, self.state.app_repo, self.repo_head)


class PuppetHeadExtractor(Extractor):

    def extract(self):
        extract_head_hash(self.state.puppet_manifests_path, 'puppet-manifests', self.puppet_head)


class NodeDependenciesExtractor(Extractor):

    apps = ['node']

    def flatten_dependencies(self, dependencies):
        for dependency, info in dependencies.items():
            yield dependency, info['version']
            for dep in self.flatten_dependencies(info.get('dependencies', {})):
                yield dep

    def extract(self):
        all_deps = {}
        for package_fn in self.package_jsons.data:
            with open(os.path.join(self.state.path, package_fn)) as f:
                deps = json.loads(f.read()).get('dependencies', {})
                all_deps[package_fn.replace(self.state.path, '')] = deps
        self.info('direct_deps', all_deps)
        self.ensure_path(self.npm_shrinkwrap, 'npm-shrinkwrap.json')
        if self.npm_shrinkwrap.ok:
            wrap = json.loads('\n'.join(self.npm_shrinkwrap.content))
            all_dependencies = self.flatten_dependencies(wrap['dependencies'])
            dep_dict = defaultdict(set)
            for dep, version in all_dependencies:
                dep_dict[dep].add(version)
            self.info('all_deps', {dep: list(version)
                                   for (dep, version) in dep_dict.items()})


class RequirementExtractor(Extractor):

    apps = ['clay']

    def extract(self):
        self.ensure_path(self.requirements_txt, 'requirements.txt')
        if self.requirements_txt.ok:
            self.requirements_txt.data = {}
            self.requirements_txt.important = True
            for requirement in self.requirements_txt.content:
                try:
                    req = pkg_resources.Requirement.parse(requirement.strip())
                    self.requirements_txt.data[req.key] = req.specs
                except ValueError:
                    continue


class ClayYamlConfigExtractor(Extractor):
    """Extract clay config from yaml files as dictionaries.

    Note: this includes a (hacky and possibly incomplete) implementation of clay config merging.
    TODO(ignas, zhitao): Replace this with clay's own implementation when it's ready for reuse.
    """
    apps = ['clay']

    @staticmethod
    def deep_update(d, u):
        for k, v in u.iteritems():
            if isinstance(v, Mapping):
                r = LoggingExtractor.deep_update(d.get(k, {}), v)
                d[k] = r
            else:
                d[k] = u[k]
            return d

    def _build_clay_config_fact(self, filename):
        key = filename.replace('.', '_')
        existing_fact = getattr(self.state, key)  # avoid processing more than once
        if existing_fact.data:
            return
        try:
            content = open(os.path.join(self.state.path, 'config', filename)).read()
            yaml_dict = yaml.safe_load(content)
            if 'extends' in yaml_dict:
                parent_file = yaml_dict['extends']
                del(yaml_dict['extends'])
                self._build_clay_config_fact(parent_file)
                parent_fact = getattr(self.state, parent_file.replace('.', '_'))
                if not parent_fact.ok:
                    self.error(key, "Cannot process clay yaml config file")
                if yaml_dict.get('deep_extend') or parent_fact.data.get('deep_extend'):
                    # deep extend
                    yaml_dict = LoggingExtractor.deep_update(parent_fact.data, yaml_dict)
                else:
                    # plain extend
                    parent_copy = copy.deepcopy(parent_fact.data)
                    parent_copy.update(yaml_dict)
                    yaml_dict = parent_copy
            self.info(key, yaml_dict)
        except yaml.YAMLError:
            self.error(key, "Cannot process clay yaml config file %s" % filename)

    def extract(self):
        config_dir = os.path.join(self.state.path, 'config')
        files = [f for f in os.listdir(config_dir) if f.endswith('.yaml')]
        for filename in files:
            self._build_clay_config_fact(filename)


class LoggingExtractor(Extractor):

    apps = ['clay']

    def extract(self):
        if self.production_yaml.ok:
            configurators = self.production_yaml.data.get('logging', {}).get('configurator', '')
            if 'SortsolLoggingConfigurator' in configurators:
                self.logging_updated.ok = True
            else:
                self.error('logging_updated', 'Logging has not been updated yet')
        else:
            self.error('logging_updated', 'production.yaml does not seem ok')


class SetupPyExtractor(Extractor):

    apps = ['clay']

    def extractValue(self, line, key):
        line = line.strip()
        value = None
        if line.startswith('%s=' % key):
            value = line.replace('%s=' % key, '')\
                        .rstrip(',')\
                        .replace('\'', '')\
                        .replace('"', '')
        return value

    def extract(self):
        if self.setup_py.ok:
            for line in self.setup_py.content:
                email = self.extractValue(line, 'email')
                if email is not None:
                    self.email.ok = True
                    self.email.data = [email]
                    if ',' in email:
                        self.email.data = email.split(',')

                author_email = self.extractValue(line, 'author_email')
                if author_email is not None:
                    self.author_email.ok = True
                    self.author_email.data = [author_email]
                    if ',' in author_email:
                        self.author_email.data = author_email.split(',')

                author = self.extractValue(line, 'author')
                if author is not None:
                    self.author.ok = True
                    self.author.data = author

            if not self.email.ok:
                self.email.error = True
                self.email.data = "Email is not in setup.py"

            if not self.author.ok:
                self.author.error = True
                self.author.data = "Author is not in setup.py"

            if not self.author_email.ok:
                self.author_email.error = True
                self.author_email.data = "Author email is not in setup.py"


class PDTeamExtractor(Extractor):

    apps = ['clay']

    def extract(self):
        app = self.state.app_repo.split('/')[-1]
        manifests = self.state.puppet_manifests_path
        try:
            result = subprocess.check_output(
                ['(cd {}; git grep -A 6 "^ *uber::service::clay_service") |'
                 ' grep -A 5 {}.: | grep "owning_team"'.format(manifests, app)],
                shell=True)
            self.owning_team.ok = True
            self.owning_team.data = result.split('=>')[-1]\
                                          .replace("'", '')\
                                          .replace(',', '')\
                                          .replace(';', '')\
                                          .strip()
        except subprocess.CalledProcessError:
            self.owning_team.error = True
            self.owning_team.data = "Could not extract owning team"


class SentryExtractor(Extractor):

    apps = ['clay']

    def extract2(self):
        pass


class CommittersExtractor(Extractor):

    def extract(self):
        result = subprocess.check_output(
            ['(cd {}; git log --format=format:"%cE")'
             ' | head -50 | sort  | uniq -c | sort -nr'.format(
                 self.state.path)],
            shell=True)

        self.info('authors', [author.split()[1]
                              for author in result.splitlines()])

        result = subprocess.check_output(
            ['(cd {}; git log --format=format:"%ci") | head -1'.format(
                self.state.path)],
            shell=True)
        self.last_commit_date.ok = True
        self.last_commit_date.data = result.strip()

        result = subprocess.check_output(
            ['(cd {}; git log --format=format:"%cr") | head -1'.format(
                self.state.path)],
            shell=True)
        self.last_commit_relative.ok = True
        self.last_commit_relative.data = result.strip()


def run_conduit(conduit, params=None):
    if params is None:
        params = {}
    result = json.loads(subprocess.check_output([
        'arc call-conduit %s'
        ' --conduit-uri=https://code.uberinternal.com 2> /dev/null <<EOF\n'
        '%s\n'
        'EOF\n' % (conduit, json.dumps(params))
    ], shell=True))
    if result['error'] is None:
        return result['response']
    else:
        raise Exception(result['errorMessage'])


class AppInfoExtractor(Extractor):

    def extract(self):
        self.info('app_name', self.state.app_repo.split('/')[-1])
        self.info('app_repository', self.state.app_repo)
        repo = run_conduit(
            'repository.query',
            dict(remoteURIs=["gitolite@code.uber.internal:{}".format(self.state.app_repo)]))
        if repo and repo[0].get('monogram'):
            monogram = repo[0]['monogram']
            self.info('repo_monogram', monogram)
        else:
            self.error('repo_monogram', 'Could not extract monogram')


class PhabTaskInfoExtractor(Extractor):
    def extract(self):

        self.ensure_path(self.arcconfig, '.arcconfig')
        if self.arcconfig.ok:
            self.arcconfig.data = json.loads('\n'.join(self.arcconfig.content))
            self.arcconfig.important = True
            self.info('arcanist_project_id', self.arcconfig.data['project_id'])

        if self.author_phid.ok and self.author_phid.data:
            self.task_owner_phid.data = self.author_phid.data[0]
        elif self.owner_phid.ok and self.owner_phid.data:
            self.task_owner_phid.data = self.owner_phid.data[0]
        elif self.commiter_phids.ok and self.commiter_phids.data:
            self.task_owner_phid.data = self.commiter_phids.data[0]
        else:
            self.state.error('task_owner_phid', "Can't get task owner phid!")

        if self.project_id.ok:
            try:
                project_info = run_conduit(
                    'arcanist.projectinfo',
                    dict(name=self.project_id.data))
                self.info('arcanist_project_info', project_info)
            except Exception as e:
                self.error('arcanist_project_info', str(e))

        try:
            project_info = run_conduit(
                'project.query',
                dict(names=[self.state.app_repo, self.state.app_name.data]))
            self.info('project_info', project_info)
        except Exception as e:
            self.error('project_info', str(e))

        if self.commiter_phids.ok:
            self.info('ccPHIDs', [person['phid']
                                  for person in self.commiter_phids.data
                                  if person['phid'] != self.task_owner_phid.data['phid']])


class Email2PhidExtractor(Extractor):

    def extract(self):
        if self.author_email.ok:
            self.author_phid.ok = True
            self.author_phid.data = run_conduit(
                'user.query', dict(emails=self.author_email.data))

        if self.email.ok:
            self.owner_phid.ok = True
            self.owner_phid.data = run_conduit(
                'user.query', dict(emails=self.email.data))

        self.commiter_phids.ok = True
        self.commiter_phids.data = run_conduit(
            'user.query',
            dict(emails=self.authors.data))
        self.commiter_phids.data.sort(key=lambda v: self.authors.data.index(v['email']))


class UdeployExtractor(Extractor):

    def extract(self):
        self.ensure_path(self.udeploy_json, 'udeploy/udeploy.json', error=False)
        if self.udeploy_json.ok:
            self.udeploy_enabled.ok = True
            self.udeploy_enabled.data = True

            self.udeploy_config.ok = True
            self.udeploy_config.data = json.loads(''.join(self.udeploy_json.content))


def clusto_request(endpoint, **kwargs):
    url = 'http://clusto.local.uber.internal/api%s?%s' % (endpoint, urllib.urlencode(kwargs))
    req = urllib2.Request(url)
    resp = urllib2.urlopen(req)
    return json.load(resp)


class ProductionExtractor(Extractor):

    apps = ['clay']

    def extract(self):
        app = self.state.app_repo.split('/')[-1]
        try:
            self.info('clusto_attrs', clusto_request('/pool/%s/show' % app)['attrs'],
                      important=False)
        except Exception as e:
            self.error('clusto_attrs', str(e))

        result = []
        if self.clusto_attrs.ok:
            result = [attr for attr in self.clusto_attrs.data
                      if (attr['key'] == 'puppet'
                          and attr['subkey'] == 'service_%s' % app)]

        if result:
            self.in_production.ok = True
            self.in_production.data = result[-1]['value']
        else:
            self.in_production.error = True
            self.in_production.data = 'Does not seem to be in production'
