"""Shared utility code."""
import os
import os.path
import subprocess
import yaml

from py.path import local


class FooberLocalPath(local):
    """A custom LocalPath object with some extensions."""

    def system(self, *extra_args):
        """Simply run the file in the path."""
        if os.access(str(self), os.X_OK):
            return subprocess.call([str(self)] + list(extra_args), shell=False)
        else:
            runners = {'.sh': 'sh',
                       '.py': 'python',
                       '.js': 'node'}
            command = [runners.get(self.ext, 'sh'), str(self)] + list(extra_args)
            return subprocess.call(command, shell=False)

    def copy_from(self, source):
        if isinstance(source, local):
            return source.copy(self)
        else:
            local(source).copy(self)

    def accessible(self):
        if not self.exists():
            return False
        return os.access(str(self), os.R_OK)


def yaml_dump(data):
    Dumper = yaml.SafeDumper
    Dumper.ignore_aliases = lambda self, data: True
    return yaml.dump(data, default_flow_style=False, Dumper=Dumper)
