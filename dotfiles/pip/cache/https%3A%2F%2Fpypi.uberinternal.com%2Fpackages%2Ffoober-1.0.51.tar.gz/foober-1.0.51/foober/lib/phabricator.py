from os.path import expanduser
import subprocess

import json

from foober.lib.utils import FooberLocalPath


def arc(conduit, params={}):
    command = ["arc"]
    arcrc_file = '/etc/foober/foober_arcrc'
    if FooberLocalPath(arcrc_file).accessible():
        command.extend(["--arcrc-file", arcrc_file])
    command.extend(["call-conduit", conduit, "--conduit-uri=https://code.uberinternal.com"])
    process = subprocess.Popen(
        command,
        cwd=expanduser("~"),
        stdin=subprocess.PIPE,
        stderr=open('/dev/null', 'w'),
        stdout=subprocess.PIPE)
    result_stream = process.communicate(input=json.dumps(params))[0]
    process.stdin.close()

    try:
        result = json.loads(result_stream)
    except ValueError:
        raise Exception(result_stream)

    if result['error'] is None:
        return result['response']
    else:
        raise Exception(result['errorMessage'])


def find_user_phids(usernames):
    """Return users PHIDs."""
    users = arc('user.query', {'usernames': usernames})

    return {user['userName']: user['phid'] for user in users}


def whoami():
    """Retrieve information about the logged-in user."""
    return arc('user.whoami')
