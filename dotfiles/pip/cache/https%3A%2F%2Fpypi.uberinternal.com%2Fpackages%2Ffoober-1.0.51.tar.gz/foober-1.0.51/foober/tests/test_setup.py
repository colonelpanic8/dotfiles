import textwrap

from foober.setup import requirements


def test_requirements(tmpdir):
    requirement_file = tmpdir.join('requirements.txt')
    requirement_file.write(textwrap.dedent("""\
    # A comment
    tox>=1.8,<2
    """))
    assert requirements(requirement_file.strpath) == ['tox>=1.8,<2']
