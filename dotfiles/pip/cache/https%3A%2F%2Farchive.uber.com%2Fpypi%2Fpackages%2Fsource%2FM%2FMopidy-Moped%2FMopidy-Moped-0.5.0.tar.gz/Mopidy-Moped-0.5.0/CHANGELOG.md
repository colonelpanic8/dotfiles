# 0.5.0 (2015-04-05)

Updated mopidy.js to 0.5.0
Mopidy 1.0.0 compatibility
Updated player controls active and hover styles (Sebastian) 

# 0.4.4 (2015-03-14)

Fixed search

# 0.4.3 (2015-03-14)

Min. characters for search is now 2 instead of 3
Use protocol relative urls for fonts (André Gaul)
Updated Angular to 1.3.x
Updated various other js libs to latest version
Try to display Mopidy album images before requesting album images from LastFM
Removed clear_current_track parameter from mopidy.stop() method for Mopidy 0.20 compatibility

# 0.4.2 (2014-11-17)

Fixed accidentally disabled error logger

# 0.4.1 (2014-11-16)

Added random toggle switch
Fixed browsing of playlists (David Tischler)
Reverted interpolation of track position due to instability
Search query is passed to mopidy as an array to support new Spotify backend

# 0.4.0 (2014-10-10)

Support for Mopidy browsing (David Tischler, https://github.com/tischlda)
Fix for search queries (David Tischler)
Backend provider is displayed in track list (Julien Bordellier)
Allow special characters in search
Interpolation of track position and checking every 10 seconds

# 0.3.3 (2014-08-03)

Reduced default amount of logging

# 0.3.2 (2014-08-03)

Fixed volume slider

# 0.3.1 (2014-07-23)

Fixed PyPI package manifest
Support for playlist folders in PyPI package

# 0.3.0 (2014-06-24)

Moped as installable Mopidy extension

# 0.2.0 (2013-12-18)

Angular version added.


# 0.1.0 (2013-12-04)

Initial Durandal version.