This is a GNU which replacement with the following features:
- it is portable (Windows, Linux);
- it understands PATHEXT on Windows;
- it can print <em>all</em> matches on the PATH;
- it can note "near misses" on the PATH (e.g. files that match but
  may not, say, have execute permissions; and
- it can be used as a Python module.


