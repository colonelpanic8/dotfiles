class AuthenticationError(Exception): pass
class NoCorrespondentError(Exception): pass
