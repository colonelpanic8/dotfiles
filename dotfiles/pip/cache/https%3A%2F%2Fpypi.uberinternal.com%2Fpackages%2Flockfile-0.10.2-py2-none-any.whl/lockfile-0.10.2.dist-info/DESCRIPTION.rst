The lockfile package exports a LockFile class which provides a simple API for
locking files.  Unlike the Windows msvcrt.locking function, the fcntl.lockf
and flock functions, and the deprecated posixfile module, the API is
identical across both Unix (including Linux and Mac) and Windows platforms.
The lock mechanism relies on the atomic nature of the link (on Unix) and
mkdir (on Windows) system calls.  An implementation based on SQLite is also
provided, more as a demonstration of the possibilities it provides than as
production-quality code.

Note: In version 0.9 the API changed in two significant ways:

 * It changed from a module defining several classes to a package containing
   several modules, each defining a single class.

 * Where classes had been named SomethingFileLock before the last two words
   have been reversed, so that class is now SomethingLockFile.

The previous module-level definitions of LinkFileLock, MkdirFileLock and
SQLiteFileLock will be retained until the 1.0 release.

Available on GitHub from:

    git://github.com/smontanaro/pylockfile.git

To install:

    python setup.py install



