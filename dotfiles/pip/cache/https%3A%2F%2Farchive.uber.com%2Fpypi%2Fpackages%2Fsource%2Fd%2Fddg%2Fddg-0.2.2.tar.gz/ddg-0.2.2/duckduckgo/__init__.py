from duckduckgo import search
